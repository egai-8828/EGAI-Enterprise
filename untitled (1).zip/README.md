# EGAI Enterprise — Enterprise Intelligence Platform

EGAI Enterprise is a multi-tenant AI business intelligence SaaS platform designed for financial analysis, document intelligence, KPI diagnostics, and executive reporting.

## Architecture Overview
- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Recharts, bilingual English (LTR) & Arabic (RTL) interface.
- **Authentication & Database**: Firebase Authentication (Google Sign-In + Email/Password flows) and Cloud Firestore with company-isolated security rules (`firestore.rules`).
- **Backend API**: Express (`server.ts`) running on port 3000 with Firebase JWT verification (`jose`), rate limiting, and RBAC enforcement (`owner`, `administrator`, `analyst`, `viewer`).
- **AI Inference**: Modular provider router prioritizing **Amazon Bedrock** (`@aws-sdk/client-bedrock-runtime` `ConverseStreamCommand`) when AWS credentials are configured, with **Server-Side Gemini** (`@google/genai`) support when `GEMINI_API_KEY` is present.
- **Document Processing**: Server-side extraction for PDF (`pdf-parse`), XLSX/CSV (`xlsx`), DOCX (`mammoth`), and TXT with S3 (`@aws-sdk/client-s3`) or local company-isolated storage (`/storage/companies`).

## Local Setup Instructions
1. Install dependencies:
   ```bash
   npm install
   ```
2. Configure environment variables by copying `.env.example` to `.env`:
   - `GEMINI_API_KEY` (optional server-side AI fallback)
   - `AWS_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `BEDROCK_MODEL_ID` (for Amazon Bedrock)
   - `AWS_S3_BUCKET` (optional for S3 document storage)
   - `PAYMOB_API_KEY`, `PAYMOB_INTEGRATION_ID`, `PAYMOB_HMAC_SECRET` (optional / deferred for Paymob payment gateway integration)
3. In Firebase Console for your project, ensure **Google** sign-in is enabled (and enable **Email/Password** under Authentication → Sign-in method if using email/password accounts).
4. Start the full-stack server:
   ```bash
   npm run dev
   ```

## Testing & Verification
- Type-check: `npm run lint`
- Unit tests: `npm test`
- Production build: `npm run build`

## Deployment Instructions
1. Build the frontend bundle:
   ```bash
   npm run build
   ```
2. Set production environment variables (`NODE_ENV=production`, `PORT=3000`, AWS Bedrock / Gemini / S3 secrets) on your hosting platform (Cloud Run, ECS, or EC2).
3. Start the server:
   ```bash
   npm start
   ```
4. Deploy Firestore security rules (`firestore.rules`) to your Firebase project before serving production traffic.
