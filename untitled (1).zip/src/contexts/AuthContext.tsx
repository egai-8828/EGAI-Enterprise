import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  applyActionCode,
  confirmPasswordReset,
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut as firebaseSignOut,
  updateProfile,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { companyApi } from '../lib/apiClient';
import { getPermissionsForRole, type RolePermissions } from '../shared/rbac';
import { PLANS } from '../shared/plans';
import {
  sanitizeForensicFindingDraft,
  sanitizeGrowthProposalDraft,
  sanitizeKnowledgeChunkDraft,
  sanitizeStructuredRecordDraft,
  type ChunkDraft,
  type ExtractedRecordDraft,
} from '../shared/intelligenceEngine';
import type {
  ActiveSpecialistId,
  AIProviderName,
  AuditActionType,
  AuditLogEntry,
  BusinessDocument,
  ChatMessage,
  CompanyInvite,
  CompanyMember,
  CompanyProfile,
  CompanySize,
  Conversation,
  EnterpriseReport,
  ForensicFinding,
  ForensicStatus,
  GrowthProposal,
  GrowthProposalStatus,
  KnowledgeChunk,
  Language,
  RecordVerificationStatus,
  ReportType,
  StructuredBusinessRecord,
  UsageLog,
  UserProfile,
  UserRole,
  WorkspaceDataDomain,
} from '../shared/types';

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  userProfile: UserProfile | null;
  company: CompanyProfile | null;
  currentMember: CompanyMember | null;
  permissions: RolePermissions;
  pendingInvites: CompanyInvite[];
  members: CompanyMember[];
  companyInvites: CompanyInvite[];
  documents: BusinessDocument[];
  structuredRecords: StructuredBusinessRecord[];
  knowledgeChunks: KnowledgeChunk[];
  forensicFindings: ForensicFinding[];
  growthProposals: GrowthProposal[];
  auditLogs: AuditLogEntry[];
  conversations: Conversation[];
  reports: EnterpriseReport[];
  usageLogs: UsageLog[];
  dataLoading: boolean;

  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (email: string, password: string, displayName: string, language: Language) => Promise<void>;
  sendResetEmail: (email: string) => Promise<void>;
  confirmResetPassword: (oobCode: string, newPassword: string) => Promise<void>;
  applyEmailVerificationCode: (oobCode: string) => Promise<void>;
  resendVerificationEmail: () => Promise<void>;
  refreshAuthUser: () => Promise<boolean>;
  signOut: () => Promise<void>;

  createCompanyWorkspace: (input: {
    name: string;
    industry: string;
    size: CompanySize;
    country: string;
    preferredLanguage: Language;
  }) => Promise<string>;
  acceptInvite: (invite: CompanyInvite) => Promise<void>;
  createInvite: (email: string, role: Exclude<UserRole, 'owner'>) => Promise<void>;
  revokeInvite: (inviteId: string) => Promise<void>;
  updateMemberRole: (memberUid: string, role: Exclude<UserRole, 'owner'>) => Promise<void>;
  removeCompanyMember: (memberUid: string) => Promise<void>;
  updateCompanyProfile: (updates: Partial<Pick<CompanyProfile, 'name' | 'industry' | 'size' | 'country' | 'preferredLanguage' | 'logoUrl'>>) => Promise<void>;
  updateCompanyGovernance: (updates: {
    retentionDays?: number;
    companySummary?: string;
    strategicGoals?: string[];
    modelFocusData?: string;
  }) => Promise<void>;
  purgeCompanyWorkspaceData: () => Promise<void>;
  updateUserSettings: (updates: Partial<Pick<UserProfile, 'displayName' | 'preferredLanguage' | 'appearance' | 'emailNotifications' | 'usageAlerts'>>) => Promise<void>;

  createConversation: (title: string, specialistId: ActiveSpecialistId, documentIds?: string[]) => Promise<string>;
  renameConversation: (conversationId: string, title: string) => Promise<void>;
  updateConversationDocs: (conversationId: string, documentIds: string[]) => Promise<void>;
  deleteConversation: (conversationId: string) => Promise<void>;
  saveMessage: (params: {
    conversationId: string;
    role: 'user' | 'assistant';
    content: string;
    specialistId: ActiveSpecialistId;
    provider?: AIProviderName | 'user';
    model?: string;
    inputTokens?: number;
    outputTokens?: number;
    newMessageCount: number;
  }) => Promise<string>;
  setMessageFeedback: (conversationId: string, messageId: string, feedback: 'none' | 'up' | 'down') => Promise<void>;

  saveDocumentRecord: (docData: Omit<BusinessDocument, 'createdAt' | 'updatedAt'>) => Promise<void>;
  persistDocumentMemory: (params: {
    documentId: string;
    fileName: string;
    domain: WorkspaceDataDomain;
    periodKey: string;
    chunks: ChunkDraft[];
    records: ExtractedRecordDraft[];
  }) => Promise<void>;
  updateRecordVerification: (recordId: string, status: RecordVerificationStatus) => Promise<void>;
  deleteDocumentRecord: (docId: string, fileName?: string) => Promise<void>;

  saveForensicFindings: (
    drafts: Array<Omit<ForensicFinding, 'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'>>
  ) => Promise<number>;
  updateForensicStatus: (findingId: string, status: ForensicStatus) => Promise<void>;

  saveGrowthProposals: (
    drafts: Array<Omit<GrowthProposal, 'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'>>
  ) => Promise<number>;
  reviewGrowthProposal: (
    proposalId: string,
    status: Extract<GrowthProposalStatus, 'approved' | 'rejected' | 'implemented'>,
    approvalNote?: string
  ) => Promise<void>;

  logAuditEvent: (params: {
    action: AuditActionType;
    targetType: string;
    targetId: string;
    summary: string;
  }) => Promise<void>;

  createReportRecord: (params: {
    reportId: string;
    title: string;
    reportType: ReportType;
    specialistId: ActiveSpecialistId;
    conversationId?: string;
    documentIds?: string[];
    status: 'generating' | 'ready' | 'failed';
    content?: string;
    provider?: string;
  }) => Promise<void>;
  finalizeReportRecord: (
    reportId: string,
    updates: { status: 'ready' | 'failed'; content?: string; provider?: string }
  ) => Promise<void>;
  deleteReportRecord: (reportId: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function makeId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authVersion, setAuthVersion] = useState(0);
  const [authReady, setAuthReady] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [company, setCompany] = useState<CompanyProfile | null>(null);
  const [members, setMembers] = useState<CompanyMember[]>([]);
  const [pendingInvites, setPendingInvites] = useState<CompanyInvite[]>([]);
  const [companyInvites, setCompanyInvites] = useState<CompanyInvite[]>([]);
  const [documents, setDocuments] = useState<BusinessDocument[]>([]);
  const [structuredRecords, setStructuredRecords] = useState<StructuredBusinessRecord[]>([]);
  const [knowledgeChunks, setKnowledgeChunks] = useState<KnowledgeChunk[]>([]);
  const [forensicFindings, setForensicFindings] = useState<ForensicFinding[]>([]);
  const [growthProposals, setGrowthProposals] = useState<GrowthProposal[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [reports, setReports] = useState<EnterpriseReport[]>([]);
  const [usageLogs, setUsageLogs] = useState<UsageLog[]>([]);
  const [dataLoading, setDataLoading] = useState(false);

  // 1. Auth state listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
      if (!firebaseUser) {
        setUserProfile(null);
        setCompany(null);
        setMembers([]);
        setPendingInvites([]);
        setCompanyInvites([]);
        setDocuments([]);
        setStructuredRecords([]);
        setKnowledgeChunks([]);
        setForensicFindings([]);
        setGrowthProposals([]);
        setAuditLogs([]);
        setConversations([]);
        setReports([]);
        setUsageLogs([]);
      }
    });
    return () => unsub();
  }, []);

  // 2. Ensure /users/{uid} exists and listen to it
  useEffect(() => {
    if (!authReady || !user) return;
    const userPath = `users/${user.uid}`;
    const userRef = doc(db, 'users', user.uid);

    (async () => {
      try {
        const snap = await getDoc(userRef);
        if (!snap.exists()) {
          await setDoc(userRef, {
            uid: user.uid,
            email: (user.email || '').toLowerCase().slice(0, 254),
            displayName: (user.displayName || user.email?.split('@')[0] || 'Enterprise User').slice(0, 120),
            preferredLanguage: 'en',
            appearance: 'dark',
            emailNotifications: true,
            usageAlerts: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      } catch (err) {
        console.error('Failed to ensure user profile:', err);
      }
    })();

    const unsub = onSnapshot(
      userRef,
      (snap) => {
        if (snap.exists() && !snap.metadata.hasPendingWrites) {
          setUserProfile(snap.data() as UserProfile);
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, userPath)
    );
    return () => unsub();
  }, [authReady, user]);

  // 3. Listen to pending invites for verified email
  useEffect(() => {
    if (!authReady || !user || !user.emailVerified || !user.email) {
      setPendingInvites([]);
      return;
    }

    const q = query(
      collection(db, 'companyInvites'),
      where('email', '==', user.email.toLowerCase()),
      where('status', '==', 'pending')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        setPendingInvites(snap.docs.map((d) => d.data() as CompanyInvite));
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'companyInvites')
    );
    return () => unsub();
  }, [authReady, user, authVersion]);

  // 4. Listen to company & subcollections once user has verified email and companyId
  const companyId = userProfile?.companyId;
  useEffect(() => {
    if (!authReady || !user || !user.emailVerified || !companyId) {
      setCompany(null);
      setMembers([]);
      setCompanyInvites([]);
      setDocuments([]);
      setStructuredRecords([]);
      setKnowledgeChunks([]);
      setForensicFindings([]);
      setGrowthProposals([]);
      setAuditLogs([]);
      setConversations([]);
      setReports([]);
      setUsageLogs([]);
      return;
    }

    let cancelled = false;
    setDataLoading(true);
    const unsubs: Array<() => void> = [];

    (async () => {
      try {
        const memberRef = doc(db, 'companies', companyId, 'members', user.uid);
        const memberSnap = await getDocFromServer(memberRef);
        if (cancelled) return;

        if (!memberSnap.exists()) {
          setCompany(null);
          setMembers([]);
          setCompanyInvites([]);
          setDocuments([]);
          setStructuredRecords([]);
          setKnowledgeChunks([]);
          setForensicFindings([]);
          setGrowthProposals([]);
          setAuditLogs([]);
          setConversations([]);
          setReports([]);
          setUsageLogs([]);
          setDataLoading(false);
          return;
        }
      } catch (err) {
        if (cancelled) return;
        setCompany(null);
        setDataLoading(false);
        console.warn('Unable to verify company membership on server:', err);
        return;
      }

      if (cancelled) return;

      unsubs.push(
        onSnapshot(
          doc(db, 'companies', companyId),
          (snap) => {
            setCompany(snap.exists() ? (snap.data() as CompanyProfile) : null);
            setDataLoading(false);
          },
          (error) => {
            setDataLoading(false);
            handleFirestoreError(error, OperationType.GET, `companies/${companyId}`);
          }
        )
      );

      unsubs.push(
        onSnapshot(
          collection(db, 'companies', companyId, 'members'),
          (snap) => setMembers(snap.docs.map((d) => d.data() as CompanyMember)),
          (error) => handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/members`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companyInvites'), where('invitedBy', '==', user.uid)),
          (snap) => {
            const items = snap.docs
              .map((d) => d.data() as CompanyInvite)
              .filter((i) => i.companyId === companyId);
            setCompanyInvites(items);
          },
          (error) => handleFirestoreError(error, OperationType.LIST, 'companyInvites')
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'documents'), orderBy('createdAt', 'desc')),
          (snap) => setDocuments(snap.docs.map((d) => d.data() as BusinessDocument)),
          (error) => handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/documents`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'structuredRecords'), orderBy('createdAt', 'desc')),
          (snap) => setStructuredRecords(snap.docs.map((d) => d.data() as StructuredBusinessRecord)),
          (error) =>
            handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/structuredRecords`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'knowledgeChunks'), orderBy('createdAt', 'desc')),
          (snap) => setKnowledgeChunks(snap.docs.map((d) => d.data() as KnowledgeChunk)),
          (error) =>
            handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/knowledgeChunks`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'forensicFindings'), orderBy('createdAt', 'desc')),
          (snap) => setForensicFindings(snap.docs.map((d) => d.data() as ForensicFinding)),
          (error) =>
            handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/forensicFindings`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'growthProposals'), orderBy('createdAt', 'desc')),
          (snap) => setGrowthProposals(snap.docs.map((d) => d.data() as GrowthProposal)),
          (error) =>
            handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/growthProposals`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'auditLogs'), orderBy('createdAt', 'desc')),
          (snap) => setAuditLogs(snap.docs.map((d) => d.data() as AuditLogEntry)),
          (error) => handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/auditLogs`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'conversations'), orderBy('updatedAt', 'desc')),
          (snap) => setConversations(snap.docs.map((d) => d.data() as Conversation)),
          (error) =>
            handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/conversations`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'reports'), orderBy('createdAt', 'desc')),
          (snap) => setReports(snap.docs.map((d) => d.data() as EnterpriseReport)),
          (error) => handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/reports`)
        )
      );

      unsubs.push(
        onSnapshot(
          query(collection(db, 'companies', companyId, 'usageLogs'), orderBy('createdAt', 'desc')),
          (snap) => setUsageLogs(snap.docs.map((d) => d.data() as UsageLog)),
          (error) => handleFirestoreError(error, OperationType.LIST, `companies/${companyId}/usageLogs`)
        )
      );
    })();

    return () => {
      cancelled = true;
      unsubs.forEach((u) => u());
    };
  }, [authReady, user, authVersion, companyId]);

  const currentMember = useMemo(() => {
    if (!user) return null;
    return members.find((m) => m.uid === user.uid) ?? null;
  }, [members, user]);

  const permissions = useMemo(
    () => getPermissionsForRole(currentMember?.role),
    [currentMember?.role]
  );

  // Immutable Audit Log writer
  const logAuditEvent = async (params: {
    action: AuditActionType;
    targetType: string;
    targetId: string;
    summary: string;
  }) => {
    if (!user || !company) return;
    const logId = makeId('aud');
    try {
      await setDoc(doc(db, 'companies', company.id, 'auditLogs', logId), {
        id: logId,
        companyId: company.id,
        actorUid: user.uid,
        actorEmail: (user.email || 'user@egai').slice(0, 254),
        actorRole: currentMember?.role || 'analyst',
        action: params.action,
        targetType: params.targetType.slice(0, 64),
        targetId: params.targetId.slice(0, 128),
        summary: params.summary.slice(0, 500),
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Audit log write skipped:', err);
    }
  };

  // Auth Actions
  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  };

  const signInWithEmail = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email.trim(), password);
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    displayName: string,
    language: Language
  ) => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    const safeName = (displayName.trim() || 'Enterprise User').slice(0, 120);
    await updateProfile(cred.user, { displayName: safeName });
    await setDoc(doc(db, 'users', cred.user.uid), {
      uid: cred.user.uid,
      email: email.trim().toLowerCase().slice(0, 254),
      displayName: safeName,
      preferredLanguage: language,
      appearance: 'dark',
      emailNotifications: true,
      usageAlerts: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    await sendEmailVerification(cred.user);
  };

  const sendResetEmail = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const confirmResetPassword = async (oobCode: string, newPassword: string) => {
    await confirmPasswordReset(auth, oobCode, newPassword);
  };

  const applyEmailVerificationCode = async (oobCode: string) => {
    await applyActionCode(auth, oobCode);
    if (auth.currentUser) {
      await auth.currentUser.reload();
      await auth.currentUser.getIdToken(true);
      setUser(auth.currentUser);
      setAuthVersion((v) => v + 1);
    }
  };

  const resendVerificationEmail = async () => {
    if (!auth.currentUser) throw new Error('No active user session.');
    await sendEmailVerification(auth.currentUser);
  };

  const refreshAuthUser = async () => {
    if (!auth.currentUser) return false;
    await auth.currentUser.reload();
    await auth.currentUser.getIdToken(true);
    setUser(auth.currentUser);
    setAuthVersion((v) => v + 1);
    return auth.currentUser.emailVerified;
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
  };

  // Workspace Mutations
  const createCompanyWorkspace = async (input: {
    name: string;
    industry: string;
    size: CompanySize;
    country: string;
    preferredLanguage: Language;
  }) => {
    if (!user) throw new Error('Authentication required.');
    const newCompanyId = makeId('comp');
    const batch = writeBatch(db);

    const userRef = doc(db, 'users', user.uid);
    const existingUserSnap = await getDoc(userRef);
    const safeEmail = (user.email || '').toLowerCase().slice(0, 254);
    const safeDisplayName = (
      userProfile?.displayName ||
      user.displayName ||
      user.email ||
      'Owner'
    ).slice(0, 120);

    batch.set(doc(db, 'companies', newCompanyId), {
      id: newCompanyId,
      name: input.name.trim().slice(0, 140),
      industry: input.industry.trim().slice(0, 100),
      size: input.size,
      country: input.country.trim().slice(0, 100),
      preferredLanguage: input.preferredLanguage,
      ownerId: user.uid,
      planId: 'starter',
      monthlyTokenLimit: PLANS.starter.monthlyTokenLimit,
      monthlyRequestLimit: PLANS.starter.monthlyRequestLimit,
      retentionDays: 365,
      allowSharedModelTraining: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'companies', newCompanyId, 'members', user.uid), {
      uid: user.uid,
      companyId: newCompanyId,
      email: safeEmail,
      displayName: safeDisplayName,
      role: 'owner',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    if (existingUserSnap.exists()) {
      batch.update(userRef, {
        companyId: newCompanyId,
        preferredLanguage: input.preferredLanguage,
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.set(userRef, {
        uid: user.uid,
        email: safeEmail,
        displayName: safeDisplayName,
        preferredLanguage: input.preferredLanguage,
        companyId: newCompanyId,
        appearance: 'dark',
        emailNotifications: true,
        usageAlerts: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    try {
      await batch.commit();
      const updatedUserSnap = await getDocFromServer(userRef);
      if (updatedUserSnap.exists()) {
        setUserProfile(updatedUserSnap.data() as UserProfile);
      }
      return newCompanyId;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `companies/${newCompanyId}`);
    }
  };

  const acceptInvite = async (invite: CompanyInvite) => {
    if (!user) throw new Error('Authentication required.');
    const batch = writeBatch(db);
    const userRef = doc(db, 'users', user.uid);
    const existingUserSnap = await getDoc(userRef);
    const safeEmail = (user.email || '').toLowerCase().slice(0, 254);
    const safeDisplayName = (
      userProfile?.displayName ||
      user.displayName ||
      user.email ||
      'Member'
    ).slice(0, 120);

    batch.set(doc(db, 'companies', invite.companyId, 'members', user.uid), {
      uid: user.uid,
      companyId: invite.companyId,
      email: safeEmail,
      displayName: safeDisplayName,
      role: invite.role,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.update(doc(db, 'companyInvites', invite.id), {
      status: 'accepted',
      updatedAt: serverTimestamp(),
    });

    if (existingUserSnap.exists()) {
      batch.update(userRef, {
        companyId: invite.companyId,
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.set(userRef, {
        uid: user.uid,
        email: safeEmail,
        displayName: safeDisplayName,
        preferredLanguage: 'en',
        companyId: invite.companyId,
        appearance: 'dark',
        emailNotifications: true,
        usageAlerts: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    try {
      await batch.commit();
      const updatedUserSnap = await getDocFromServer(userRef);
      if (updatedUserSnap.exists()) {
        setUserProfile(updatedUserSnap.data() as UserProfile);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `companyInvites/${invite.id}`);
    }
  };

  const createInvite = async (email: string, role: Exclude<UserRole, 'owner'>) => {
    if (!user || !company) throw new Error('Company context required.');
    const inviteId = makeId('inv');
    const path = `companyInvites/${inviteId}`;
    try {
      await setDoc(doc(db, 'companyInvites', inviteId), {
        id: inviteId,
        companyId: company.id,
        companyName: company.name,
        email: email.trim().toLowerCase(),
        role,
        invitedBy: user.uid,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: 'member_invited',
        targetType: 'invite',
        targetId: inviteId,
        summary: `Invited ${email.trim().toLowerCase()} with role ${role}`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const revokeInvite = async (inviteId: string) => {
    const path = `companyInvites/${inviteId}`;
    try {
      await updateDoc(doc(db, 'companyInvites', inviteId), {
        status: 'revoked',
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const updateMemberRole = async (memberUid: string, role: Exclude<UserRole, 'owner'>) => {
    if (!company) return;
    const path = `companies/${company.id}/members/${memberUid}`;
    try {
      await updateDoc(doc(db, 'companies', company.id, 'members', memberUid), {
        role,
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: 'member_role_changed',
        targetType: 'member',
        targetId: memberUid,
        summary: `Updated member role to ${role}`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const removeCompanyMember = async (memberUid: string) => {
    if (!company) return;
    const path = `companies/${company.id}/members/${memberUid}`;
    try {
      await deleteDoc(doc(db, 'companies', company.id, 'members', memberUid));
      await logAuditEvent({
        action: 'member_removed',
        targetType: 'member',
        targetId: memberUid,
        summary: `Removed member ${memberUid} from workspace`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  const updateCompanyProfile = async (
    updates: Partial<Pick<CompanyProfile, 'name' | 'industry' | 'size' | 'country' | 'preferredLanguage' | 'logoUrl'>>
  ) => {
    if (!company) return;
    const path = `companies/${company.id}`;
    try {
      await updateDoc(doc(db, 'companies', company.id), {
        ...updates,
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: 'company_settings_updated',
        targetType: 'company',
        targetId: company.id,
        summary: `Updated company profile fields: ${Object.keys(updates).join(', ')}`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const updateCompanyGovernance = async (updates: {
    retentionDays?: number;
    companySummary?: string;
    strategicGoals?: string[];
    modelFocusData?: string;
  }) => {
    if (!company) return;
    const path = `companies/${company.id}`;
    const payload: Record<string, unknown> = {
      allowSharedModelTraining: false,
      updatedAt: serverTimestamp(),
    };
    if (typeof updates.retentionDays === 'number') {
      payload.retentionDays = Math.max(30, Math.min(3650, Math.round(updates.retentionDays)));
    }
    if (updates.companySummary !== undefined) {
      payload.companySummary = updates.companySummary.trim().slice(0, 4900);
    }
    if (updates.strategicGoals !== undefined) {
      payload.strategicGoals = updates.strategicGoals
        .map((g) => g.trim())
        .filter(Boolean)
        .slice(0, 20);
    }
    if (updates.modelFocusData !== undefined) {
      payload.modelFocusData = updates.modelFocusData.trim().slice(0, 8000);
    }
    try {
      await updateDoc(doc(db, 'companies', company.id), payload);
      await logAuditEvent({
        action: 'company_settings_updated',
        targetType: 'governance',
        targetId: company.id,
        summary: 'Updated company intelligence context, strategic goals, model focus data, or retention policy',
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const purgeCompanyWorkspaceData = async () => {
    if (!company || !user || currentMember?.role !== 'owner') {
      throw new Error('Only the Company Owner can purge workspace data.');
    }
    try {
      await updateDoc(doc(db, 'companies', company.id), {
        deletionRequestedAt: new Date().toISOString(),
        updatedAt: serverTimestamp(),
      });

      await companyApi.purgeStorage(company.id);

      const msgRefsToDelete = [];
      for (const conv of conversations) {
        const msgSnap = await getDocs(
          collection(db, 'companies', company.id, 'conversations', conv.id, 'messages')
        );
        for (const msgDoc of msgSnap.docs) {
          msgRefsToDelete.push(msgDoc.ref);
        }
      }

      const deletableRefs = [
        ...msgRefsToDelete,
        ...documents.map((d) => doc(db, 'companies', company.id, 'documents', d.id)),
        ...structuredRecords.map((r) => doc(db, 'companies', company.id, 'structuredRecords', r.id)),
        ...knowledgeChunks.map((k) => doc(db, 'companies', company.id, 'knowledgeChunks', k.id)),
        ...forensicFindings.map((f) => doc(db, 'companies', company.id, 'forensicFindings', f.id)),
        ...growthProposals.map((p) => doc(db, 'companies', company.id, 'growthProposals', p.id)),
        ...conversations.map((c) => doc(db, 'companies', company.id, 'conversations', c.id)),
        ...reports.map((r) => doc(db, 'companies', company.id, 'reports', r.id)),
      ];

      for (let i = 0; i < deletableRefs.length; i += 400) {
        const batch = writeBatch(db);
        for (const ref of deletableRefs.slice(i, i + 400)) {
          batch.delete(ref);
        }
        await batch.commit();
      }

      await logAuditEvent({
        action: 'company_purge_requested',
        targetType: 'company',
        targetId: company.id,
        summary: `Owner executed workspace data purge across ${deletableRefs.length} records and object storage`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `companies/${company.id}`);
    }
  };

  const updateUserSettings = async (
    updates: Partial<Pick<UserProfile, 'displayName' | 'preferredLanguage' | 'appearance' | 'emailNotifications' | 'usageAlerts'>>
  ) => {
    if (!user) return;
    const path = `users/${user.uid}`;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...updates,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  // Conversations & Messages
  const createConversation = async (
    title: string,
    specialistId: ActiveSpecialistId,
    documentIds: string[] = []
  ) => {
    if (!user || !company) throw new Error('Company workspace required.');
    const convId = makeId('conv');
    const path = `companies/${company.id}/conversations/${convId}`;
    try {
      await setDoc(doc(db, 'companies', company.id, 'conversations', convId), {
        id: convId,
        companyId: company.id,
        createdBy: user.uid,
        title: title.trim().slice(0, 200) || 'New Analysis',
        specialistId,
        documentIds,
        messageCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return convId;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const renameConversation = async (conversationId: string, title: string) => {
    if (!company) return;
    const path = `companies/${company.id}/conversations/${conversationId}`;
    try {
      await updateDoc(doc(db, 'companies', company.id, 'conversations', conversationId), {
        title: title.trim().slice(0, 200),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const updateConversationDocs = async (conversationId: string, documentIds: string[]) => {
    if (!company) return;
    const path = `companies/${company.id}/conversations/${conversationId}`;
    try {
      await updateDoc(doc(db, 'companies', company.id, 'conversations', conversationId), {
        documentIds: documentIds.slice(0, 20),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const deleteConversation = async (conversationId: string) => {
    if (!company) return;
    const path = `companies/${company.id}/conversations/${conversationId}`;
    try {
      const msgSnap = await getDocs(
        collection(db, 'companies', company.id, 'conversations', conversationId, 'messages')
      );
      if (!msgSnap.empty) {
        for (let i = 0; i < msgSnap.docs.length; i += 400) {
          const batch = writeBatch(db);
          for (const msgDoc of msgSnap.docs.slice(i, i + 400)) {
            batch.delete(msgDoc.ref);
          }
          await batch.commit();
        }
      }
      await deleteDoc(doc(db, 'companies', company.id, 'conversations', conversationId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  const saveMessage = async (params: {
    conversationId: string;
    role: 'user' | 'assistant';
    content: string;
    specialistId: ActiveSpecialistId;
    provider?: AIProviderName | 'user';
    model?: string;
    inputTokens?: number;
    outputTokens?: number;
    newMessageCount: number;
  }) => {
    if (!user || !company) throw new Error('Workspace required.');
    const msgId = makeId('msg');
    const path = `companies/${company.id}/conversations/${params.conversationId}/messages/${msgId}`;
    const batch = writeBatch(db);

    const payload: Record<string, unknown> = {
      id: msgId,
      conversationId: params.conversationId,
      companyId: company.id,
      senderId: user.uid,
      role: params.role,
      content: params.content.slice(0, 79000),
      specialistId: params.specialistId,
      provider: params.provider || (params.role === 'user' ? 'user' : 'gemini'),
      feedback: 'none',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (params.model) payload.model = params.model.slice(0, 120);
    if (typeof params.inputTokens === 'number') payload.inputTokens = params.inputTokens;
    if (typeof params.outputTokens === 'number') payload.outputTokens = params.outputTokens;

    batch.set(
      doc(db, 'companies', company.id, 'conversations', params.conversationId, 'messages', msgId),
      payload
    );
    batch.update(doc(db, 'companies', company.id, 'conversations', params.conversationId), {
      messageCount: params.newMessageCount,
      updatedAt: serverTimestamp(),
    });

    try {
      await batch.commit();
      return msgId;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const setMessageFeedback = async (
    conversationId: string,
    messageId: string,
    feedback: 'none' | 'up' | 'down'
  ) => {
    if (!company) return;
    const path = `companies/${company.id}/conversations/${conversationId}/messages/${messageId}`;
    try {
      await updateDoc(
        doc(db, 'companies', company.id, 'conversations', conversationId, 'messages', messageId),
        {
          feedback,
          updatedAt: serverTimestamp(),
        }
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  // Documents & Company Intelligence Memory
  const saveDocumentRecord = async (docData: Omit<BusinessDocument, 'createdAt' | 'updatedAt'>) => {
    if (!company) throw new Error('Company context required.');
    const path = `companies/${company.id}/documents/${docData.id}`;
    try {
      await setDoc(doc(db, 'companies', company.id, 'documents', docData.id), {
        ...docData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: 'document_uploaded',
        targetType: 'document',
        targetId: docData.id,
        summary: `Uploaded ${docData.fileName} (${docData.domain || 'finance'})`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const persistDocumentMemory = async (params: {
    documentId: string;
    fileName: string;
    domain: WorkspaceDataDomain;
    periodKey: string;
    chunks: ChunkDraft[];
    records: ExtractedRecordDraft[];
  }) => {
    if (!user || !company) throw new Error('Company context required.');
    const chunksSlice = params.chunks
      .slice(0, 24)
      .map((c) => sanitizeKnowledgeChunkDraft(c, params.fileName));
    const recordsSlice = params.records
      .slice(0, 40)
      .map((r) =>
        sanitizeStructuredRecordDraft(r, params.domain, params.periodKey, params.fileName)
      );
    const batch = writeBatch(db);

    for (const c of chunksSlice) {
      const chunkId = `${params.documentId}_chk_${c.chunkIndex}`;
      batch.set(doc(db, 'companies', company.id, 'knowledgeChunks', chunkId), {
        id: chunkId,
        companyId: company.id,
        documentId: params.documentId,
        documentName: params.fileName.slice(0, 255),
        domain: params.domain,
        periodKey: params.periodKey.slice(0, 32),
        chunkIndex: c.chunkIndex,
        locationLabel: c.locationLabel,
        content: c.content,
        keywords: c.keywords,
        createdAt: serverTimestamp(),
      });
    }

    recordsSlice.forEach((r, idx) => {
      const recId = `${params.documentId}_rec_${idx}`;
      batch.set(doc(db, 'companies', company.id, 'structuredRecords', recId), {
        id: recId,
        companyId: company.id,
        domain: r.domain,
        periodKey: r.periodKey,
        metricKey: r.metricKey,
        metricLabel: r.metricLabel,
        category: r.category,
        numericValue: r.numericValue,
        unit: r.unit,
        sourceDocumentId: params.documentId,
        sourceDocumentName: params.fileName.slice(0, 255),
        sourceLocation: r.sourceLocation,
        verificationStatus: 'pending_review',
        createdBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    batch.update(doc(db, 'companies', company.id, 'documents', params.documentId), {
      domain: params.domain,
      periodKey: params.periodKey.slice(0, 32),
      indexedChunkCount: chunksSlice.length,
      structuredRecordCount: recordsSlice.length,
      updatedAt: serverTimestamp(),
    });

    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `companies/${company.id}/documents/${params.documentId}`);
    }
  };

  const updateRecordVerification = async (recordId: string, status: RecordVerificationStatus) => {
    if (!user || !company) return;
    const path = `companies/${company.id}/structuredRecords/${recordId}`;
    try {
      await updateDoc(doc(db, 'companies', company.id, 'structuredRecords', recordId), {
        verificationStatus: status,
        verifiedBy: (user.email || user.uid).slice(0, 254),
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: status === 'disputed' ? 'record_disputed' : 'record_verified',
        targetType: 'structuredRecord',
        targetId: recordId,
        summary: `Marked extracted record ${recordId} as ${status}`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const deleteDocumentRecord = async (docId: string, fileName?: string) => {
    if (!company) return;
    const path = `companies/${company.id}/documents/${docId}`;
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'companies', company.id, 'documents', docId));
      for (const chk of knowledgeChunks.filter((c) => c.documentId === docId)) {
        batch.delete(doc(db, 'companies', company.id, 'knowledgeChunks', chk.id));
      }
      for (const rec of structuredRecords.filter((r) => r.sourceDocumentId === docId)) {
        batch.delete(doc(db, 'companies', company.id, 'structuredRecords', rec.id));
      }
      await batch.commit();
      await logAuditEvent({
        action: 'document_deleted',
        targetType: 'document',
        targetId: docId,
        summary: `Deleted document ${fileName || docId} and its indexed memory records`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  // Financial Forensics
  const saveForensicFindings = async (
    drafts: Array<Omit<ForensicFinding, 'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'>>
  ) => {
    if (!user || !company) throw new Error('Company context required.');
    const limited = drafts.slice(0, 20).map((d) => sanitizeForensicFindingDraft(d));
    const batch = writeBatch(db);
    for (const d of limited) {
      const id = makeId('for');
      batch.set(doc(db, 'companies', company.id, 'forensicFindings', id), {
        ...d,
        id,
        companyId: company.id,
        createdBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    try {
      await batch.commit();
      await logAuditEvent({
        action: 'forensics_scan',
        targetType: 'forensicFindings',
        targetId: company.id,
        summary: `Executed Financial Forensics scan (${limited.length} findings generated)`,
      });
      return limited.length;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `companies/${company.id}/forensicFindings`);
    }
  };

  const updateForensicStatus = async (findingId: string, status: ForensicStatus) => {
    if (!user || !company) return;
    const path = `companies/${company.id}/forensicFindings/${findingId}`;
    try {
      await updateDoc(doc(db, 'companies', company.id, 'forensicFindings', findingId), {
        status,
        reviewedBy: (user.email || user.uid).slice(0, 254),
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: 'forensic_status_updated',
        targetType: 'forensicFinding',
        targetId: findingId,
        summary: `Updated forensic finding ${findingId} status to ${status}`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  // Business Growth Advisor (Mandatory Management Approval Gate)
  const saveGrowthProposals = async (
    drafts: Array<Omit<GrowthProposal, 'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'>>
  ) => {
    if (!user || !company) throw new Error('Company context required.');
    const limited = drafts.slice(0, 12).map((d) => sanitizeGrowthProposalDraft(d));
    const batch = writeBatch(db);
    for (const d of limited) {
      const id = makeId('prop');
      batch.set(doc(db, 'companies', company.id, 'growthProposals', id), {
        ...d,
        id,
        companyId: company.id,
        requiresManagementApproval: true,
        status: 'pending_approval',
        createdBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    try {
      await batch.commit();
      await logAuditEvent({
        action: 'proposal_generated',
        targetType: 'growthProposals',
        targetId: company.id,
        summary: `Generated ${limited.length} growth proposals (pending management approval)`,
      });
      return limited.length;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `companies/${company.id}/growthProposals`);
    }
  };

  const reviewGrowthProposal = async (
    proposalId: string,
    status: Extract<GrowthProposalStatus, 'approved' | 'rejected' | 'implemented'>,
    approvalNote = ''
  ) => {
    if (!user || !company) return;
    const path = `companies/${company.id}/growthProposals/${proposalId}`;
    try {
      await updateDoc(doc(db, 'companies', company.id, 'growthProposals', proposalId), {
        status,
        approvedBy: user.uid,
        approvedByEmail: (user.email || '').slice(0, 254),
        approvalNote: approvalNote.trim().slice(0, 1000),
        updatedAt: serverTimestamp(),
      });
      await logAuditEvent({
        action: status === 'rejected' ? 'proposal_rejected' : 'proposal_approved',
        targetType: 'growthProposal',
        targetId: proposalId,
        summary: `Management marked proposal ${proposalId} as ${status}`,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  // Reports
  const createReportRecord = async (params: {
    reportId: string;
    title: string;
    reportType: ReportType;
    specialistId: ActiveSpecialistId;
    conversationId?: string;
    documentIds?: string[];
    status: 'generating' | 'ready' | 'failed';
    content?: string;
    provider?: string;
  }) => {
    if (!user || !company) throw new Error('Company context required.');
    const path = `companies/${company.id}/reports/${params.reportId}`;
    const payload: Record<string, unknown> = {
      id: params.reportId,
      companyId: company.id,
      createdBy: user.uid,
      title: params.title.slice(0, 200),
      reportType: params.reportType,
      specialistId: params.specialistId,
      documentIds: params.documentIds || [],
      status: params.status,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (params.conversationId) payload.conversationId = params.conversationId;
    if (params.content) payload.content = params.content.slice(0, 149000);
    if (params.provider) payload.provider = params.provider;

    try {
      await setDoc(doc(db, 'companies', company.id, 'reports', params.reportId), payload);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const finalizeReportRecord = async (
    reportId: string,
    updates: { status: 'ready' | 'failed'; content?: string; provider?: string }
  ) => {
    if (!company) return;
    const path = `companies/${company.id}/reports/${reportId}`;
    const payload: Record<string, unknown> = {
      status: updates.status,
      updatedAt: serverTimestamp(),
    };
    if (updates.content !== undefined) payload.content = updates.content.slice(0, 149000);
    if (updates.provider !== undefined) payload.provider = updates.provider;

    try {
      await updateDoc(doc(db, 'companies', company.id, 'reports', reportId), payload);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const deleteReportRecord = async (reportId: string) => {
    if (!company) return;
    const path = `companies/${company.id}/reports/${reportId}`;
    try {
      await deleteDoc(doc(db, 'companies', company.id, 'reports', reportId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        authReady,
        userProfile,
        company,
        currentMember,
        permissions,
        pendingInvites,
        members,
        companyInvites,
        documents,
        structuredRecords,
        knowledgeChunks,
        forensicFindings,
        growthProposals,
        auditLogs,
        conversations,
        reports,
        usageLogs,
        dataLoading,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        sendResetEmail,
        confirmResetPassword,
        applyEmailVerificationCode,
        resendVerificationEmail,
        refreshAuthUser,
        signOut,
        createCompanyWorkspace,
        acceptInvite,
        createInvite,
        revokeInvite,
        updateMemberRole,
        removeCompanyMember,
        updateCompanyProfile,
        updateCompanyGovernance,
        purgeCompanyWorkspaceData,
        updateUserSettings,
        createConversation,
        renameConversation,
        updateConversationDocs,
        deleteConversation,
        saveMessage,
        setMessageFeedback,
        saveDocumentRecord,
        persistDocumentMemory,
        updateRecordVerification,
        deleteDocumentRecord,
        saveForensicFindings,
        updateForensicStatus,
        saveGrowthProposals,
        reviewGrowthProposal,
        logAuditEvent,
        createReportRecord,
        finalizeReportRecord,
        deleteReportRecord,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export function subscribeConversationMessages(
  companyId: string,
  conversationId: string,
  onData: (messages: ChatMessage[]) => void
) {
  const q = query(
    collection(db, 'companies', companyId, 'conversations', conversationId, 'messages'),
    orderBy('createdAt', 'asc')
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as ChatMessage));
    },
    (error) =>
      handleFirestoreError(
        error,
        OperationType.LIST,
        `companies/${companyId}/conversations/${conversationId}/messages`
      )
  );
}
