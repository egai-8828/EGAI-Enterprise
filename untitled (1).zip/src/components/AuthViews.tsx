import React, { useEffect, useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, Globe, MailCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { BrandLogo } from './BrandMark';

export type AuthMode = 'signin' | 'signup' | 'forgot' | 'reset' | 'verify';

interface AuthViewsProps {
  mode: AuthMode;
  oobCode?: string | null;
  onNavigate: (path: string) => void;
}

export function AuthViews({ mode, oobCode, onNavigate }: AuthViewsProps) {
  const {
    user,
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    sendResetEmail,
    confirmResetPassword,
    applyEmailVerificationCode,
    resendVerificationEmail,
    refreshAuthUser,
    signOut,
  } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showEmailConsoleHelp, setShowEmailConsoleHelp] = useState(false);

  const handledOobCodeRef = useRef<string | null>(null);

  // Handle Firebase email verification action code automatically if provided in URL
  useEffect(() => {
    if (mode === 'verify' && oobCode && handledOobCodeRef.current !== oobCode) {
      handledOobCodeRef.current = oobCode;
      setBusy(true);
      applyEmailVerificationCode(oobCode)
        .then(() => {
          setSuccess(
            language === 'ar'
              ? 'تم تأكيد بريدك الإلكتروني بنجاح.'
              : 'Your email address has been verified.'
          );
        })
        .catch((err) => {
          setError(err instanceof Error ? err.message : 'Verification link invalid or expired.');
        })
        .finally(() => setBusy(false));
    }
  }, [mode, oobCode, applyEmailVerificationCode, language]);

  const formatFirebaseError = (err: unknown): string => {
    const raw = err instanceof Error ? err.message : String(err);
    if (raw.includes('auth/operation-not-allowed')) {
      setShowEmailConsoleHelp(true);
      return language === 'ar'
        ? 'مزود البريد الإلكتروني وكلمة المرور غير مفعل بعد في Firebase Console.'
        : 'Email/Password sign-in provider is not yet enabled in Firebase Console.';
    }
    if (raw.includes('auth/invalid-credential') || raw.includes('auth/wrong-password')) {
      return language === 'ar'
        ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'
        : 'Invalid email or password.';
    }
    if (raw.includes('auth/email-already-in-use')) {
      return language === 'ar'
        ? 'هذا البريد الإلكتروني مسجل بالفعل.'
        : 'An account with this email already exists.';
    }
    if (raw.includes('auth/weak-password')) {
      return language === 'ar'
        ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.'
        : 'Password must be at least 6 characters.';
    }
    if (raw.includes('auth/popup-closed-by-user')) {
      return language === 'ar' ? 'تم إغلاق نافذة تسجيل الدخول.' : 'Sign-in popup was closed.';
    }
    return raw;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (mode === 'signin') {
      if (!email.trim() || !password) {
        setError(language === 'ar' ? 'يرجى إدخال البريد وكلمة المرور.' : 'Email and password are required.');
        return;
      }
      setBusy(true);
      try {
        await signInWithEmail(email, password);
      } catch (err) {
        setError(formatFirebaseError(err));
      } finally {
        setBusy(false);
      }
    } else if (mode === 'signup') {
      if (!displayName.trim() || !email.trim() || password.length < 6) {
        setError(
          language === 'ar'
            ? 'يرجى إدخال الاسم والبريد وكلمة مرور من 6 أحرف على الأقل.'
            : 'Enter your full name, valid work email, and a password of at least 6 characters.'
        );
        return;
      }
      if (password !== confirmPassword) {
        setError(language === 'ar' ? 'كلمتا المرور غير متطابقتين.' : 'Passwords do not match.');
        return;
      }
      setBusy(true);
      try {
        await signUpWithEmail(email, password, displayName, language);
        onNavigate('/auth/verify-email');
      } catch (err) {
        setError(formatFirebaseError(err));
      } finally {
        setBusy(false);
      }
    } else if (mode === 'forgot') {
      if (!email.trim()) {
        setError(language === 'ar' ? 'يرجى إدخال البريد الإلكتروني.' : 'Please enter your email address.');
        return;
      }
      setBusy(true);
      try {
        await sendResetEmail(email);
        setSuccess(
          language === 'ar'
            ? 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.'
            : 'Password reset link sent to your email address.'
        );
      } catch (err) {
        setError(formatFirebaseError(err));
      } finally {
        setBusy(false);
      }
    } else if (mode === 'reset') {
      if (!oobCode) {
        setError(language === 'ar' ? 'رمز إعادة التعيين غير موجود.' : 'Missing password reset code.');
        return;
      }
      if (password.length < 6 || password !== confirmPassword) {
        setError(
          language === 'ar'
            ? 'تأكد من تطابق كلمة المرور وأنها لا تقل عن 6 أحرف.'
            : 'Passwords must match and be at least 6 characters.'
        );
        return;
      }
      setBusy(true);
      try {
        await confirmResetPassword(oobCode, password);
        setSuccess(
          language === 'ar'
            ? 'تم تحديث كلمة المرور. يمكنك الآن تسجيل الدخول.'
            : 'Password updated. You can now sign in.'
        );
      } catch (err) {
        setError(formatFirebaseError(err));
      } finally {
        setBusy(false);
      }
    }
  };

  const handleGoogle = async () => {
    setError(null);
    setBusy(true);
    try {
      await signInWithGoogle();
    } catch (err) {
      setError(formatFirebaseError(err));
    } finally {
      setBusy(false);
    }
  };

  const handleRefreshVerify = async () => {
    setBusy(true);
    setError(null);
    try {
      const verified = await refreshAuthUser();
      if (!verified) {
        setError(
          language === 'ar'
            ? 'لم يتم تأكيد البريد الإلكتروني بعد. افتح الرابط المرسل لبريدك ثم حاول مجدداً.'
            : 'Email is not verified yet. Click the link in your inbox, then retry.'
        );
      }
    } catch (err) {
      setError(formatFirebaseError(err));
    } finally {
      setBusy(false);
    }
  };

  const handleResend = async () => {
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      await resendVerificationEmail();
      setSuccess(
        language === 'ar'
          ? 'تم إعادة إرسال رسالة التأكيد.'
          : 'Verification email resent.'
      );
    } catch (err) {
      setError(formatFirebaseError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D18] text-[#F8FAFC] flex flex-col">
      <header className="border-b border-slate-800/80 px-4 sm:px-8 py-4 flex items-center justify-between">
        <button type="button" onClick={() => onNavigate('/')} className="focus-visible:outline-none">
          <BrandLogo />
        </button>
        <button
          type="button"
          onClick={toggleLanguage}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-[#111827] px-3 py-2 text-xs font-medium text-[#F8FAFC]"
        >
          <Globe size={14} className="text-[#38BDF8]" />
          <span>{language === 'en' ? 'العربية' : 'English'}</span>
        </button>
      </header>

      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md rounded-xl border border-slate-800 bg-[#151E2E] p-6 sm:p-8">
          {mode === 'verify' ? (
            <div className="space-y-5">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-[#1D4ED8]/20 text-[#38BDF8]">
                <MailCheck size={22} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-[#F8FAFC]">{t.auth.verifyTitle}</h1>
                <p className="mt-1.5 text-sm text-[#94A3B8]">{t.auth.verifySubtitle}</p>
                {user?.email && (
                  <p className="mt-2 font-mono text-xs text-[#38BDF8]">{user.email}</p>
                )}
              </div>

              {error && (
                <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-[#FCA5A5]">
                  <AlertCircle size={15} className="shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}
              {success && (
                <div className="flex items-start gap-2 rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3 text-xs text-[#86EFAC]">
                  <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
                  <span>{success}</span>
                </div>
              )}

              <div className="space-y-2.5">
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleRefreshVerify}
                  className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
                >
                  {t.auth.refreshVerifyBtn}
                </button>
                {user && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleResend}
                    className="w-full rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 disabled:opacity-50"
                  >
                    {t.auth.resendVerifyBtn}
                  </button>
                )}
                {user ? (
                  <button
                    type="button"
                    onClick={() => signOut()}
                    className="w-full text-center text-xs text-[#94A3B8] hover:text-[#F8FAFC] pt-2"
                  >
                    {t.auth.signOutBtn}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => onNavigate('/auth/signin')}
                    className="w-full text-center text-xs text-[#38BDF8] hover:underline pt-2"
                  >
                    {t.auth.backToSignIn}
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <h1 className="text-xl font-bold text-[#F8FAFC]">
                  {mode === 'signin'
                    ? t.auth.signInTitle
                    : mode === 'signup'
                    ? t.auth.signUpTitle
                    : mode === 'forgot'
                    ? t.auth.forgotTitle
                    : t.auth.resetTitle}
                </h1>
                <p className="mt-1 text-sm text-[#94A3B8]">
                  {mode === 'signin'
                    ? t.auth.signInSubtitle
                    : mode === 'signup'
                    ? t.auth.signUpSubtitle
                    : mode === 'forgot'
                    ? t.auth.forgotSubtitle
                    : t.auth.resetSubtitle}
                </p>
              </div>

              {(mode === 'signin' || mode === 'signup') && (
                <>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleGoogle}
                    className="w-full flex items-center justify-center gap-2.5 rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:border-slate-600 transition-colors disabled:opacity-50"
                  >
                    <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="#EA4335"
                        d="M12 10.2v3.9h5.5c-.2 1.3-1.5 3.9-5.5 3.9-3.3 0-6-2.7-6-6s2.7-6 6-6c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.7 3.4 14.5 2.5 12 2.5 6.8 2.5 2.5 6.8 2.5 12s4.3 9.5 9.5 9.5c5.5 0 9.1-3.9 9.1-9.3 0-.6-.1-1.1-.2-1.6H12z"
                      />
                    </svg>
                    <span>{t.auth.googleBtn}</span>
                  </button>

                  <div className="relative flex items-center py-1">
                    <div className="flex-grow border-t border-slate-800" />
                    <span className="mx-3 text-xs text-[#94A3B8]">
                      {language === 'ar' ? 'أو' : 'or'}
                    </span>
                    <div className="flex-grow border-t border-slate-800" />
                  </div>
                </>
              )}

              {error && (
                <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-[#FCA5A5]">
                  <AlertCircle size={15} className="shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {showEmailConsoleHelp && (
                <div className="rounded-lg border border-[#F59E0B]/40 bg-[#F59E0B]/10 p-3 text-xs text-[#FDE68A] space-y-1">
                  <p className="font-semibold">{t.auth.emailProviderHintTitle}</p>
                  <p>{t.auth.emailProviderHintBody}</p>
                </div>
              )}

              {success && (
                <div className="flex items-start gap-2 rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3 text-xs text-[#86EFAC]">
                  <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
                  <span>{success}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'signup' && (
                  <div>
                    <label htmlFor="auth-name" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                      {t.auth.fullNameLabel}
                    </label>
                    <input
                      id="auth-name"
                      type="text"
                      required
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                    />
                  </div>
                )}

                {mode !== 'reset' && (
                  <div>
                    <label htmlFor="auth-email" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                      {t.auth.emailLabel}
                    </label>
                    <input
                      id="auth-email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                    />
                  </div>
                )}

                {(mode === 'signin' || mode === 'signup' || mode === 'reset') && (
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label htmlFor="auth-password" className="block text-xs font-medium text-[#CBD5E1]">
                        {t.auth.passwordLabel}
                      </label>
                      {mode === 'signin' && (
                        <button
                          type="button"
                          onClick={() => onNavigate('/auth/forgot-password')}
                          className="text-xs text-[#38BDF8] hover:underline"
                        >
                          {t.auth.forgotLink}
                        </button>
                      )}
                    </div>
                    <input
                      id="auth-password"
                      type="password"
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                    />
                  </div>
                )}

                {(mode === 'signup' || mode === 'reset') && (
                  <div>
                    <label htmlFor="auth-confirm" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                      {t.auth.confirmPasswordLabel}
                    </label>
                    <input
                      id="auth-confirm"
                      type="password"
                      required
                      minLength={6}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={busy}
                  className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] transition-colors disabled:opacity-50"
                >
                  {busy
                    ? language === 'ar'
                      ? 'جاري التنفيذ...'
                      : 'Processing...'
                    : mode === 'signin'
                    ? t.auth.signInBtn
                    : mode === 'signup'
                    ? t.auth.signUpBtn
                    : mode === 'forgot'
                    ? t.auth.sendResetBtn
                    : t.auth.confirmResetBtn}
                </button>
              </form>

              <div className="pt-2 border-t border-slate-800 text-center text-xs text-[#94A3B8]">
                {mode === 'signin' ? (
                  <>
                    <span>{t.auth.noAccount} </span>
                    <button
                      type="button"
                      onClick={() => onNavigate('/auth/signup')}
                      className="font-semibold text-[#38BDF8] hover:underline"
                    >
                      {t.nav.getStarted}
                    </button>
                  </>
                ) : mode === 'signup' ? (
                  <>
                    <span>{t.auth.hasAccount} </span>
                    <button
                      type="button"
                      onClick={() => onNavigate('/auth/signin')}
                      className="font-semibold text-[#38BDF8] hover:underline"
                    >
                      {t.auth.signInBtn}
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => onNavigate('/auth/signin')}
                    className="font-semibold text-[#38BDF8] hover:underline"
                  >
                    {t.auth.backToSignIn}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
