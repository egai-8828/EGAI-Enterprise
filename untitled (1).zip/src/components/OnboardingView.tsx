import React, { useState } from 'react';
import { Building2, LogOut, UserCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import type { CompanySize, Language } from '../shared/types';
import { BrandLogo } from './BrandMark';

export function OnboardingView() {
  const { user, pendingInvites, createCompanyWorkspace, acceptInvite, signOut } = useAuth();
  const { language, t } = useLanguage();

  const [name, setName] = useState('');
  const [industry, setIndustry] = useState('');
  const [size, setSize] = useState<CompanySize>('11-50');
  const [country, setCountry] = useState('');
  const [preferredLanguage, setPreferredLanguage] = useState<Language>(language);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (name.trim().length < 2 || industry.trim().length < 2 || country.trim().length < 2) {
      setError(
        language === 'ar'
          ? 'يرجى إدخال اسم الشركة والقطاع والدولة.'
          : 'Please enter your company name, industry, and country.'
      );
      return;
    }
    setBusy(true);
    try {
      await createCompanyWorkspace({
        name,
        industry,
        size,
        country,
        preferredLanguage,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create workspace');
    } finally {
      setBusy(false);
    }
  };

  const handleAcceptInvite = async (invite: (typeof pendingInvites)[number]) => {
    setError(null);
    setBusy(true);
    try {
      await acceptInvite(invite);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to accept workspace invite');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D18] text-[#F8FAFC] flex flex-col">
      <header className="border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <BrandLogo />
        <div className="flex items-center gap-4 text-xs">
          <span className="text-[#94A3B8] hidden sm:inline">{user?.email}</span>
          <button
            type="button"
            onClick={() => signOut()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-[#111827] px-3 py-2 text-[#F8FAFC] hover:border-slate-700"
          >
            <LogOut size={14} />
            <span>{t.auth.signOutBtn}</span>
          </button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-xl space-y-6">
          {pendingInvites.length > 0 && (
            <div className="rounded-xl border border-[#1D4ED8]/60 bg-[#151E2E] p-6 space-y-4">
              <div className="flex items-center gap-2.5 text-[#38BDF8]">
                <UserCheck size={18} />
                <h2 className="text-base font-semibold text-[#F8FAFC]">
                  {t.onboarding.pendingInvitesTitle}
                </h2>
              </div>
              <div className="space-y-3">
                {pendingInvites.map((invite) => (
                  <div
                    key={invite.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-800 bg-[#090D18] p-4"
                  >
                    <div>
                      <p className="text-sm font-semibold text-[#F8FAFC]">{invite.companyName}</p>
                      <p className="text-xs text-[#94A3B8]">
                        {invite.role} · {invite.email}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleAcceptInvite(invite)}
                      className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
                    >
                      {t.onboarding.acceptInviteBtn}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-6 sm:p-8">
            <div className="flex items-center gap-2.5 text-[#38BDF8]">
              <Building2 size={20} />
              <h1 className="text-xl font-bold text-[#F8FAFC]">{t.onboarding.title}</h1>
            </div>
            <p className="mt-1.5 text-sm text-[#94A3B8]">{t.onboarding.subtitle}</p>

            {error && (
              <div className="mt-4 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-[#FCA5A5]">
                {error}
              </div>
            )}

            <form onSubmit={handleCreate} className="mt-6 space-y-4">
              <div>
                <label htmlFor="co-name" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                  {t.onboarding.companyName}
                </label>
                <input
                  id="co-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="co-industry" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                    {t.onboarding.industry}
                  </label>
                  <input
                    id="co-industry"
                    type="text"
                    required
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                    className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="co-country" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                    {t.onboarding.country}
                  </label>
                  <input
                    id="co-country"
                    type="text"
                    required
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="co-size" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                    {t.onboarding.companySize}
                  </label>
                  <select
                    id="co-size"
                    value={size}
                    onChange={(e) => setSize(e.target.value as CompanySize)}
                    className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                  >
                    <option value="1-10">1-10</option>
                    <option value="11-50">11-50</option>
                    <option value="51-200">51-200</option>
                    <option value="201-1000">201-1000</option>
                    <option value="1000+">1000+</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="co-lang" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                    {t.onboarding.preferredLanguage}
                  </label>
                  <select
                    id="co-lang"
                    value={preferredLanguage}
                    onChange={(e) => setPreferredLanguage(e.target.value as Language)}
                    className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                  >
                    <option value="en">English (LTR)</option>
                    <option value="ar">العربية (RTL)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-lg bg-[#1D4ED8] px-4 py-3 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] transition-colors disabled:opacity-50"
              >
                {busy
                  ? language === 'ar'
                    ? 'جاري الإنشاء...'
                    : 'Creating Workspace...'
                  : t.onboarding.createCompanyBtn}
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}
