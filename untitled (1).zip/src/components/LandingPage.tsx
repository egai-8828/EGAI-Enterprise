import { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  FileSpreadsheet,
  FileText,
  Globe,
  Lock,
  Menu,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { SPECIALISTS } from '../shared/specialists';
import { BrandLogo, SpecialistIcon } from './BrandMark';

interface LandingPageProps {
  onNavigate: (path: string) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  const { language, dir, toggleLanguage, t } = useLanguage();
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [previewTab, setPreviewTab] = useState<'finance' | 'bi' | 'docs'>('finance');

  const ArrowIcon = dir === 'rtl' ? ArrowLeft : ArrowRight;

  return (
    <div className="min-h-screen bg-[#090D18] text-[#F8FAFC]">
      {/* Top Bar Contract: 3 zones (Brand | Nav Links | Actions) */}
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#090D18]/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6 lg:px-8">
          <a href="#top" className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#38BDF8] rounded">
            <BrandLogo />
          </a>

          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#94A3B8]">
            <a href="#product" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
              {t.nav.product}
            </a>
            <a href="#specialists" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
              {t.nav.specialists}
            </a>
            <a href="#about" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
              {t.nav.about}
            </a>
          </nav>

          <div className="hidden lg:flex items-center gap-4 shrink-0">
            <button
              type="button"
              onClick={toggleLanguage}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-[#111827] px-3 py-2 text-xs font-medium text-[#F8FAFC] hover:border-slate-700 transition-colors whitespace-nowrap shrink-0"
              aria-label="Switch Language"
            >
              <Globe size={14} className="text-[#38BDF8]" />
              <span>{language === 'en' ? 'العربية' : 'English'}</span>
            </button>

            {user ? (
              <button
                type="button"
                onClick={() => onNavigate('/app/overview')}
                className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
              >
                {t.nav.openWorkspace}
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => onNavigate('/auth/signin')}
                  className="px-2 py-2 text-sm font-medium text-[#94A3B8] hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0"
                >
                  {t.nav.signIn}
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('/auth/signup')}
                  className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
                >
                  {t.nav.getStarted}
                </button>
              </>
            )}
          </div>

          {/* Mobile controls */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              type="button"
              onClick={toggleLanguage}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-800 bg-[#111827] px-2.5 py-2 text-xs font-medium text-[#F8FAFC]"
              aria-label="Switch Language (Mobile)"
            >
              <Globe size={14} className="text-[#38BDF8]" />
              <span>{language === 'en' ? 'AR' : 'EN'}</span>
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-800 bg-[#111827] text-[#F8FAFC]"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 bg-[#111827] px-4 py-4 space-y-3">
            <div className="flex flex-col space-y-2 text-sm font-medium text-[#94A3B8]">
              <a href="#product" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#F8FAFC]">{t.nav.product}</a>
              <a href="#specialists" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#F8FAFC]">{t.nav.specialists}</a>
              <a href="#about" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#F8FAFC]">{t.nav.about}</a>
            </div>
            <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
              {user ? (
                <button
                  type="button"
                  onClick={() => onNavigate('/app/overview')}
                  className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC]"
                >
                  {t.nav.openWorkspace}
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => onNavigate('/auth/signin')}
                    className="w-full rounded-lg border border-slate-700 px-4 py-2.5 text-sm font-medium text-[#F8FAFC]"
                  >
                    {t.nav.signIn}
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('/auth/signup')}
                    className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC]"
                  >
                    {t.nav.getStarted}
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </header>

      <main id="top">
        {/* 1. HERO SECTION */}
        <section className="border-b border-slate-800/80 bg-[#090D18]">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
            <div className="mx-auto max-w-3xl text-center">
              <p className="text-xs font-semibold tracking-wider text-[#38BDF8] uppercase">
                {t.hero.eyebrow}
              </p>
              <h1
                className="mt-4 font-bold tracking-tight text-[#F8FAFC] text-balance"
                style={{ fontSize: 'clamp(2.15rem, 4.2vw, 3.5rem)', lineHeight: 1.15 }}
              >
                {t.hero.headline}
              </h1>
              <p className="mt-5 text-base sm:text-lg text-[#94A3B8] leading-relaxed max-w-2xl mx-auto">
                {t.hero.description}
              </p>

              <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate(user ? '/app/overview' : '/auth/signup')}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-6 py-3 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] transition-colors whitespace-nowrap"
                >
                  <span>{t.hero.primaryCta}</span>
                  <ArrowIcon size={16} />
                </button>
                <a
                  href="#product"
                  className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#111827] px-6 py-3 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 transition-colors whitespace-nowrap"
                >
                  {t.hero.secondaryCta}
                </a>
              </div>
            </div>

            {/* Interactive Enterprise Dashboard Preview Frame */}
            <div className="mt-14 rounded-xl border border-slate-800 bg-[#111827] overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 bg-[#151E2E] px-4 py-3">
                <div className="flex items-center gap-2 text-xs text-[#94A3B8]">
                  <span className="font-semibold text-[#F8FAFC]">EGAI Workspace</span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {language === 'en'
                      ? 'Interactive platform preview'
                      : 'معاينة تفاعلية لواجهة المنصة'}
                  </span>
                </div>
                <div className="flex items-center gap-1 rounded-lg bg-[#090D18] p-1 border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setPreviewTab('finance')}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                      previewTab === 'finance'
                        ? 'bg-[#1D4ED8] text-[#F8FAFC]'
                        : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {language === 'en' ? 'Finance Specialist' : 'أخصائي المالية'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewTab('bi')}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                      previewTab === 'bi'
                        ? 'bg-[#1D4ED8] text-[#F8FAFC]'
                        : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {language === 'en' ? 'BI Analytics' : 'ذكاء الأعمال'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewTab('docs')}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                      previewTab === 'docs'
                        ? 'bg-[#1D4ED8] text-[#F8FAFC]'
                        : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {language === 'en' ? 'Document Pipeline' : 'معالجة المستندات'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12">
                {/* Mock Sidebar Navigation inside preview */}
                <div className="hidden lg:block lg:col-span-3 border-e border-slate-800 bg-[#090D18] p-4 space-y-1.5 text-xs">
                  {[
                    t.sidebar.intelligence,
                    t.sidebar.workspace,
                    t.sidebar.overview,
                    t.sidebar.forensics,
                    t.sidebar.advisor,
                    t.sidebar.documents,
                    t.sidebar.team,
                  ].map((label, idx) => (
                    <div
                      key={label}
                      className={`rounded-md px-3 py-2 font-medium ${
                        (previewTab === 'finance' && idx === 1) ||
                        (previewTab === 'bi' && idx === 2) ||
                        (previewTab === 'docs' && idx === 5)
                          ? 'bg-[#151E2E] text-[#F8FAFC] border border-slate-800'
                          : 'text-[#94A3B8]'
                      }`}
                    >
                      {label}
                    </div>
                  ))}
                </div>

                {/* Preview Viewport */}
                <div className="lg:col-span-9 p-5 sm:p-6 bg-[#090D18]/60">
                  {previewTab === 'finance' && (
                    <div className="space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-2">
                          <SpecialistIcon iconName="Landmark" color="#1D4ED8" size={18} />
                          <span className="text-sm font-semibold text-[#F8FAFC]">
                            {language === 'en'
                              ? 'Finance Specialist · Source-Grounded Analysis'
                              : 'أخصائي المالية · تحليل موثق بالمصادر'}
                          </span>
                        </div>
                        <span className="text-xs font-mono text-[#94A3B8]">
                          PDF / XLSX / CSV
                        </span>
                      </div>
                      <div className="space-y-4 text-sm">
                        <p className="text-xs font-medium text-[#38BDF8]">
                          {language === 'en' ? 'Workflow Example: Margin & Ratio Verification' : 'نموذج سير العمل: التحقق من الهوامش والنسب'}
                        </p>
                        <p className="text-[#CBD5E1] leading-relaxed">
                          {language === 'en'
                            ? 'When a financial statement is uploaded, the Finance Specialist extracts line items with page citations, verifies formulas step-by-step, separates actual figures from estimates, and explicitly flags any missing balance sheet rows.'
                            : 'عند رفع القائمة المالية، يستخرج أخصائي المالية البنود مع أرقام الصفحات، ويشرح المعادلات خطوة بخطوة، ويفصل الأرقام الفعلية عن التقديرات، ويوضح أي بيانات مفقودة.'}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-800/80 text-xs">
                          <div>
                            <p className="text-[#94A3B8]">{language === 'en' ? 'Document Evidence' : 'أدلة المستند'}</p>
                            <p className="mt-1 font-medium text-[#F8FAFC]">
                              {language === 'en' ? 'Page & sheet citations' : 'استشهاد بالصفحة والورقة'}
                            </p>
                          </div>
                          <div>
                            <p className="text-[#94A3B8]">{language === 'en' ? 'Calculation Audit' : 'تدقيق الحسابات'}</p>
                            <p className="mt-1 font-medium text-[#F8FAFC]">
                              {language === 'en' ? 'Verified financial formulas' : 'تدقيق المعادلات المالية'}
                            </p>
                          </div>
                          <div>
                            <p className="text-[#94A3B8]">{language === 'en' ? 'Export Ready' : 'جاهز للتصدير'}</p>
                            <p className="mt-1 font-medium text-[#F8FAFC]">Markdown / HTML</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {previewTab === 'bi' && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-2">
                          <SpecialistIcon iconName="BarChart3" color="#38BDF8" size={18} />
                          <span className="text-sm font-semibold text-[#F8FAFC]">
                            {language === 'en'
                              ? 'Business Intelligence · Spreadsheet & KPI Diagnostics'
                              : 'ذكاء الأعمال · تشخيص الجداول ومؤشرات الأداء'}
                          </span>
                        </div>
                        <span className="text-xs font-medium text-[#38BDF8]">
                          {language === 'en' ? 'KPI & Margin Audit' : 'مؤشرات الأداء والهوامش'}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div className="rounded-lg border border-slate-800 bg-[#151E2E] p-4 space-y-2">
                          <h3 className="font-semibold text-[#F8FAFC]">
                            {language === 'en' ? 'Automated Spreadsheet Profiling' : 'تحليل إحصائي دقيق للأعمدة'}
                          </h3>
                          <p className="text-xs text-[#94A3B8] leading-relaxed">
                            {language === 'en'
                              ? 'Every XLSX workbook and CSV export is analyzed for exact row counts, sums, averages, and unusual anomalies before AI synthesis.'
                              : 'يتم تحليل ملفات Excel وCSV لحساب المجاميع والمتوسطات واكتشاف القيم الشاذة بدقة قبل التحليل.'}
                          </p>
                        </div>
                        <div className="rounded-lg border border-slate-800 bg-[#151E2E] p-4 space-y-2">
                          <h3 className="font-semibold text-[#F8FAFC]">
                            {language === 'en' ? 'Live Company Records' : 'بيانات الشركة الفعلية'}
                          </h3>
                          <p className="text-xs text-[#94A3B8] leading-relaxed">
                            {language === 'en'
                              ? 'Your dashboard reflects your company’s uploaded records and focus priorities directly without fabricated metrics.'
                              : 'تعرض لوحة التحكم بيانات شركتك الحقيقية وأولويات التركيز المحددة دون أي أرقام افتراضية.'}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {previewTab === 'docs' && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-2">
                          <FileSpreadsheet size={18} className="text-[#38BDF8]" />
                          <span className="text-sm font-semibold text-[#F8FAFC]">
                            {language === 'en'
                              ? 'Multi-Format Document Intelligence'
                              : 'معالجة ذكية للمستندات بصيغ متعددة'}
                          </span>
                        </div>
                        <span className="text-xs font-mono text-[#22C55E]">PDF · XLSX · CSV · DOCX · TXT</span>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                        {(['PDF', 'XLSX', 'CSV', 'DOCX', 'TXT'] as const).map((fmt) => (
                          <div key={fmt} className="rounded-lg border border-slate-800 bg-[#151E2E] p-3 text-center">
                            <p className="font-mono font-semibold text-[#F8FAFC]">{fmt}</p>
                            <p className="mt-1 text-[#94A3B8]">
                              {language === 'en' ? 'Indexed' : 'مفهرس'}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 2. PLATFORM BENEFITS */}
        <section id="product" className="border-b border-slate-800/80 bg-[#111827]/50">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
            <div className="max-w-2xl">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F8FAFC] text-balance">
                {t.landing.benefitsTitle}
              </h2>
              <p className="mt-3 text-base text-[#94A3B8] leading-relaxed">
                {t.landing.benefitsSubtitle}
              </p>
            </div>
            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
              {t.landing.benefits.map((item, idx) => (
                <div
                  key={item.title}
                  className="rounded-xl border border-slate-800 bg-[#151E2E] p-6"
                >
                  <span className="text-xs font-mono font-semibold text-[#38BDF8]">
                    0{idx + 1}.
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-[#F8FAFC]">{item.title}</h3>
                  <p className="mt-2 text-sm text-[#94A3B8] leading-relaxed">{item.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 3. AI SPECIALIST DEPARTMENTS */}
        <section id="specialists" className="border-b border-slate-800/80 bg-[#090D18]">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
            <div className="max-w-2xl">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F8FAFC] text-balance">
                {t.landing.specialistsTitle}
              </h2>
              <p className="mt-3 text-base text-[#94A3B8] leading-relaxed">
                {t.landing.specialistsSubtitle}
              </p>
            </div>

            <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {SPECIALISTS.map((spec) => (
                <div
                  key={spec.id}
                  className={`rounded-xl border p-5 flex flex-col justify-between ${
                    spec.active
                      ? 'border-[#1D4ED8]/60 bg-[#151E2E]'
                      : 'border-slate-800/80 bg-[#111827]/70 opacity-85'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <SpecialistIcon iconName={spec.iconName} color={spec.color} size={20} />
                      <span
                        className={`text-xs font-medium ${
                          spec.active ? 'text-[#22C55E]' : 'text-[#94A3B8]'
                        }`}
                      >
                        {spec.active ? t.landing.activeLabel : t.landing.comingSoonLabel}
                      </span>
                    </div>
                    <h3 className="mt-4 text-sm font-semibold text-[#F8FAFC]">
                      {language === 'ar' ? spec.nameAr : spec.nameEn}
                    </h3>
                    <p className="mt-1.5 text-xs text-[#94A3B8] leading-relaxed">
                      {language === 'ar' ? spec.descriptionAr : spec.descriptionEn}
                    </p>
                  </div>
                  <p className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-[#94A3B8]">
                    {language === 'ar' ? spec.departmentAr : spec.departmentEn}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 3. DOCUMENT INTELLIGENCE + BI ANALYTICS */}
        <section className="border-b border-slate-800/80 bg-[#111827]/40">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20 grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-7">
              <div className="flex items-center gap-2.5 text-[#38BDF8]">
                <FileText size={20} />
                <span className="text-xs font-semibold uppercase tracking-wider">
                  PDF · XLSX · CSV · DOCX · TXT
                </span>
              </div>
              <h2 className="mt-4 text-xl sm:text-2xl font-bold text-[#F8FAFC]">
                {t.landing.docIntelTitle}
              </h2>
              <p className="mt-3 text-sm text-[#94A3B8] leading-relaxed">
                {t.landing.docIntelBody}
              </p>
              <div className="mt-6 grid grid-cols-2 gap-3 text-xs text-[#E2E8F0]">
                {[
                  t.documents.workflows.summarize,
                  t.documents.workflows.financial_extraction,
                  t.documents.workflows.trend_identification,
                  t.documents.workflows.comparison,
                  t.documents.workflows.qa,
                  t.documents.workflows.report,
                ].map((wf) => (
                  <div key={wf} className="flex items-center gap-2">
                    <Check size={14} className="text-[#22C55E] shrink-0" />
                    <span>{wf}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-7">
              <div className="flex items-center gap-2.5 text-[#38BDF8]">
                <FileSpreadsheet size={20} />
                <span className="text-xs font-semibold uppercase tracking-wider">
                  {language === 'en' ? 'BI & Financial Precision' : 'دقة ذكاء الأعمال والمالية'}
                </span>
              </div>
              <h2 className="mt-4 text-xl sm:text-2xl font-bold text-[#F8FAFC]">
                {t.landing.biAnalyticsTitle}
              </h2>
              <p className="mt-3 text-sm text-[#94A3B8] leading-relaxed">
                {t.landing.biAnalyticsBody}
              </p>
              <div className="mt-6 space-y-2.5 text-xs text-[#CBD5E1]">
                <div className="flex items-center gap-2">
                  <Check size={14} className="text-[#22C55E] shrink-0" />
                  <span>
                    {language === 'en'
                      ? 'Company-wide memory across 7 structured business domains'
                      : 'ذاكرة موحدة للشركة تغطي 7 مجالات أعمال مترابطة'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Check size={14} className="text-[#22C55E] shrink-0" />
                  <span>
                    {language === 'en'
                      ? 'Custom Model Focus Data field to prioritize your critical KPIs'
                      : 'خانة بيانات التركيز لتوجيه النموذج نحو مؤشراتك وأرقامك الأهم'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Check size={14} className="text-[#22C55E] shrink-0" />
                  <span>
                    {language === 'en'
                      ? 'Source provenance citations with management approval workflows'
                      : 'توثيق المصادر بالصفحة والملف مع بوابة اعتماد إدارية للخطط'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. SECURITY & PRIVACY */}
        <section id="about" className="border-b border-slate-800/80 bg-[#090D18]">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
            <div className="flex items-center gap-2.5 text-[#38BDF8]">
              <ShieldCheck size={20} />
              <span className="text-xs font-semibold uppercase tracking-wider">
                {language === 'en' ? 'Enterprise Governance' : 'الحوكمة والأمان المؤسسي'}
              </span>
            </div>
            <h2 className="mt-3 text-2xl sm:text-3xl font-bold tracking-tight text-[#F8FAFC]">
              {t.landing.securityTitle}
            </h2>
            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
              {t.landing.securityItems.map((sec) => (
                <div key={sec.title} className="rounded-xl border border-slate-800 bg-[#151E2E] p-6">
                  <Lock size={18} className="text-[#38BDF8]" />
                  <h3 className="mt-3 text-base font-semibold text-[#F8FAFC]">{sec.title}</h3>
                  <p className="mt-2 text-sm text-[#94A3B8] leading-relaxed">{sec.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-[#090D18] py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <BrandLogo />
            <p className="mt-2 text-xs text-[#94A3B8] max-w-md">{t.landing.footerNote}</p>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-xs text-[#94A3B8]">
            <a href="#product" className="hover:text-[#F8FAFC]">{t.nav.product}</a>
            <a href="#specialists" className="hover:text-[#F8FAFC]">{t.nav.specialists}</a>
            <a href="#about" className="hover:text-[#F8FAFC]">{t.nav.about}</a>
            <button type="button" onClick={() => onNavigate('/auth/signin')} className="hover:text-[#F8FAFC]">
              {t.nav.signIn}
            </button>
            <span>© {new Date().getFullYear()} EGAI Enterprise</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
