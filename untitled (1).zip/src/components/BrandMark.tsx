import {
  BarChart3,
  Compass,
  HeartHandshake,
  Landmark,
  Megaphone,
  PackageCheck,
  Settings2,
  ShieldAlert,
  TrendingUp,
  Users,
} from 'lucide-react';
import type { SpecialistDefinition } from '../shared/specialists';

export function BrandLogo({ showSubtext = false }: { showSubtext?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0">
      <svg
        width="28"
        height="28"
        viewBox="0 0 28 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        <rect width="28" height="28" rx="7" fill="#151E2E" stroke="#1D4ED8" strokeWidth="1.5" />
        <path
          d="M8 9.5H20M8 14H15.5M8 18.5H20"
          stroke="#F8FAFC"
          strokeWidth="2"
          strokeLinecap="round"
        />
        <circle cx="19" cy="14" r="2" fill="#38BDF8" />
      </svg>
      <span className="flex flex-col leading-none">
        <span className="text-base font-bold tracking-tight text-[#F8FAFC]">
          EGAI Enterprise
        </span>
        {showSubtext && (
          <span className="text-[11px] font-medium text-[#94A3B8] mt-0.5">
            Enterprise Intelligence
          </span>
        )}
      </span>
    </span>
  );
}

export function SpecialistIcon({
  iconName,
  color,
  size = 18,
}: {
  iconName: SpecialistDefinition['iconName'];
  color: string;
  size?: number;
}) {
  const props = { size, style: { color }, 'aria-hidden': true as const };
  switch (iconName) {
    case 'Landmark':
      return <Landmark {...props} />;
    case 'BarChart3':
      return <BarChart3 {...props} />;
    case 'Users':
      return <Users {...props} />;
    case 'Megaphone':
      return <Megaphone {...props} />;
    case 'TrendingUp':
      return <TrendingUp {...props} />;
    case 'Settings2':
      return <Settings2 {...props} />;
    case 'PackageCheck':
      return <PackageCheck {...props} />;
    case 'HeartHandshake':
      return <HeartHandshake {...props} />;
    case 'ShieldAlert':
      return <ShieldAlert {...props} />;
    case 'Compass':
      return <Compass {...props} />;
  }
}
