import { useMemo } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Brain,
  FileBarChart2,
  FileText,
  Lightbulb,
  MessageSquare,
  ScanSearch,
  Upload,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { formatBytes } from '../../shared/financeUtils';
import { computePeriodAnalytics } from '../../shared/intelligenceEngine';
import type { DashboardSection } from './DashboardShell';

interface OverviewViewProps {
  onNavigateSection: (section: DashboardSection) => void;
}

export function OverviewView({ onNavigateSection }: OverviewViewProps) {
  const {
    documents,
    reports,
    structuredRecords,
    forensicFindings,
    growthProposals,
    permissions,
  } = useAuth();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';

  const analytics = useMemo(
    () => computePeriodAnalytics(structuredRecords),
    [structuredRecords]
  );

  const pendingApprovals = growthProposals.filter((p) => p.status === 'pending_approval').length;
  const openFindings = forensicFindings.filter(
    (f) => f.status === 'open' || f.status === 'investigating'
  ).length;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* KPI Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'إجمالي الإيرادات الموثقة' : 'Indexed Revenue'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {analytics.totalRevenue.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8] font-mono tabular-nums">
            {analytics.periods.length} {isAr ? 'فترة مالية' : 'periods'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'إجمالي المصروفات المستخرجة' : 'Indexed Expenses'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {analytics.totalExpenses.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8] font-mono tabular-nums">
            {analytics.profitMarginPct !== null
              ? `${isAr ? 'هامش الربح:' : 'Margin:'} ${analytics.profitMarginPct}%`
              : `${documents.length} ${isAr ? 'مستند' : 'documents'}`}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'تنبيهات التدقيق والاعتماد' : 'Forensics & Pending Approvals'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F59E0B] tabular-nums">
            {openFindings} / {pendingApprovals}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8]">
            {isAr ? 'ملاحظات مفتوحة / خطط بانتظار الموافقة' : 'Open risks / plans awaiting sign-off'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'المستندات والتقارير' : 'Workspace Knowledge & Reports'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#38BDF8] tabular-nums">
            {documents.length} / {reports.length}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8]">
            {isAr ? 'مستند مفهرس / تقرير جاهز' : 'Indexed documents / reports'}
          </div>
        </div>
      </div>

      {/* Period-over-Period Financial Chart */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
        <div className="flex items-center justify-between gap-2 mb-4">
          <h2 className="text-sm font-semibold text-[#F8FAFC]">
            {isAr
              ? 'الأداء المالي عبر الفترات (الإيرادات مقابل المصروفات وصافي الربح)'
              : 'Period-over-Period Business Performance (Revenue vs Expenses & Net Profit)'}
          </h2>
          <button
            type="button"
            onClick={() => onNavigateSection('intelligence')}
            className="text-xs font-medium text-[#38BDF8] hover:underline"
          >
            {isAr ? 'مراجعة السجلات والمصادر' : 'Verify Sources in Memory'}
          </button>
        </div>

        {analytics.periods.length === 0 ? (
          <div className="rounded-lg border border-dashed border-slate-800 bg-[#090D18]/50 p-8 text-center text-sm text-[#94A3B8]">
            {isAr
              ? 'لا توجد بيانات مالية مستخرجة بعد. ارفع ملفات XLSX أو CSV أو PDF من ذكاء المستندات لعرض مقارنة الإيرادات والمصروفات الحقيقية هنا.'
              : 'No structured period records indexed yet. Upload financial XLSX, CSV, or PDF statements in Document Intelligence to visualize real revenue and expense trends.'}
          </div>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.periods}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="periodKey" stroke="#94A3B8" fontSize={12} />
                <YAxis stroke="#94A3B8" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#090D18',
                    borderColor: '#334155',
                    color: '#F8FAFC',
                    fontSize: '12px',
                  }}
                />
                <Bar
                  dataKey="revenue"
                  name={isAr ? 'الإيرادات' : 'Revenue'}
                  fill="#1D4ED8"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="expenses"
                  name={isAr ? 'المصروفات' : 'Expenses'}
                  fill="#F59E0B"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="netProfit"
                  name={isAr ? 'صافي الربح' : 'Net Profit'}
                  fill="#22C55E"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-3">
        <h2 className="text-sm font-semibold text-[#F8FAFC]">{t.dashboard.quickActions}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => onNavigateSection('intelligence')}
            className="flex items-center gap-3 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] transition-colors"
          >
            <Brain size={16} />
            <span>{t.sidebar.intelligence}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigateSection('workspace')}
            className="flex items-center gap-3 rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 transition-colors"
          >
            <MessageSquare size={16} className="text-[#38BDF8]" />
            <span>{t.sidebar.workspace}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigateSection('forensics')}
            className="flex items-center gap-3 rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 transition-colors"
          >
            <ScanSearch size={16} className="text-[#F59E0B]" />
            <span>{t.sidebar.forensics}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigateSection('advisor')}
            className="flex items-center gap-3 rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 transition-colors"
          >
            <Lightbulb size={16} className="text-[#22C55E]" />
            <span>{t.sidebar.advisor}</span>
          </button>
          {permissions.canUploadDocuments && (
            <button
              type="button"
              onClick={() => onNavigateSection('documents')}
              className="flex items-center gap-3 rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 transition-colors"
            >
              <Upload size={16} className="text-[#38BDF8]" />
              <span>{t.documents.uploadBtn}</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => onNavigateSection('reports')}
            className="flex items-center gap-3 rounded-lg border border-slate-700 bg-[#111827] px-4 py-2.5 text-sm font-medium text-[#F8FAFC] hover:border-slate-600 transition-colors"
          >
            <FileBarChart2 size={16} className="text-[#38BDF8]" />
            <span>{t.reports.createTitle}</span>
          </button>
        </div>
      </div>

      {/* Recent Documents & Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-[#F8FAFC]">{t.dashboard.recentDocuments}</h2>
            <button
              type="button"
              onClick={() => onNavigateSection('documents')}
              className="text-xs text-[#38BDF8] hover:underline"
            >
              {isAr ? 'الكل' : 'All'}
            </button>
          </div>
          {documents.length === 0 ? (
            <p className="text-xs text-[#94A3B8] py-4">{t.dashboard.emptyDocuments}</p>
          ) : (
            <div className="space-y-2.5">
              {documents.slice(0, 4).map((d) => (
                <div
                  key={d.id}
                  className="rounded-lg border border-slate-800 bg-[#090D18] p-3 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-[#F8FAFC] truncate flex items-center gap-1.5">
                      <FileText size={13} className="text-[#38BDF8] shrink-0" />
                      <span className="truncate">{d.fileName}</span>
                    </div>
                    <div className="mt-1 text-[11px] text-[#94A3B8] font-mono tabular-nums">
                      {d.fileType.toUpperCase()} · {formatBytes(d.fileSize)}
                    </div>
                  </div>
                  <span
                    className={`text-[11px] font-medium shrink-0 ${
                      d.status === 'ready'
                        ? 'text-[#22C55E]'
                        : d.status === 'error'
                        ? 'text-[#EF4444]'
                        : 'text-[#F59E0B]'
                    }`}
                  >
                    {d.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-[#F8FAFC]">{t.dashboard.recentReports}</h2>
            <button
              type="button"
              onClick={() => onNavigateSection('reports')}
              className="text-xs text-[#38BDF8] hover:underline"
            >
              {isAr ? 'الكل' : 'All'}
            </button>
          </div>
          {reports.length === 0 ? (
            <p className="text-xs text-[#94A3B8] py-4">{t.dashboard.emptyReports}</p>
          ) : (
            <div className="space-y-2.5">
              {reports.slice(0, 4).map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => onNavigateSection('reports')}
                  className="w-full text-start rounded-lg border border-slate-800 bg-[#090D18] p-3 hover:border-slate-700"
                >
                  <div className="text-xs font-semibold text-[#F8FAFC] truncate">{r.title}</div>
                  <div className="mt-1 text-[11px] text-[#94A3B8] capitalize">
                    {r.reportType.replace('_', ' ')} · {r.status}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
