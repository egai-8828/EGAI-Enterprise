import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  Database,
  Edit3,
  Paperclip,
  Plus,
  RefreshCw,
  Save,
  Search,
  Send,
  Square,
  Target,
  ThumbsDown,
  ThumbsUp,
  Trash2,
} from 'lucide-react';
import { subscribeConversationMessages, useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { chatApi, documentsApi } from '../../lib/apiClient';
import { getActiveSpecialists, getSpecialist } from '../../shared/specialists';
import type {
  ActiveSpecialistId,
  ChatMessage,
  SpecialistSelection,
} from '../../shared/types';
import { MarkdownRenderer } from '../MarkdownRenderer';
import { SpecialistIcon } from '../BrandMark';

interface WorkspaceViewProps {
  initialSpecialist?: SpecialistSelection;
  initialConversationId?: string | null;
}

export function WorkspaceView({
  initialSpecialist = 'auto',
  initialConversationId = null,
}: WorkspaceViewProps) {
  const {
    company,
    user,
    permissions,
    conversations,
    documents,
    structuredRecords,
    knowledgeChunks,
    createConversation,
    renameConversation,
    updateConversationDocs,
    deleteConversation,
    saveMessage,
    setMessageFeedback,
    saveDocumentRecord,
    persistDocumentMemory,
    updateCompanyGovernance,
  } = useAuth();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';

  const [selectedConvId, setSelectedConvId] = useState<string | null>(initialConversationId);
  const [selectedSpecialist, setSelectedSpecialist] =
    useState<SpecialistSelection>(initialSpecialist);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [inputText, setInputText] = useState('');
  const [attachedDocIds, setAttachedDocIds] = useState<string[]>([]);
  const [showDocPicker, setShowDocPicker] = useState(false);

  const [focusDataInput, setFocusDataInput] = useState(company?.modelFocusData || '');
  const [showFocusPanel, setShowFocusPanel] = useState(true);
  const [savingFocus, setSavingFocus] = useState(false);
  const [focusSaved, setFocusSaved] = useState(false);

  const [streamingText, setStreamingText] = useState('');
  const [streamingSpecialistId, setStreamingSpecialistId] = useState<ActiveSpecialistId | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [uploadingQuick, setUploadingQuick] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setFocusDataInput(company?.modelFocusData || '');
  }, [company?.modelFocusData]);

  useEffect(() => {
    if (initialConversationId) {
      setSelectedConvId(initialConversationId);
    }
  }, [initialConversationId]);

  useEffect(() => {
    setSelectedSpecialist(initialSpecialist);
  }, [initialSpecialist]);

  const activeConversation = useMemo(
    () => conversations.find((c) => c.id === selectedConvId) ?? null,
    [conversations, selectedConvId]
  );

  useEffect(() => {
    if (activeConversation) {
      setSelectedSpecialist(activeConversation.specialistId);
      setAttachedDocIds(activeConversation.documentIds || []);
    }
  }, [activeConversation]);

  // Subscribe to messages of active conversation
  useEffect(() => {
    if (!company || !selectedConvId) {
      setMessages([]);
      return;
    }
    const unsub = subscribeConversationMessages(company.id, selectedConvId, setMessages);
    return () => unsub();
  }, [company, selectedConvId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, streamingText]);

  const readyDocuments = useMemo(
    () => documents.filter((d) => d.status === 'ready'),
    [documents]
  );

  const filteredConversations = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter((c) => c.title.toLowerCase().includes(q));
  }, [conversations, searchTerm]);

  const specialistDef = getSpecialist(
    streamingSpecialistId || (selectedSpecialist === 'auto' ? 'bi' : selectedSpecialist)
  )!;

  const executivePrompt = isAr
    ? 'حلل أداء شركتي خلال آخر 6 شهور، واكتشف أسباب انخفاض الأرباح، واقترح خطة لتحسين المبيعات وتقليل المصروفات.'
    : 'Analyze my company performance over the last 6 months, identify root causes of profit compression, and propose a plan to grow sales and cut unnecessary expenses.';

  const handleNewChat = () => {
    setSelectedConvId(null);
    setSelectedSpecialist('auto');
    setStreamingSpecialistId(null);
    setMessages([]);
    setStreamingText('');
    setErrorMsg(null);
  };

  const handleToggleAttachDoc = async (docId: string) => {
    const next = attachedDocIds.includes(docId)
      ? attachedDocIds.filter((id) => id !== docId)
      : [...attachedDocIds, docId];
    setAttachedDocIds(next);
    if (selectedConvId) {
      await updateConversationDocs(selectedConvId, next);
    }
  };

  const handleQuickUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !company || !user) return;
    setErrorMsg(null);
    setUploadingQuick(true);
    const docId = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    try {
      const uploaded = await documentsApi.upload({
        companyId: company.id,
        docId,
        file,
      });
      await saveDocumentRecord({
        id: uploaded.docId,
        companyId: company.id,
        uploadedBy: user.uid,
        uploadedByName: user.displayName || user.email || 'Analyst',
        fileName: uploaded.fileName,
        fileType: uploaded.fileType,
        fileSize: uploaded.fileSize,
        storageLocation: uploaded.storageLocation,
        status: 'ready',
        domain: uploaded.domain,
        periodKey: uploaded.periodKey,
        indexedChunkCount: uploaded.chunks.length,
        structuredRecordCount: uploaded.extractedRecords.length,
        pageCount: uploaded.pageCount ?? undefined,
        sheetNames: uploaded.sheetNames,
        textPreview: uploaded.textPreview,
      });
      await persistDocumentMemory({
        documentId: uploaded.docId,
        fileName: uploaded.fileName,
        domain: uploaded.domain,
        periodKey: uploaded.periodKey,
        chunks: uploaded.chunks,
        records: uploaded.extractedRecords,
      });
      const next = [...attachedDocIds, uploaded.docId];
      setAttachedDocIds(next);
      if (selectedConvId) {
        await updateConversationDocs(selectedConvId, next);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'File upload failed.');
    } finally {
      setUploadingQuick(false);
    }
  };

  const runPrompt = async (promptText: string, existingHistory: ChatMessage[]) => {
    if (!company || !permissions.canInvokeAI) return;
    setErrorMsg(null);
    setIsStreaming(true);
    setStreamingText('');
    setStreamingSpecialistId(selectedSpecialist === 'auto' ? null : selectedSpecialist);

    const controller = new AbortController();
    abortRef.current = controller;

    let convId = selectedConvId;
    let currentCount = existingHistory.length;
    const isNewConversation = !convId;

    try {
      const historyPayload = existingHistory.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      // If conversation already exists, record user message immediately
      if (convId) {
        const existingSpec: ActiveSpecialistId =
          activeConversation?.specialistId ||
          (selectedSpecialist === 'auto' ? 'bi' : selectedSpecialist);
        const last = existingHistory[existingHistory.length - 1];
        if (!last || last.role !== 'user' || last.content !== promptText) {
          currentCount += 1;
          await saveMessage({
            conversationId: convId,
            role: 'user',
            content: promptText,
            specialistId: existingSpec,
            provider: 'user',
            newMessageCount: currentCount,
          });
        }
      }

      const result = await chatApi.streamMessage({
        companyId: company.id,
        specialistId: convId
          ? activeConversation?.specialistId || selectedSpecialist
          : selectedSpecialist,
        message: promptText,
        history: historyPayload,
        documentIds: attachedDocIds,
        language,
        focusData: focusDataInput.trim() || undefined,
        records: structuredRecords,
        chunks: knowledgeChunks,
        signal: controller.signal,
        onMeta: ({ specialistId: resolvedId }) => {
          setStreamingSpecialistId(resolvedId);
        },
        onDelta: (chunk) => {
          setStreamingText((prev) => prev + chunk);
        },
      });

      const resolvedSpecialist = result.specialistId;

      if (isNewConversation) {
        const title = promptText.slice(0, 64) + (promptText.length > 64 ? '…' : '');
        convId = await createConversation(title, resolvedSpecialist, attachedDocIds);
        setSelectedConvId(convId);
        setSelectedSpecialist(resolvedSpecialist);
        currentCount = 1;
        await saveMessage({
          conversationId: convId,
          role: 'user',
          content: promptText,
          specialistId: resolvedSpecialist,
          provider: 'user',
          newMessageCount: currentCount,
        });
      }

      if (convId && result.fullText.trim()) {
        currentCount += 1;
        await saveMessage({
          conversationId: convId,
          role: 'assistant',
          content: result.fullText,
          specialistId: resolvedSpecialist,
          provider: result.provider,
          model: result.model,
          inputTokens: result.inputTokens,
          outputTokens: result.outputTokens,
          newMessageCount: currentCount,
        });
      }
      setStreamingText('');
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        setErrorMsg(err instanceof Error ? err.message : 'AI request failed.');
      }
    } finally {
      setIsStreaming(false);
      setStreamingSpecialistId(null);
      abortRef.current = null;
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || isStreaming) return;
    setInputText('');
    await runPrompt(trimmed, messages);
  };

  const handleRegenerate = async () => {
    if (isStreaming || messages.length === 0) return;
    const lastUserIdx = [...messages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserIdx === -1) return;
    const actualIdx = messages.length - 1 - lastUserIdx;
    const lastUserMsg = messages[actualIdx];
    const priorHistory = messages.slice(0, actualIdx);
    await runPrompt(lastUserMsg.content, priorHistory);
  };

  const handleCopy = async (id: string, text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleRenameSubmit = async (convId: string) => {
    if (renameValue.trim()) {
      await renameConversation(convId, renameValue);
    }
    setRenamingId(null);
  };

  const handleSaveFocusData = async () => {
    if (!permissions.canManageCompany) return;
    setSavingFocus(true);
    setFocusSaved(false);
    setErrorMsg(null);
    try {
      await updateCompanyGovernance({ modelFocusData: focusDataInput });
      setFocusSaved(true);
      setTimeout(() => setFocusSaved(false), 2500);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save focus data.');
    } finally {
      setSavingFocus(false);
    }
  };

  return (
    <div className="h-[calc(100vh-8.5rem)] min-h-[520px] grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Conversation Sidebar */}
      <div className="lg:col-span-3 rounded-xl border border-slate-800 bg-[#111827] flex flex-col overflow-hidden">
        <div className="p-3 border-b border-slate-800 space-y-2.5">
          <button
            type="button"
            onClick={handleNewChat}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-3 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB]"
          >
            <Plus size={15} />
            <span>{t.workspace.newConversation}</span>
          </button>
          <div className="relative">
            <Search size={14} className="absolute top-2.5 start-3 text-[#94A3B8]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.workspace.searchPlaceholder}
              className="w-full rounded-lg border border-slate-800 bg-[#090D18] ps-8 pe-3 py-1.5 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredConversations.length === 0 ? (
            <div className="p-4 text-center text-xs text-[#94A3B8]">
              {t.dashboard.emptyConversations}
            </div>
          ) : (
            filteredConversations.map((conv) => {
              const active = conv.id === selectedConvId;
              return (
                <div
                  key={conv.id}
                  className={`rounded-lg border p-2.5 transition-colors ${
                    active
                      ? 'border-[#1D4ED8] bg-[#151E2E]'
                      : 'border-transparent hover:bg-[#151E2E]/60'
                  }`}
                >
                  {renamingId === conv.id ? (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleRenameSubmit(conv.id);
                      }}
                      className="flex gap-1"
                    >
                      <input
                        type="text"
                        autoFocus
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onBlur={() => handleRenameSubmit(conv.id)}
                        className="flex-1 rounded border border-[#38BDF8] bg-[#090D18] px-2 py-1 text-xs text-[#F8FAFC]"
                      />
                    </form>
                  ) : (
                    <div className="flex items-start justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedConvId(conv.id)}
                        className="flex-1 text-start min-w-0"
                      >
                        <div className="text-xs font-medium text-[#F8FAFC] truncate">
                          {conv.title}
                        </div>
                        <div className="mt-1 text-[11px] text-[#94A3B8] font-mono tabular-nums">
                          {getSpecialist(conv.specialistId)?.[isAr ? 'nameAr' : 'nameEn'] ||
                            conv.specialistId}{' '}
                          · {conv.messageCount}
                        </div>
                      </button>
                      {permissions.canWriteWorkspace && (
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            aria-label={`Rename ${conv.title}`}
                            onClick={() => {
                              setRenamingId(conv.id);
                              setRenameValue(conv.title);
                            }}
                            className="p-1 text-[#94A3B8] hover:text-[#F8FAFC]"
                          >
                            <Edit3 size={12} />
                          </button>
                          <button
                            type="button"
                            aria-label={`Delete ${conv.title}`}
                            onClick={() => {
                              if (selectedConvId === conv.id) setSelectedConvId(null);
                              deleteConversation(conv.id);
                            }}
                            className="p-1 text-[#94A3B8] hover:text-[#EF4444]"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Main Chat Pane */}
      <div className="lg:col-span-9 rounded-xl border border-slate-800 bg-[#151E2E] flex flex-col overflow-hidden">
        {/* Top Workspace Bar */}
        <div className="border-b border-slate-800 bg-[#111827] px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <SpecialistIcon iconName={specialistDef.iconName} color={specialistDef.color} size={18} />
            <div>
              <div className="text-xs text-[#94A3B8]">{t.workspace.selectSpecialist}</div>
              {selectedConvId ? (
                <div className="text-sm font-semibold text-[#F8FAFC]">
                  {isAr ? specialistDef.nameAr : specialistDef.nameEn}
                </div>
              ) : (
                <select
                  aria-label={t.workspace.selectSpecialist}
                  value={selectedSpecialist}
                  onChange={(e) => setSelectedSpecialist(e.target.value as SpecialistSelection)}
                  className="bg-transparent text-sm font-semibold text-[#F8FAFC] focus:outline-none"
                >
                  <option value="auto" className="bg-[#111827]">
                    {isAr ? 'تلقائي (يحدده الذكاء الاصطناعي)' : 'Auto (AI Routing)'}
                  </option>
                  {getActiveSpecialists().map((s) => (
                    <option key={s.id} value={s.id} className="bg-[#111827]">
                      {isAr ? s.nameAr : s.nameEn}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-[#090D18] px-2.5 py-1.5 text-[#CBD5E1]">
              <Database size={13} className="text-[#22C55E]" />
              <span className="font-mono tabular-nums">
                {isAr
                  ? `ذاكرة الشركة: ${knowledgeChunks.length} مقطع`
                  : `Company Memory: ${knowledgeChunks.length} chunks`}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setShowFocusPanel((v) => !v)}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 font-medium transition-colors ${
                focusDataInput.trim()
                  ? 'border-[#38BDF8]/60 bg-[#1D4ED8]/15 text-[#F8FAFC]'
                  : 'border-slate-700 bg-[#090D18] text-[#CBD5E1] hover:border-[#38BDF8]'
              }`}
            >
              <Target size={13} className="text-[#38BDF8]" />
              <span>{isAr ? 'بيانات التركيز' : 'Model Focus Data'}</span>
              {showFocusPanel ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            </button>

            <button
              type="button"
              onClick={() => setShowDocPicker((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#090D18] px-3 py-1.5 font-medium text-[#F8FAFC] hover:border-[#38BDF8]"
            >
              <Paperclip size={13} className="text-[#38BDF8]" />
              <span>
                {t.workspace.attachDocs} ({attachedDocIds.length})
              </span>
            </button>
          </div>
        </div>

        {/* Dedicated Model Focus Data Field */}
        {showFocusPanel && (
          <div className="border-b border-slate-800 bg-[#090D18]/80 px-4 py-3 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label
                htmlFor="workspace-focus-data"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#F8FAFC]"
              >
                <Target size={13} className="text-[#38BDF8]" />
                <span>
                  {isAr
                    ? 'بيانات يركز عليها النموذج (أرقام، أولويات، أو معطيات محددة)'
                    : 'Model Focus Data (Priority figures, KPIs, or specific constraints)'}
                </span>
              </label>
              <div className="flex items-center gap-2">
                {focusSaved && (
                  <span className="text-[11px] text-[#22C55E]">
                    {isAr ? 'تم الحفظ للشركة' : 'Saved for company'}
                  </span>
                )}
                {permissions.canManageCompany && (
                  <button
                    type="button"
                    disabled={savingFocus}
                    onClick={handleSaveFocusData}
                    className="inline-flex items-center gap-1 rounded-md border border-slate-700 bg-[#111827] px-2.5 py-1 text-[11px] font-medium text-[#38BDF8] hover:border-[#38BDF8] disabled:opacity-50"
                  >
                    <Save size={11} />
                    <span>{isAr ? 'حفظ كافتراضي للشركة' : 'Save for Company'}</span>
                  </button>
                )}
              </div>
            </div>
            <textarea
              id="workspace-focus-data"
              rows={2}
              value={focusDataInput}
              onChange={(e) => setFocusDataInput(e.target.value)}
              disabled={!permissions.canInvokeAI}
              placeholder={
                isAr
                  ? 'أدخل هنا البيانات أو الأرقام أو البنود التي تريد أن يضعها النموذج في مقدمة تحليله (مثال: هامش الربح المستهدف 22%، تكلفة التسويق 45000، التركيز على فرع الرياض)...'
                  : 'Enter priority figures, KPIs, or facts you want the AI model to focus on across its analysis (e.g., Target gross margin 22%, Q3 ad spend $45,000, focus on enterprise churn)...'
              }
              className="w-full resize-y rounded-lg border border-slate-700 bg-[#111827] px-3 py-2 text-xs text-[#F8FAFC] placeholder:text-[#64748B] focus:border-[#38BDF8] focus:outline-none disabled:opacity-60"
            />
          </div>
        )}

        {/* Attached Document Picker Drawer */}
        {showDocPicker && (
          <div className="border-b border-slate-800 bg-[#090D18] px-4 py-3 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-[#CBD5E1]">
                {t.workspace.attachDocs}{' '}
                <span className="text-[#94A3B8]">
                  ({isAr
                    ? 'اختياري: بدون تحديد يقرأ المساعد من كل ذاكرة الشركة تلقائياً'
                    : 'Optional: leave empty to query all Company Memory automatically'})
                </span>
              </span>
              {permissions.canUploadDocuments && (
                <>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.xlsx,.xls,.csv,.docx,.txt"
                    onChange={handleQuickUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploadingQuick}
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs font-semibold text-[#38BDF8] hover:underline"
                  >
                    {uploadingQuick
                      ? isAr
                        ? 'جاري الرفع...'
                        : 'Uploading...'
                      : isAr
                      ? '+ رفع ملف جديد'
                      : '+ Upload New File'}
                  </button>
                </>
              )}
            </div>
            {readyDocuments.length === 0 ? (
              <p className="text-xs text-[#94A3B8]">{t.workspace.noDocsReady}</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {readyDocuments.map((d) => {
                  const selected = attachedDocIds.includes(d.id);
                  return (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => handleToggleAttachDoc(d.id)}
                      className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs transition-colors ${
                        selected
                          ? 'border-[#38BDF8] bg-[#1D4ED8]/20 text-[#F8FAFC]'
                          : 'border-slate-800 bg-[#111827] text-[#94A3B8] hover:text-[#F8FAFC]'
                      }`}
                    >
                      {selected && <Check size={12} className="text-[#38BDF8]" />}
                      <span className="truncate max-w-[200px]">{d.fileName}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {messages.length === 0 && !isStreaming && (
            <div className="max-w-2xl mx-auto py-8 space-y-5">
              <div className="flex items-center gap-3">
                <SpecialistIcon
                  iconName={specialistDef.iconName}
                  color={specialistDef.color}
                  size={24}
                />
                <div>
                  <h2 className="text-lg font-bold text-[#F8FAFC]">
                    {selectedSpecialist === 'auto'
                      ? isAr
                        ? 'توجيه تلقائي للمتخصص المناسب (Auto AI)'
                        : 'Automatic Specialist Routing'
                      : isAr
                      ? specialistDef.nameAr
                      : specialistDef.nameEn}
                  </h2>
                  <p className="text-xs text-[#94A3B8]">
                    {selectedSpecialist === 'auto'
                      ? isAr
                        ? 'يختار الذكاء الاصطناعي المتخصص الأنسب تلقائياً من بين الإدارات العشر حسب سؤالك ومستنداتك، أو يمكنك اختيار إدارة محددة من القائمة أعلاه.'
                        : 'AI automatically selects the best department specialist from all 10 divisions based on your prompt and uploaded files, or you can pick one manually above.'
                      : isAr
                      ? specialistDef.descriptionAr
                      : specialistDef.descriptionEn}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                <button
                  type="button"
                  disabled={!permissions.canInvokeAI}
                  onClick={() => setInputText(executivePrompt)}
                  className="text-start rounded-lg border border-[#38BDF8]/40 bg-[#111827] p-3.5 text-xs text-[#F8FAFC] hover:border-[#38BDF8] transition-colors"
                >
                  <div className="text-[11px] font-semibold text-[#38BDF8] mb-1">
                    {isAr ? 'استعلام تنفيذي شامل من ذاكرة الشركة' : 'Executive Cross-Memory Prompt'}
                  </div>
                  {executivePrompt}
                </button>
                {(isAr ? specialistDef.examplePromptsAr : specialistDef.examplePromptsEn).map(
                  (prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      disabled={!permissions.canInvokeAI}
                      onClick={() => setInputText(prompt)}
                      className="text-start rounded-lg border border-slate-800 bg-[#111827] p-3.5 text-xs text-[#E2E8F0] hover:border-[#38BDF8]/60 transition-colors"
                    >
                      {prompt}
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {messages.map((msg, index) => {
            const isAssistant = msg.role === 'assistant';
            const isLastAssistant = isAssistant && index === messages.length - 1;
            const msgSpecialist = getSpecialist(msg.specialistId) || specialistDef;
            return (
              <div
                key={msg.id}
                className={`rounded-xl border p-4 ${
                  isAssistant
                    ? 'border-slate-800 bg-[#111827]'
                    : 'border-[#1D4ED8]/40 bg-[#1D4ED8]/10 ms-auto max-w-3xl'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-2 text-xs text-[#94A3B8]">
                  <span className="font-semibold text-[#F8FAFC]">
                    {isAssistant
                      ? isAr
                        ? msgSpecialist.nameAr
                        : msgSpecialist.nameEn
                      : user?.displayName || user?.email}
                  </span>
                </div>

                {isAssistant ? (
                  <MarkdownRenderer content={msg.content} />
                ) : (
                  <p className="text-sm text-[#F8FAFC] whitespace-pre-wrap leading-relaxed">
                    {msg.content}
                  </p>
                )}

                {isAssistant && (
                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center gap-3 text-xs text-[#94A3B8]">
                    <button
                      type="button"
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="inline-flex items-center gap-1 hover:text-[#F8FAFC]"
                    >
                      {copiedId === msg.id ? (
                        <Check size={13} className="text-[#22C55E]" />
                      ) : (
                        <Copy size={13} />
                      )}
                      <span>{copiedId === msg.id ? t.workspace.copied : t.workspace.copy}</span>
                    </button>

                    {isLastAssistant && permissions.canInvokeAI && (
                      <button
                        type="button"
                        onClick={handleRegenerate}
                        className="inline-flex items-center gap-1 hover:text-[#F8FAFC]"
                      >
                        <RefreshCw size={13} />
                        <span>{t.workspace.regenerate}</span>
                      </button>
                    )}

                    {selectedConvId && permissions.canWriteWorkspace && (
                      <div className="flex items-center gap-2 ms-auto">
                        <button
                          type="button"
                          aria-label={t.workspace.helpful}
                          onClick={() =>
                            setMessageFeedback(
                              selectedConvId,
                              msg.id,
                              msg.feedback === 'up' ? 'none' : 'up'
                            )
                          }
                          className={`p-1 rounded ${
                            msg.feedback === 'up' ? 'text-[#22C55E]' : 'hover:text-[#F8FAFC]'
                          }`}
                        >
                          <ThumbsUp size={13} />
                        </button>
                        <button
                          type="button"
                          aria-label={t.workspace.notHelpful}
                          onClick={() =>
                            setMessageFeedback(
                              selectedConvId,
                              msg.id,
                              msg.feedback === 'down' ? 'none' : 'down'
                            )
                          }
                          className={`p-1 rounded ${
                            msg.feedback === 'down' ? 'text-[#EF4444]' : 'hover:text-[#F8FAFC]'
                          }`}
                        >
                          <ThumbsDown size={13} />
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {isStreaming && (
            <div className="rounded-xl border border-[#38BDF8]/40 bg-[#111827] p-4">
              <div className="text-xs font-semibold text-[#38BDF8] mb-2">
                {streamingSpecialistId
                  ? isAr
                    ? specialistDef.nameAr
                    : specialistDef.nameEn
                  : isAr
                  ? 'تحديد المتخصص المناسب...'
                  : 'Selecting best specialist...'}
              </div>
              {streamingText ? (
                <MarkdownRenderer content={streamingText} />
              ) : (
                <p className="text-xs text-[#94A3B8]">
                  {isAr ? 'جاري التحليل والاستدلال من ذاكرة الشركة...' : 'Analyzing Company Memory...'}
                </p>
              )}
            </div>
          )}

          {errorMsg && (
            <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-[#FCA5A5]">
              <AlertCircle size={15} className="shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input Composer */}
        <form onSubmit={handleSend} className="border-t border-slate-800 bg-[#111827] p-3 sm:p-4">
          {!permissions.canInvokeAI ? (
            <div className="text-xs text-[#F59E0B] py-2">{t.workspace.viewerNotice}</div>
          ) : (
            <div className="space-y-2">
              <textarea
                rows={3}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend(e);
                  }
                }}
                placeholder={t.workspace.inputPlaceholder}
                className="w-full resize-none rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-sm text-[#F8FAFC] placeholder:text-[#64748B] focus:border-[#38BDF8] focus:outline-none"
              />
              <div className="flex items-center justify-between gap-2 text-xs text-[#94A3B8]">
                <div className="truncate">
                  {attachedDocIds.length > 0
                    ? `${attachedDocIds.length} ${isAr ? 'مستند مرفق' : 'document(s) attached'}`
                    : isAr
                    ? 'متصل تلقائياً بذاكرة الشركة · Enter للإرسال'
                    : 'Auto-connected to Company Memory · Enter to send'}
                </div>
                {isStreaming ? (
                  <button
                    type="button"
                    onClick={() => abortRef.current?.abort()}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#EF4444] px-4 py-2 text-xs font-semibold text-[#F8FAFC]"
                  >
                    <Square size={13} />
                    <span>{t.workspace.stop}</span>
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={!inputText.trim()}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
                  >
                    <Send size={13} />
                    <span>{t.workspace.send}</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
