import { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ClipboardCheck,
  Lightbulb,
  Lock,
  Sparkles,
  Target,
  XCircle,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { advisorApi } from '../../lib/apiClient';
import { GROWTH_ADVISOR_DOMAINS } from '../../shared/intelligenceEngine';
import type { GrowthAdvisorDomain, GrowthProposalStatus } from '../../shared/types';

export function GrowthAdvisorView() {
  const {
    company,
    permissions,
    structuredRecords,
    knowledgeChunks,
    growthProposals,
    saveGrowthProposals,
    reviewGrowthProposal,
  } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [selectedDomains, setSelectedDomains] = useState<GrowthAdvisorDomain[]>([
    'finance',
    'sales',
    'marketing',
    'operations',
  ]);
  const [focusData, setFocusData] = useState(company?.modelFocusData || '');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<GrowthProposalStatus | 'all'>('all');
  const [approvalNotes, setApprovalNotes] = useState<Record<string, string>>({});

  useEffect(() => {
    setFocusData(company?.modelFocusData || '');
  }, [company?.modelFocusData]);

  const toggleDomain = (id: GrowthAdvisorDomain) => {
    setSelectedDomains((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredProposals = useMemo(() => {
    if (statusFilter === 'all') return growthProposals;
    return growthProposals.filter((p) => p.status === statusFilter);
  }, [growthProposals, statusFilter]);

  const handleGenerate = async () => {
    if (!company || !permissions.canInvokeAI || selectedDomains.length === 0) return;
    setError(null);
    setNotice(null);
    setGenerating(true);
    try {
      const res = await advisorApi.generate({
        companyId: company.id,
        domains: selectedDomains,
        records: structuredRecords,
        chunks: knowledgeChunks,
        language,
        focusData: focusData.trim() || undefined,
      });

      const saved = await saveGrowthProposals(res.proposals);
      setNotice(
        isAr
          ? `تم توليد ${saved} خطة تطوير مقترحة. جميع الخطط تبقى بانتظار موافقة الإدارة (Requires Management Approval).`
          : `Generated ${saved} structured growth proposal(s). All plans require Management Approval before execution.`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate growth proposals.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            {isAr ? 'مستشار نمو وتطوير الأعمال (Business Growth Advisor)' : 'Business Growth Advisor'}
          </h2>
          <p className="mt-1 text-sm text-[#94A3B8]">
            {isAr
              ? 'يقترح حلول تطوير قابلة للتنفيذ عبر 8 مجالات، ويشمل كل مقترح الأركان السبعة كاملة مع بوابة إلزامية لاعتماد الإدارة قبل أي تنفيذ.'
              : 'Generates actionable improvement plans across 8 business domains with all 7 required analytical sections and a mandatory Management Approval gate.'}
          </p>
        </div>

        <div className="rounded-lg border border-[#F59E0B]/40 bg-[#F59E0B]/10 px-3.5 py-2 text-xs text-[#FDE68A] flex items-center gap-2">
          <Lock size={14} className="shrink-0" />
          <span>
            {isAr
              ? 'حوكمة الذكاء الاصطناعي: كل التوصيات تتطلب موافقة الإدارة ولا تنفذ تلقائياً'
              : 'Governance Gate: Requires Management Approval (AI never executes changes autonomously)'}
          </span>
        </div>
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3.5 text-xs text-[#FCA5A5]">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="flex items-start gap-2 rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3.5 text-xs text-[#86EFAC]">
          <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
          <span>{notice}</span>
        </div>
      )}

      {/* 8-Domain Selection & Generator */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-[#38BDF8]">
            <Lightbulb size={17} />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              {isAr ? 'اختر مجالات التطوير (8 مجالات متخصصة)' : 'Select Target Domains (8 Growth Areas)'}
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => setSelectedDomains(GROWTH_ADVISOR_DOMAINS.map((d) => d.id))}
              className="text-[#38BDF8] hover:underline"
            >
              {isAr ? 'تحديد الكل (8)' : 'Select All (8)'}
            </button>
            <span className="text-[#64748B]">·</span>
            <button
              type="button"
              onClick={() => setSelectedDomains([])}
              className="text-[#94A3B8] hover:text-[#F8FAFC]"
            >
              {isAr ? 'مسح' : 'Clear'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {GROWTH_ADVISOR_DOMAINS.map((dom) => {
            const selected = selectedDomains.includes(dom.id);
            return (
              <button
                key={dom.id}
                type="button"
                onClick={() => toggleDomain(dom.id)}
                className={`text-start rounded-lg border p-3.5 transition-colors ${
                  selected
                    ? 'border-[#38BDF8] bg-[#1D4ED8]/15'
                    : 'border-slate-800 bg-[#090D18] hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-semibold text-[#F8FAFC]">
                    {isAr ? dom.nameAr : dom.nameEn}
                  </span>
                  {selected && <CheckCircle2 size={14} className="text-[#38BDF8] shrink-0" />}
                </div>
                <p className="mt-1 text-xs text-[#94A3B8]">
                  {isAr ? dom.focusAr : dom.focusEn}
                </p>
              </button>
            );
          })}
        </div>

        {permissions.canInvokeAI && (
          <div className="space-y-3 pt-1">
            <div>
              <label
                htmlFor="advisor-focus-data"
                className="flex items-center gap-1.5 text-xs font-medium text-[#38BDF8] mb-1.5"
              >
                <Target size={13} />
                <span>
                  {isAr
                    ? 'بيانات يركز عليها النموذج (اختياري)'
                    : 'Model Focus Data (optional)'}
                </span>
              </label>
              <textarea
                id="advisor-focus-data"
                rows={2}
                value={focusData}
                onChange={(e) => setFocusData(e.target.value)}
                placeholder={
                  isAr
                    ? 'أدخل أرقاماً أو أولويات محددة تريد من مستشار النمو التركيز عليها في خطط التطوير...'
                    : 'Enter priority figures, constraints, or business challenges for the Growth Advisor to emphasize...'
                }
                className="w-full rounded-lg border border-[#38BDF8]/40 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <button
              type="button"
              disabled={generating || selectedDomains.length === 0}
              onClick={handleGenerate}
              className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
            >
              <Sparkles size={16} />
              <span>
                {generating
                  ? isAr
                    ? 'جاري إعداد خطط التطوير...'
                    : 'Generating Growth Proposals...'
                  : isAr
                  ? `توليد خطط التطوير (${selectedDomains.length})`
                  : `Generate Growth Proposals (${selectedDomains.length})`}
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Proposals Feed with Mandatory Approval Gate */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-sm font-semibold text-[#F8FAFC]">
            {isAr
              ? `مقترحات التطوير وبوابة الاعتماد الإداري (${filteredProposals.length})`
              : `Growth Proposals & Management Approval Queue (${filteredProposals.length})`}
          </h3>
          <select
            aria-label="Filter proposal status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as GrowthProposalStatus | 'all')}
            className="rounded-lg border border-slate-700 bg-[#111827] px-3 py-1.5 text-xs text-[#F8FAFC]"
          >
            <option value="all">{isAr ? 'كل الحالات' : 'All Statuses'}</option>
            <option value="pending_approval">{isAr ? 'بانتظار موافقة الإدارة' : 'Pending Approval'}</option>
            <option value="approved">{isAr ? 'معتمد' : 'Approved'}</option>
            <option value="rejected">{isAr ? 'مرفوض' : 'Rejected'}</option>
            <option value="implemented">{isAr ? 'تم التنفيذ' : 'Implemented'}</option>
          </select>
        </div>

        {filteredProposals.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-800 bg-[#151E2E]/40 p-10 text-center space-y-2">
            <ClipboardCheck size={24} className="mx-auto text-[#38BDF8]" />
            <p className="text-sm text-[#94A3B8]">
              {isAr
                ? 'لا توجد خطط تطوير في هذه القائمة بعد. اختر المجالات واضغط «توليد خطط التطوير».'
                : 'No growth proposals in this queue yet. Select business domains above and generate structured plans.'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredProposals.map((prop) => {
              const statusColor =
                prop.status === 'approved' || prop.status === 'implemented'
                  ? 'text-[#22C55E] border-[#22C55E]/40'
                  : prop.status === 'rejected'
                  ? 'text-[#EF4444] border-[#EF4444]/40'
                  : 'text-[#F59E0B] border-[#F59E0B]/40';

              const statusLabel =
                prop.status === 'pending_approval'
                  ? isAr
                    ? 'بانتظار موافقة الإدارة (Requires Management Approval)'
                    : 'Requires Management Approval'
                  : prop.status === 'approved'
                  ? isAr
                    ? 'معتمد من الإدارة'
                    : 'Approved'
                  : prop.status === 'rejected'
                  ? isAr
                    ? 'مرفوض'
                    : 'Rejected'
                  : isAr
                  ? 'تم التنفيذ'
                  : 'Implemented';

              return (
                <div
                  key={prop.id}
                  className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
                        <span className="uppercase text-[#38BDF8] font-semibold">
                          {prop.domain}
                        </span>
                        <span className={`border rounded px-2 py-0.5 font-semibold ${statusColor}`}>
                          {statusLabel}
                        </span>
                      </div>
                      <h4 className="mt-1.5 text-base font-bold text-[#F8FAFC]">{prop.title}</h4>
                    </div>

                    {prop.approvedByEmail && (
                      <div className="text-xs text-[#94A3B8] font-mono">
                        {isAr ? 'تمت المراجعة بواسطة:' : 'Reviewed by:'} {prop.approvedByEmail}
                      </div>
                    )}
                  </div>

                  {/* All 7 Mandatory Proposal Sections */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                      <div className="font-semibold text-[#F8FAFC] mb-1">
                        {isAr ? '1. المشكلة المكتشفة' : '1. Detected Problem'}
                      </div>
                      <p className="text-[#CBD5E1] leading-relaxed">{prop.detectedProblem}</p>
                    </div>

                    <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                      <div className="font-semibold text-[#F8FAFC] mb-1">
                        {isAr ? '2. الأدلة والأرقام' : '2. Evidence & Numbers'}
                      </div>
                      <p className="text-[#CBD5E1] font-mono leading-relaxed whitespace-pre-wrap">
                        {prop.evidenceAndNumbers}
                      </p>
                    </div>

                    <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                      <div className="font-semibold text-[#F8FAFC] mb-1">
                        {isAr ? '3. الحل المقترح' : '3. Proposed Solution'}
                      </div>
                      <p className="text-[#CBD5E1] leading-relaxed">{prop.proposedSolution}</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                        <div className="font-semibold text-[#F8FAFC] mb-1">
                          {isAr ? '4. التكلفة المتوقعة' : '4. Expected Cost'}
                        </div>
                        <p className="text-[#CBD5E1] leading-relaxed">{prop.expectedCost}</p>
                      </div>
                      <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                        <div className="font-semibold text-[#22C55E] mb-1">
                          {isAr ? '5. العائد المتوقع' : '5. Expected Return'}
                        </div>
                        <p className="text-[#CBD5E1] leading-relaxed">{prop.expectedReturn}</p>
                      </div>
                    </div>

                    <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                      <div className="font-semibold text-[#F8FAFC] mb-1.5">
                        {isAr ? '6. خطة التنفيذ' : '6. Execution Plan'}
                      </div>
                      <ol className="list-decimal list-inside space-y-1 text-[#CBD5E1]">
                        {prop.executionPlan.map((step, idx) => (
                          <li key={idx}>{step}</li>
                        ))}
                      </ol>
                    </div>

                    <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5">
                      <div className="font-semibold text-[#38BDF8] mb-1.5">
                        {isAr ? '7. مؤشرات قياس النجاح' : '7. Success Metrics (KPIs)'}
                      </div>
                      <p className="text-[#CBD5E1] leading-relaxed">{prop.successMetrics}</p>
                      {prop.approvalNote && (
                        <div className="mt-2 pt-2 border-t border-slate-800 text-[11px] text-[#94A3B8]">
                          <strong className="text-[#F8FAFC]">
                            {isAr ? 'ملاحظة الإدارة:' : 'Management Note:'}
                          </strong>{' '}
                          {prop.approvalNote}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Management Approval Action Bar (Owner / Administrator only) */}
                  {prop.status === 'pending_approval' && (
                    <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                      {permissions.canApproveGrowthPlans ? (
                        <>
                          <input
                            type="text"
                            value={approvalNotes[prop.id] || ''}
                            onChange={(e) =>
                              setApprovalNotes((prev) => ({
                                ...prev,
                                [prop.id]: e.target.value,
                              }))
                            }
                            placeholder={
                              isAr
                                ? 'أضف ملاحظة اعتماد أو سبب الرفض (اختياري)...'
                                : 'Optional management approval note or condition...'
                            }
                            className="flex-1 min-w-[220px] rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
                          />
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                reviewGrowthProposal(prop.id, 'approved', approvalNotes[prop.id])
                              }
                              className="inline-flex items-center gap-1.5 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/50 px-3.5 py-2 text-xs font-semibold text-[#86EFAC] hover:bg-[#22C55E]/30"
                            >
                              <CheckCircle2 size={14} />
                              <span>{isAr ? 'اعتماد الخطة' : 'Approve Plan'}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                reviewGrowthProposal(prop.id, 'rejected', approvalNotes[prop.id])
                              }
                              className="inline-flex items-center gap-1.5 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/40 px-3.5 py-2 text-xs font-semibold text-[#FCA5A5] hover:bg-[#EF4444]/25"
                            >
                              <XCircle size={14} />
                              <span>{isAr ? 'رفض' : 'Reject'}</span>
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="text-xs text-[#F59E0B]">
                          {isAr
                            ? 'يتطلب اعتماد المالك (Owner) أو المدير (Administrator) لتنفيذ هذه الخطة.'
                            : 'Only an Owner or Administrator can approve or reject growth proposals.'}
                        </div>
                      )}
                    </div>
                  )}

                  {prop.status === 'approved' && permissions.canApproveGrowthPlans && (
                    <div className="pt-2 border-t border-slate-800 flex justify-end">
                      <button
                        type="button"
                        onClick={() =>
                          reviewGrowthProposal(prop.id, 'implemented', prop.approvalNote)
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#38BDF8]/40 bg-[#38BDF8]/10 px-3.5 py-1.5 text-xs font-semibold text-[#38BDF8] hover:bg-[#38BDF8]/20"
                      >
                        <ClipboardCheck size={14} />
                        <span>{isAr ? 'تحديد كمنفّذة' : 'Mark as Implemented'}</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
