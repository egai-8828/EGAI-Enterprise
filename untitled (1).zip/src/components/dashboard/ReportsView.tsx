import React, { useEffect, useState } from 'react';
import { AlertCircle, Download, Eye, FileBarChart2, Target, Trash2, X } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { reportsApi } from '../../lib/apiClient';
import { getActiveSpecialists } from '../../shared/specialists';
import type {
  EnterpriseReport,
  ReportType,
  SpecialistSelection,
} from '../../shared/types';
import { MarkdownRenderer } from '../MarkdownRenderer';

export function ReportsView() {
  const {
    company,
    permissions,
    documents,
    conversations,
    reports,
    createReportRecord,
    deleteReportRecord,
  } = useAuth();
  const { language, t } = useLanguage();

  const [title, setTitle] = useState('');
  const [reportType, setReportType] = useState<ReportType>('executive_summary');
  const [specialistId, setSpecialistId] = useState<SpecialistSelection>('auto');
  const [selectedDocs, setSelectedDocs] = useState<string[]>([]);
  const [selectedConvId, setSelectedConvId] = useState('');
  const [instructions, setInstructions] = useState('');
  const [focusData, setFocusData] = useState(company?.modelFocusData || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewReport, setPreviewReport] = useState<EnterpriseReport | null>(null);

  useEffect(() => {
    setFocusData(company?.modelFocusData || '');
  }, [company?.modelFocusData]);

  const readyDocs = documents.filter((d) => d.status === 'ready');

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company || !permissions.canInvokeAI) return;
    if (!title.trim()) {
      setError(language === 'ar' ? 'يرجى إدخال عنوان التقرير.' : 'Please enter a report title.');
      return;
    }

    setError(null);
    setBusy(true);
    const reportId = `rep_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

    try {
      const conv = conversations.find((c) => c.id === selectedConvId);
      const res = await reportsApi.generate({
        companyId: company.id,
        title: title.trim(),
        reportType,
        specialistId,
        documentIds: selectedDocs,
        conversationSummary: conv ? `Conversation Topic: ${conv.title}` : undefined,
        instructions,
        focusData: focusData.trim() || undefined,
        language,
      });

      await createReportRecord({
        reportId,
        title: title.trim(),
        reportType,
        specialistId: res.specialistId,
        conversationId: selectedConvId || undefined,
        documentIds: selectedDocs,
        status: 'ready',
        content: res.content,
        provider: `${res.provider}:${res.model}`,
      });

      setTitle('');
      setInstructions('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Report generation failed.');
    } finally {
      setBusy(false);
    }
  };

  const downloadMarkdown = (report: EnterpriseReport) => {
    if (report.status !== 'ready' || !report.content) return;
    const blob = new Blob([`# ${report.title}\n\n${report.content}`], {
      type: 'text/markdown;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.title.replace(/[^a-zA-Z0-9_-]/g, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadHtml = (report: EnterpriseReport) => {
    if (report.status !== 'ready' || !report.content) return;
    const escaped = report.content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    const html = `<!doctype html><html lang="${language}" dir="${
      language === 'ar' ? 'rtl' : 'ltr'
    }"><head><meta charset="utf-8"><title>${report.title}</title><style>body{font-family:system-ui,sans-serif;max-width:860px;margin:40px auto;padding:0 20px;line-height:1.6;color:#0f172a}pre{white-space:pre-wrap;font-family:inherit}</style></head><body><h1>${report.title}</h1><pre>${escaped}</pre></body></html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.title.replace(/[^a-zA-Z0-9_-]/g, '_')}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-[#F8FAFC]">{t.reports.title}</h2>
        <p className="mt-1 text-sm text-[#94A3B8]">{t.reports.subtitle}</p>
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3.5 text-xs text-[#FCA5A5]">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Report Generator Form */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F8FAFC]">{t.reports.createTitle}</h3>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label htmlFor="rep-title" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {t.reports.reportTitle}
              </label>
              <input
                id="rep-title"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="rep-type" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                  {t.reports.reportType}
                </label>
                <select
                  id="rep-type"
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value as ReportType)}
                  className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC]"
                >
                  <option value="financial">{t.reports.templates.financial}</option>
                  <option value="business_performance">
                    {t.reports.templates.business_performance}
                  </option>
                  <option value="executive_summary">{t.reports.templates.executive_summary}</option>
                  <option value="data_analysis">{t.reports.templates.data_analysis}</option>
                </select>
              </div>
              <div>
                <label htmlFor="rep-spec" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                  {t.workspace.selectSpecialist}
                </label>
                <select
                  id="rep-spec"
                  value={specialistId}
                  onChange={(e) => setSpecialistId(e.target.value as SpecialistSelection)}
                  className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC]"
                >
                  <option value="auto">
                    {language === 'ar' ? 'تلقائي (يحدده الذكاء الاصطناعي)' : 'Auto (AI Routing)'}
                  </option>
                  {getActiveSpecialists().map((spec) => (
                    <option key={spec.id} value={spec.id}>
                      {language === 'ar' ? spec.nameAr : spec.nameEn}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {conversations.length > 0 && (
              <div>
                <label htmlFor="rep-conv" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                  {language === 'ar' ? 'المحادثة المرتبطة (اختياري)' : 'Associated Conversation (optional)'}
                </label>
                <select
                  id="rep-conv"
                  value={selectedConvId}
                  onChange={(e) => setSelectedConvId(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC]"
                >
                  <option value="">{language === 'ar' ? '— بدون —' : '— None —'}</option>
                  {conversations.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <div className="text-xs font-medium text-[#CBD5E1] mb-1.5">
                {language === 'ar' ? 'ربط مستندات جاهزة' : 'Include Processed Documents'}
              </div>
              {readyDocs.length === 0 ? (
                <p className="text-xs text-[#94A3B8]">{t.workspace.noDocsReady}</p>
              ) : (
                <div className="max-h-32 overflow-y-auto space-y-1.5 rounded-lg border border-slate-800 bg-[#090D18] p-2.5">
                  {readyDocs.map((d) => (
                    <label key={d.id} className="flex items-center gap-2 text-xs text-[#CBD5E1] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedDocs.includes(d.id)}
                        onChange={() =>
                          setSelectedDocs((prev) =>
                            prev.includes(d.id)
                              ? prev.filter((id) => id !== d.id)
                              : [...prev, d.id]
                          )
                        }
                      />
                      <span className="truncate">{d.fileName}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label htmlFor="rep-notes" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {language === 'ar' ? 'نطاق التقرير وتعليمات إضافية' : 'Scope & Instructions'}
              </label>
              <textarea
                id="rep-notes"
                rows={2}
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="rep-focus-data"
                className="flex items-center gap-1.5 text-xs font-medium text-[#38BDF8] mb-1.5"
              >
                <Target size={13} />
                <span>
                  {language === 'ar'
                    ? 'بيانات يركز عليها النموذج (اختياري)'
                    : 'Model Focus Data (optional)'}
                </span>
              </label>
              <textarea
                id="rep-focus-data"
                rows={2}
                value={focusData}
                onChange={(e) => setFocusData(e.target.value)}
                placeholder={
                  language === 'ar'
                    ? 'أدخل الأرقام أو المحاور التي تريد إبرازها في التقرير...'
                    : 'Enter priority figures, KPIs, or topics to highlight in the report...'
                }
                className="w-full rounded-lg border border-[#38BDF8]/40 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={!permissions.canInvokeAI || busy}
              className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
            >
              {busy
                ? language === 'ar'
                  ? 'جاري إعداد التقرير...'
                  : 'Generating Report...'
                : t.reports.generateBtn}
            </button>
          </form>
        </div>

        {/* Generated Reports List */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F8FAFC]">
            {language === 'ar' ? 'التقارير المُنشأة' : 'Generated Reports'}
          </h3>

          {reports.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-800 bg-[#090D18]/40 p-8 text-center text-sm text-[#94A3B8]">
              {t.dashboard.emptyReports}
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((rep) => (
                <div
                  key={rep.id}
                  className="rounded-lg border border-slate-800 bg-[#090D18] p-4 flex flex-wrap items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <FileBarChart2 size={16} className="text-[#38BDF8] shrink-0" />
                      <h4 className="text-sm font-semibold text-[#F8FAFC] truncate">{rep.title}</h4>
                    </div>
                    <div className="mt-1 text-xs text-[#94A3B8] flex items-center gap-2">
                      <span className="capitalize">{rep.reportType.replace('_', ' ')}</span>
                      <span>·</span>
                      <span
                        className={
                          rep.status === 'ready'
                            ? 'text-[#22C55E]'
                            : rep.status === 'failed'
                            ? 'text-[#EF4444]'
                            : 'text-[#F59E0B]'
                        }
                      >
                        {rep.status}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {rep.status === 'ready' && rep.content && (
                      <>
                        <button
                          type="button"
                          onClick={() => setPreviewReport(rep)}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1.5 text-xs text-[#F8FAFC] hover:border-[#38BDF8]"
                        >
                          <Eye size={13} />
                          <span>{t.reports.previewBtn}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadMarkdown(rep)}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1.5 text-xs text-[#38BDF8] hover:border-[#38BDF8]"
                        >
                          <Download size={13} />
                          <span>.MD</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadHtml(rep)}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1.5 text-xs text-[#38BDF8] hover:border-[#38BDF8]"
                        >
                          <Download size={13} />
                          <span>.HTML</span>
                        </button>
                      </>
                    )}
                    {permissions.canWriteWorkspace && (
                      <button
                        type="button"
                        aria-label={`Delete ${rep.title}`}
                        onClick={() => deleteReportRecord(rep.id)}
                        className="p-1.5 rounded-lg border border-slate-800 text-[#94A3B8] hover:text-[#EF4444]"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Preview Modal */}
      {previewReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-4xl max-h-[85vh] rounded-xl border border-slate-800 bg-[#151E2E] flex flex-col overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-[#F8FAFC]">{previewReport.title}</h3>
                <p className="text-xs text-[#94A3B8] capitalize">
                  {previewReport.reportType.replace('_', ' ')}
                </p>
              </div>
              <button
                type="button"
                aria-label="Close report preview"
                onClick={() => setPreviewReport(null)}
                className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#F8FAFC]"
              >
                <X size={18} />
              </button>
            </div>
            <div className="p-6 overflow-y-auto">
              <MarkdownRenderer content={previewReport.content || ''} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
