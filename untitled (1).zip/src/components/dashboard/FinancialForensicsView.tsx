import { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  ScanSearch,
  ShieldCheck,
  Target,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { forensicsApi } from '../../lib/apiClient';
import type { ForensicSeverity, ForensicStatus } from '../../shared/types';

export function FinancialForensicsView() {
  const {
    company,
    permissions,
    structuredRecords,
    forensicFindings,
    saveForensicFindings,
    updateForensicStatus,
  } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [focusData, setFocusData] = useState(company?.modelFocusData || '');
  const [scanning, setScanning] = useState(false);
  const [scanSummary, setScanSummary] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [severityFilter, setSeverityFilter] = useState<ForensicSeverity | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<ForensicStatus | 'all'>('all');

  useEffect(() => {
    setFocusData(company?.modelFocusData || '');
  }, [company?.modelFocusData]);

  const filteredFindings = useMemo(() => {
    return forensicFindings.filter((f) => {
      if (severityFilter !== 'all' && f.severity !== severityFilter) return false;
      if (statusFilter !== 'all' && f.status !== statusFilter) return false;
      return true;
    });
  }, [forensicFindings, severityFilter, statusFilter]);

  const counts = useMemo(() => {
    return {
      total: forensicFindings.length,
      high: forensicFindings.filter((f) => f.severity === 'high' && f.status !== 'resolved').length,
      open: forensicFindings.filter((f) => f.status === 'open' || f.status === 'investigating').length,
      resolved: forensicFindings.filter((f) => f.status === 'resolved').length,
    };
  }, [forensicFindings]);

  const handleRunScan = async () => {
    if (!company || !permissions.canRunForensics) return;
    setError(null);
    setScanSummary(null);
    setScanning(true);
    try {
      const res = await forensicsApi.scan({
        companyId: company.id,
        records: structuredRecords,
        language,
        focusData: focusData.trim() || undefined,
      });

      if (res.findings.length === 0) {
        setScanSummary(
          isAr
            ? `تم فحص ${res.scannedDocuments} مستند و ${res.scannedRecords} سجل منظم — لم يتم رصد شذوذ مالي أو تكرار فواتير.`
            : `Scanned ${res.scannedDocuments} document(s) and ${res.scannedRecords} structured record(s) — no anomalies detected.`
        );
      } else {
        const saved = await saveForensicFindings(res.findings);
        setScanSummary(
          isAr
            ? `تم رصد وحفظ ${saved} ملاحظة تدقيق مالي من أصل ${res.scannedDocuments} مستند.`
            : `Detected and saved ${saved} forensic audit finding(s) across ${res.scannedDocuments} document(s).`
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Forensic scan failed.');
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            {isAr ? 'التدقيق المالي الذكي وكشف الشذوذ (Financial Forensics)' : 'Financial Forensics & Anomaly Detection'}
          </h2>
          <p className="mt-1 text-sm text-[#94A3B8]">
            {isAr
              ? 'فحص هجين يجمع القواعد الرياضية الدقيقة والذكاء الاصطناعي لكشف تكرار الفواتير، القفزات المفاجئة (>25%)، ضغط الهوامش، والمخاطر الخفية في المستندات.'
              : 'Hybrid AI & mathematical forensic audit for duplicate charges, expense spikes (>25%), margin compression, vendor variance, and statistical outliers (>2σ).'}
          </p>
        </div>

        {permissions.canRunForensics && (
          <button
            type="button"
            disabled={scanning}
            onClick={handleRunScan}
            className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
          >
            <ScanSearch size={16} />
            <span>
              {scanning
                ? isAr
                  ? 'جاري الفحص الجنائي المالي...'
                  : 'Running Forensic Scan...'
                : isAr
                ? 'تشغيل الفحص المالي الشامل'
                : 'Run Forensic Audit Scan'}
            </span>
          </button>
        )}
      </div>

      {permissions.canRunForensics && (
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-4 space-y-2">
          <label
            htmlFor="forensics-focus-data"
            className="flex items-center gap-1.5 text-xs font-medium text-[#38BDF8]"
          >
            <Target size={13} />
            <span>
              {isAr
                ? 'بيانات يركز عليها مدقق الذكاء الاصطناعي (اختياري)'
                : 'Model Focus Data for Audit (optional)'}
            </span>
          </label>
          <textarea
            id="forensics-focus-data"
            rows={2}
            value={focusData}
            onChange={(e) => setFocusData(e.target.value)}
            placeholder={
              isAr
                ? 'أدخل بنوداً أو موردين أو حسابات محددة تريد من التدقيق المالي التحقق منها بدقة...'
                : 'Specify priority vendors, cost centers, or suspected variances for AI forensic review...'
            }
            className="w-full rounded-lg border border-[#38BDF8]/40 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
          />
        </div>
      )}

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3.5 text-xs text-[#FCA5A5]">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {scanSummary && (
        <div className="flex items-start gap-2 rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3.5 text-xs text-[#86EFAC]">
          <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
          <span>{scanSummary}</span>
        </div>
      )}

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs text-[#94A3B8]">{isAr ? 'إجمالي الملاحظات' : 'Total Findings'}</div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {counts.total}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs text-[#94A3B8]">{isAr ? 'مخاطر مرتفعة نشطة' : 'Active High Severity'}</div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#EF4444] tabular-nums">
            {counts.high}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs text-[#94A3B8]">{isAr ? 'قيد المتابعة والتحقيق' : 'Open / Investigating'}</div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F59E0B] tabular-nums">
            {counts.open}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs text-[#94A3B8]">{isAr ? 'حالات تم حلها' : 'Resolved'}</div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#22C55E] tabular-nums">
            {counts.resolved}
          </div>
        </div>
      </div>

      {/* Filters & Findings List */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-sm font-semibold text-[#F8FAFC]">
            {isAr ? 'سجل نتائج التدقيق المالي' : 'Forensic Findings Ledger'}
          </h3>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <select
              aria-label="Filter severity"
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value as ForensicSeverity | 'all')}
              className="rounded-lg border border-slate-700 bg-[#090D18] px-3 py-1.5 text-xs text-[#F8FAFC]"
            >
              <option value="all">{isAr ? 'كل مستويات الخطورة' : 'All Severities'}</option>
              <option value="high">{isAr ? 'مرتفع' : 'High'}</option>
              <option value="medium">{isAr ? 'متوسط' : 'Medium'}</option>
              <option value="low">{isAr ? 'منخفض' : 'Low'}</option>
            </select>
            <select
              aria-label="Filter status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as ForensicStatus | 'all')}
              className="rounded-lg border border-slate-700 bg-[#090D18] px-3 py-1.5 text-xs text-[#F8FAFC]"
            >
              <option value="all">{isAr ? 'كل الحالات' : 'All Statuses'}</option>
              <option value="open">{isAr ? 'مفتوح' : 'Open'}</option>
              <option value="investigating">{isAr ? 'قيد التحقيق' : 'Investigating'}</option>
              <option value="resolved">{isAr ? 'تم الحل' : 'Resolved'}</option>
              <option value="dismissed">{isAr ? 'مستبعد' : 'Dismissed'}</option>
            </select>
          </div>
        </div>

        {filteredFindings.length === 0 ? (
          <div className="rounded-lg border border-dashed border-slate-800 bg-[#090D18]/40 p-10 text-center space-y-2">
            <ShieldCheck size={24} className="mx-auto text-[#38BDF8]" />
            <p className="text-sm text-[#94A3B8]">
              {isAr
                ? 'لا توجد نتائج تدقيق مطابقة حالياً. ارفع كشوف المصروفات والمبيعات ثم اضغط «تشغيل الفحص المالي الشامل».'
                : 'No forensic findings matching the current filter. Upload financial spreadsheets or statements and click Run Forensic Audit Scan.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredFindings.map((finding) => {
              const sevColor =
                finding.severity === 'high'
                  ? 'text-[#EF4444] border-[#EF4444]/40'
                  : finding.severity === 'medium'
                  ? 'text-[#F59E0B] border-[#F59E0B]/40'
                  : 'text-[#38BDF8] border-[#38BDF8]/40';

              return (
                <div
                  key={finding.id}
                  className="rounded-xl border border-slate-800 bg-[#090D18] p-4 space-y-3"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <AlertTriangle
                        size={17}
                        className={`shrink-0 mt-0.5 ${
                          finding.severity === 'high'
                            ? 'text-[#EF4444]'
                            : finding.severity === 'medium'
                            ? 'text-[#F59E0B]'
                            : 'text-[#38BDF8]'
                        }`}
                      />
                      <div>
                        <h4 className="text-sm font-semibold text-[#F8FAFC]">
                          {isAr ? finding.titleAr : finding.titleEn}
                        </h4>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] font-mono text-[#94A3B8]">
                          <span className={`uppercase font-semibold border rounded px-1.5 py-0.5 ${sevColor}`}>
                            {finding.severity}
                          </span>
                          <span>{finding.category.replace(/_/g, ' ')}</span>
                          <span>·</span>
                          <span>
                            {finding.sourceDocumentName} ({finding.sourceLocation})
                          </span>
                        </div>
                      </div>
                    </div>

                    {permissions.canRunForensics ? (
                      <select
                        aria-label={`Status for ${finding.titleEn}`}
                        value={finding.status}
                        onChange={(e) =>
                          updateForensicStatus(finding.id, e.target.value as ForensicStatus)
                        }
                        className="rounded-lg border border-slate-700 bg-[#111827] px-2.5 py-1.5 text-xs text-[#F8FAFC]"
                      >
                        <option value="open">{isAr ? 'مفتوح' : 'Open'}</option>
                        <option value="investigating">{isAr ? 'قيد التحقيق' : 'Investigating'}</option>
                        <option value="resolved">{isAr ? 'تم الحل' : 'Resolved'}</option>
                        <option value="dismissed">{isAr ? 'مستبعد' : 'Dismissed'}</option>
                      </select>
                    ) : (
                      <span className="text-xs font-mono capitalize text-[#38BDF8]">
                        {finding.status}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-[#CBD5E1] leading-relaxed">
                    {isAr ? finding.descriptionAr : finding.descriptionEn}
                  </p>

                  <div className="rounded-lg border border-slate-800 bg-[#111827] p-3 text-[11px] font-mono text-[#94A3B8]">
                    <span className="text-[#38BDF8] font-semibold">
                      {isAr ? 'الأدلة المستخرجة:' : 'Evidence:'}{' '}
                    </span>
                    {finding.evidence}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
