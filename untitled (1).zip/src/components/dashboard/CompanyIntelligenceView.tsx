import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  Brain,
  CheckCircle2,
  Database,
  FileSearch,
  Save,
  Search,
  ShieldAlert,
  Target,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { intelligenceApi } from '../../lib/apiClient';
import {
  computePeriodAnalytics,
  WORKSPACE_DATA_DOMAINS,
  type RankedChunkResult,
} from '../../shared/intelligenceEngine';
import type { WorkspaceDataDomain } from '../../shared/types';
import { MarkdownRenderer } from '../MarkdownRenderer';

export function CompanyIntelligenceView() {
  const {
    company,
    permissions,
    documents,
    structuredRecords,
    knowledgeChunks,
    updateCompanyGovernance,
    updateRecordVerification,
    logAuditEvent,
  } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  // Company Context, Strategic Goals & Model Focus Data editor
  const [summaryInput, setSummaryInput] = useState(company?.companySummary || '');
  const [goalsInput, setGoalsInput] = useState((company?.strategicGoals || []).join('\n'));
  const [focusDataInput, setFocusDataInput] = useState(company?.modelFocusData || '');
  const [savingContext, setSavingContext] = useState(false);
  const [contextSaved, setContextSaved] = useState(false);

  useEffect(() => {
    setSummaryInput(company?.companySummary || '');
    setGoalsInput((company?.strategicGoals || []).join('\n'));
    setFocusDataInput(company?.modelFocusData || '');
  }, [company?.companySummary, company?.strategicGoals, company?.modelFocusData]);

  // RAG Vector Search
  const [ragQuery, setRagQuery] = useState('');
  const [ragDomain, setRagDomain] = useState<WorkspaceDataDomain | 'all'>('all');
  const [searching, setSearching] = useState(false);
  const [ragAnswer, setRagAnswer] = useState<string | null>(null);
  const [ragHits, setRagHits] = useState<RankedChunkResult[]>([]);
  const [ragMeta, setRagMeta] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Structured records filter
  const [recordDomainFilter, setRecordDomainFilter] = useState<WorkspaceDataDomain | 'all'>('all');
  const [recordStatusFilter, setRecordStatusFilter] = useState<'all' | 'pending_review' | 'verified' | 'disputed'>('all');

  const analytics = useMemo(
    () => computePeriodAnalytics(structuredRecords),
    [structuredRecords]
  );

  const filteredRecords = useMemo(() => {
    return structuredRecords.filter((r) => {
      if (recordDomainFilter !== 'all' && r.domain !== recordDomainFilter) return false;
      if (recordStatusFilter !== 'all' && r.verificationStatus !== recordStatusFilter) return false;
      return true;
    });
  }, [structuredRecords, recordDomainFilter, recordStatusFilter]);

  const handleSaveContext = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.canManageCompany) return;
    setSavingContext(true);
    setContextSaved(false);
    setError(null);
    try {
      await updateCompanyGovernance({
        companySummary: summaryInput,
        strategicGoals: goalsInput
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        modelFocusData: focusDataInput,
      });
      setContextSaved(true);
      setTimeout(() => setContextSaved(false), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save company context.');
    } finally {
      setSavingContext(false);
    }
  };

  const handleRagSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company || !ragQuery.trim() || !permissions.canInvokeAI) return;
    setError(null);
    setSearching(true);
    try {
      const res = await intelligenceApi.query({
        companyId: company.id,
        question: ragQuery.trim(),
        domain: ragDomain,
        language,
        focusData: focusDataInput.trim() || undefined,
        records: structuredRecords,
        chunks: knowledgeChunks,
      });
      setRagAnswer(res.answer);
      setRagHits(res.hits);
      setRagMeta(`${res.hits.length} ${isAr ? 'مقتطف مرجعي' : 'referenced sources'}`);
      await logAuditEvent({
        action: 'rag_query',
        targetType: 'companyMemory',
        targetId: company.id,
        summary: `Queried Company Memory (${ragDomain}): "${ragQuery.trim().slice(0, 80)}"`,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Memory search failed.');
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-[#F8FAFC]">
          {isAr ? 'ذاكرة وذكاء الشركة (Company Intelligence Memory)' : 'Company Intelligence Memory'}
        </h2>
        <p className="mt-1 text-sm text-[#94A3B8]">
          {isAr
            ? 'البيانات المرفوعة تُحفظ وتُفهرس مرة واحدة عبر 7 مجالات أعمال — ابحث، قارن الفترات، وتحقق من مصادر كل رقم دون إعادة الرفع.'
            : 'Upload once, analyze continuously across 7 business domains. Search indexed document chunks, compare historical periods, and verify record provenance.'}
        </p>
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3.5 text-xs text-[#FCA5A5]">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Memory Architecture KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'المستندات المخزنة' : 'Stored Documents'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {documents.length}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8]">
            {isAr ? 'ملفات أصلية ومستخلصة' : 'Original + extracted store'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'مقاطع البحث الدلالي (RAG)' : 'Indexed Knowledge Chunks'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#38BDF8] tabular-nums">
            {knowledgeChunks.length}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8]">
            {isAr ? 'مفهرسة بالصفحة والورقة' : 'Page & sheet indexed'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'السجلات المنظمة المستخرجة' : 'Structured Records'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {analytics.totalRecords}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8] font-mono tabular-nums">
            {analytics.verifiedCount} {isAr ? 'موثق' : 'verified'} · {analytics.pendingCount}{' '}
            {isAr ? 'قيد المراجعة' : 'pending'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="text-xs font-medium text-[#94A3B8]">
            {isAr ? 'الفترات التاريخية المرصودة' : 'Historical Periods'}
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#22C55E] tabular-nums">
            {analytics.periods.length}
          </div>
          <div className="mt-1 text-xs text-[#94A3B8]">
            {analytics.profitMarginPct !== null
              ? `${isAr ? 'هامش صافي الربح:' : 'Net margin:'} ${analytics.profitMarginPct}%`
              : isAr
              ? 'ارفع بيانات مالية لحساب الهامش'
              : 'Upload financial data for margin'}
          </div>
        </div>
      </div>

      {/* 7 Business Data Domains Coverage */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
        <div className="flex items-center gap-2 text-[#38BDF8]">
          <Database size={17} />
          <h3 className="text-sm font-semibold text-[#F8FAFC]">
            {isAr ? 'تغطية مجالات بيانات الشركة (7 أقسام)' : 'Company Workspace Coverage Across 7 Business Domains'}
          </h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {WORKSPACE_DATA_DOMAINS.map((dom) => {
            const docCount = documents.filter((d) => (d.domain || 'finance') === dom.id).length;
            const recCount = analytics.domainCounts[dom.id] || 0;
            return (
              <div
                key={dom.id}
                className="rounded-lg border border-slate-800 bg-[#090D18] p-3.5 flex flex-col justify-between gap-2"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold text-[#F8FAFC]">
                      {isAr ? dom.nameAr : dom.nameEn}
                    </span>
                    <span className="font-mono text-xs text-[#38BDF8] tabular-nums">
                      {docCount} {isAr ? 'ملف' : 'docs'}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-[#94A3B8]">
                    {isAr ? dom.examplesAr : dom.examplesEn}
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-[#CBD5E1] tabular-nums">
                  {recCount} {isAr ? 'سجل رقمي مستخرج' : 'extracted records'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* RAG Search & Ask Company Memory + Company Context Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Ask / Search Company Memory */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <div className="flex items-center gap-2 text-[#38BDF8]">
            <FileSearch size={17} />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              {isAr ? 'البحث الذكي داخل ذاكرة الشركة (Vector / RAG Search)' : 'Query Company Memory (RAG Search & Root-Cause Analysis)'}
            </h3>
          </div>

          <form onSubmit={handleRagSearch} className="space-y-3">
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Search size={14} className="absolute top-3 start-3 text-[#94A3B8]" />
                <input
                  type="text"
                  disabled={!permissions.canInvokeAI}
                  value={ragQuery}
                  onChange={(e) => setRagQuery(e.target.value)}
                  placeholder={
                    isAr
                      ? 'مثال: ليه أرباحنا قلت الشهر ده؟ أو قارن المصروفات والمبيعات...'
                      : 'e.g., Why did our profits drop this month? Compare revenue vs expenses...'
                  }
                  className="w-full rounded-lg border border-slate-700 bg-[#090D18] ps-9 pe-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none disabled:opacity-60"
                />
              </div>
              <select
                aria-label={isAr ? 'تصفية المجال' : 'Filter domain'}
                disabled={!permissions.canInvokeAI}
                value={ragDomain}
                onChange={(e) => setRagDomain(e.target.value as WorkspaceDataDomain | 'all')}
                className="rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] disabled:opacity-60"
              >
                <option value="all">{isAr ? 'كل المجالات' : 'All Domains'}</option>
                {WORKSPACE_DATA_DOMAINS.map((d) => (
                  <option key={d.id} value={d.id}>
                    {isAr ? d.nameAr : d.nameEn}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                disabled={!permissions.canInvokeAI || searching || !ragQuery.trim()}
                className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50 shrink-0"
              >
                {searching
                  ? isAr
                    ? 'جاري البحث...'
                    : 'Searching...'
                  : isAr
                  ? 'تحليل من الذاكرة'
                  : 'Query Memory'}
              </button>
            </div>
            {!permissions.canInvokeAI && (
              <p className="text-[11px] text-[#F59E0B]">
                {isAr
                  ? 'دور المشاهد للقراءة فقط. يلزم صلاحية محلل أو أعلى لتشغيل استعلامات الذكاء الاصطناعي.'
                  : 'Viewer role is read-only. Analyst or higher permissions are required to execute AI memory queries.'}
              </p>
            )}
          </form>

          {/* Suggested starter question */}
          <div className="flex flex-wrap gap-2">
            {(isAr
              ? [
                  'ليه أرباحنا قلت الشهر ده؟',
                  'ما هي أعلى بنود المصروفات مقارنة بالإيرادات؟',
                  'لخّص أهم الملاحظات في مستندات الشركة',
                ]
              : [
                  'Why did our net profit decrease across recent periods?',
                  'Which expense categories grew faster than revenue?',
                  'Summarize key findings across all uploaded documents',
                ]
            ).map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => setRagQuery(q)}
                className="rounded-md border border-slate-800 bg-[#090D18] px-2.5 py-1 text-[11px] text-[#CBD5E1] hover:border-[#38BDF8]"
              >
                {q}
              </button>
            ))}
          </div>

          {ragAnswer && (
            <div className="rounded-lg border border-slate-800 bg-[#090D18] p-4 space-y-3">
              {ragMeta && (
                <div className="text-[11px] font-mono text-[#38BDF8] border-b border-slate-800 pb-2">
                  {ragMeta}
                </div>
              )}
              <MarkdownRenderer content={ragAnswer} />
              {ragHits.length > 0 && (
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="text-xs font-semibold text-[#CBD5E1]">
                    {isAr ? 'المقاطع المرجعية المسترجعة:' : 'Retrieved Source Citations:'}
                  </div>
                  {ragHits.map((h) => (
                    <div
                      key={h.chunk.id}
                      className="rounded-md border border-slate-800 bg-[#111827] p-2.5 text-xs"
                    >
                      <div className="flex items-center justify-between text-[#38BDF8] font-mono text-[11px]">
                        <span>
                          {h.chunk.documentName} · {h.chunk.locationLabel}
                        </span>
                        <span>score {h.score}</span>
                      </div>
                      <p className="mt-1 text-[#CBD5E1] line-clamp-2">{h.chunk.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Company Context & Strategic Goals */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <div className="flex items-center gap-2 text-[#38BDF8]">
            <Brain size={17} />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              {isAr ? 'سياق الشركة والأهداف الاستراتيجية' : 'Company Context & Strategic Goals'}
            </h3>
          </div>

          <form onSubmit={handleSaveContext} className="space-y-3">
            <div>
              <label htmlFor="comp-summary" className="block text-xs font-medium text-[#CBD5E1] mb-1">
                {isAr ? 'ملخص نشاط الشركة ونموذج العمل' : 'Company Activity & Business Model Summary'}
              </label>
              <textarea
                id="comp-summary"
                rows={4}
                disabled={!permissions.canManageCompany}
                value={summaryInput}
                onChange={(e) => setSummaryInput(e.target.value)}
                placeholder={
                  isAr
                    ? 'اكتب وصفاً مختصراً لطبيعة نشاط الشركة وأهم مصادر الإيراد والتكاليف...'
                    : 'Describe core business lines, revenue streams, and operational footprint...'
                }
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none disabled:opacity-60"
              />
            </div>

            <div>
              <label htmlFor="comp-goals" className="block text-xs font-medium text-[#CBD5E1] mb-1">
                {isAr ? 'الأهداف الاستراتيجية (هدف واحد في كل سطر)' : 'Strategic Goals (one per line)'}
              </label>
              <textarea
                id="comp-goals"
                rows={3}
                disabled={!permissions.canManageCompany}
                value={goalsInput}
                onChange={(e) => setGoalsInput(e.target.value)}
                placeholder={
                  isAr
                    ? 'رفع هامش الربح بنسبة 8%\nتقليل مصروفات المشتريات بنسبة 10%'
                    : 'Increase net profit margin by 8%\nReduce procurement cost variance by 10%'
                }
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none disabled:opacity-60"
              />
            </div>

            <div>
              <label
                htmlFor="comp-focus-data"
                className="flex items-center gap-1.5 text-xs font-medium text-[#38BDF8] mb-1"
              >
                <Target size={13} />
                <span>
                  {isAr
                    ? 'بيانات يركز عليها النموذج (أولويات التحليل والأرقام المرجعية)'
                    : 'Model Focus Data (Priority KPIs, numbers & constraints)'}
                </span>
              </label>
              <textarea
                id="comp-focus-data"
                rows={3}
                disabled={!permissions.canInvokeAI && !permissions.canManageCompany}
                value={focusDataInput}
                onChange={(e) => setFocusDataInput(e.target.value)}
                placeholder={
                  isAr
                    ? 'أدخل الأرقام أو البيانات التي تريد أن يركز عليها النموذج أثناء التحليل والبحث...'
                    : 'Enter priority metrics, budgets, or specific items for the model to emphasize...'
                }
                className="w-full rounded-lg border border-[#38BDF8]/40 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none disabled:opacity-60"
              />
            </div>

            {permissions.canManageCompany && (
              <div className="flex items-center justify-between gap-2">
                <button
                  type="submit"
                  disabled={savingContext}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
                >
                  <Save size={14} />
                  <span>{isAr ? 'حفظ سياق الشركة' : 'Save Company Context'}</span>
                </button>
                {contextSaved && (
                  <span className="text-xs text-[#22C55E]">
                    {isAr ? 'تم الحفظ في ذاكرة الشركة' : 'Saved to Company Memory'}
                  </span>
                )}
              </div>
            )}
          </form>

          {/* Historical Period Comparison Summary */}
          {analytics.periods.length > 0 && (
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-[#F8FAFC]">
                {isAr ? 'مقارنة الفترات التاريخية' : 'Period-over-Period Comparison'}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg border border-slate-800 bg-[#090D18] p-2.5">
                  <div className="text-[#94A3B8]">{isAr ? 'نمو الإيرادات' : 'Revenue Trend'}</div>
                  <div className="mt-1 font-mono font-bold flex items-center gap-1 tabular-nums text-[#F8FAFC]">
                    {analytics.revenueGrowthPct !== null ? (
                      <>
                        {analytics.revenueGrowthPct >= 0 ? (
                          <TrendingUp size={13} className="text-[#22C55E]" />
                        ) : (
                          <TrendingDown size={13} className="text-[#EF4444]" />
                        )}
                        <span>{analytics.revenueGrowthPct}%</span>
                      </>
                    ) : (
                      <span>—</span>
                    )}
                  </div>
                </div>
                <div className="rounded-lg border border-slate-800 bg-[#090D18] p-2.5">
                  <div className="text-[#94A3B8]">{isAr ? 'نمو المصروفات' : 'Expense Trend'}</div>
                  <div className="mt-1 font-mono font-bold flex items-center gap-1 tabular-nums text-[#F8FAFC]">
                    {analytics.expenseGrowthPct !== null ? (
                      <>
                        {analytics.expenseGrowthPct > 0 ? (
                          <TrendingUp size={13} className="text-[#F59E0B]" />
                        ) : (
                          <TrendingDown size={13} className="text-[#22C55E]" />
                        )}
                        <span>{analytics.expenseGrowthPct}%</span>
                      </>
                    ) : (
                      <span>—</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Structured Database Provenance & Verification Table */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              {isAr
                ? 'قاعدة البيانات المنظمة وسلسلة التوثيق (Data Provenance & Verification)'
                : 'Structured Database & Source Provenance Verification'}
            </h3>
            <p className="text-xs text-[#94A3B8]">
              {isAr
                ? 'كل رقم مستخرج يبدأ بحالة «قيد المراجعة» مع حفظ اسم المستند ورقم الصفحة/الصف — وثّق الأرقام المعتمدة أو اعترض على القيم الخاطئة.'
                : 'Extracted figures default to Pending Review with exact document & page/row citations. Verify accurate figures or mark discrepancies as Disputed.'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <select
              aria-label="Filter record domain"
              value={recordDomainFilter}
              onChange={(e) => setRecordDomainFilter(e.target.value as WorkspaceDataDomain | 'all')}
              className="rounded-lg border border-slate-700 bg-[#090D18] px-3 py-1.5 text-xs text-[#F8FAFC]"
            >
              <option value="all">{isAr ? 'كل المجالات' : 'All Domains'}</option>
              {WORKSPACE_DATA_DOMAINS.map((d) => (
                <option key={d.id} value={d.id}>
                  {isAr ? d.nameAr : d.nameEn}
                </option>
              ))}
            </select>
            <select
              aria-label="Filter verification status"
              value={recordStatusFilter}
              onChange={(e) =>
                setRecordStatusFilter(
                  e.target.value as 'all' | 'pending_review' | 'verified' | 'disputed'
                )
              }
              className="rounded-lg border border-slate-700 bg-[#090D18] px-3 py-1.5 text-xs text-[#F8FAFC]"
            >
              <option value="all">{isAr ? 'كل الحالات' : 'All Statuses'}</option>
              <option value="pending_review">{isAr ? 'قيد المراجعة' : 'Pending Review'}</option>
              <option value="verified">{isAr ? 'موثق' : 'Verified'}</option>
              <option value="disputed">{isAr ? 'متنازع عليه' : 'Disputed'}</option>
            </select>
          </div>
        </div>

        {filteredRecords.length === 0 ? (
          <div className="rounded-lg border border-dashed border-slate-800 bg-[#090D18]/40 p-8 text-center text-sm text-[#94A3B8]">
            {isAr
              ? 'لا توجد سجلات منظمة بعد. ارفع ملفات XLSX أو CSV أو PDF من قسم Document Intelligence ليتم استخراج الأرقام وفهرستها هنا.'
              : 'No structured records indexed yet. Upload XLSX, CSV, PDF, or DOCX files in Document Intelligence to populate structured company tables.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-[#94A3B8]">
                  <th className="py-2.5 px-3 text-start font-medium">{isAr ? 'الفترة' : 'Period'}</th>
                  <th className="py-2.5 px-3 text-start font-medium">{isAr ? 'المجال' : 'Domain'}</th>
                  <th className="py-2.5 px-3 text-start font-medium">{isAr ? 'المؤشر / البند' : 'Metric / Category'}</th>
                  <th className="py-2.5 px-3 text-end font-medium">{isAr ? 'القيمة' : 'Value'}</th>
                  <th className="py-2.5 px-3 text-start font-medium">{isAr ? 'المصدر الموثق' : 'Source Provenance'}</th>
                  <th className="py-2.5 px-3 text-start font-medium">{isAr ? 'الحالة' : 'Status'}</th>
                  {permissions.canVerifyRecords && (
                    <th className="py-2.5 px-3 text-end font-medium">{isAr ? 'إجراء' : 'Verify'}</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredRecords.slice(0, 60).map((rec) => (
                  <tr key={rec.id}>
                    <td className="py-2.5 px-3 font-mono text-[#CBD5E1] whitespace-nowrap">
                      {rec.periodKey}
                    </td>
                    <td className="py-2.5 px-3 capitalize text-[#38BDF8]">{rec.domain}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-medium text-[#F8FAFC]">{rec.metricLabel}</div>
                      <div className="text-[11px] text-[#94A3B8]">{rec.category}</div>
                    </td>
                    <td className="py-2.5 px-3 text-end font-mono font-semibold text-[#F8FAFC] tabular-nums whitespace-nowrap">
                      {rec.numericValue.toLocaleString()}
                      {rec.unit === '%' ? '%' : ''}
                    </td>
                    <td className="py-2.5 px-3 text-[#CBD5E1]">
                      <div className="truncate max-w-[200px]">{rec.sourceDocumentName}</div>
                      <div className="text-[11px] font-mono text-[#94A3B8]">{rec.sourceLocation}</div>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`text-[11px] font-semibold ${
                          rec.verificationStatus === 'verified'
                            ? 'text-[#22C55E]'
                            : rec.verificationStatus === 'disputed'
                            ? 'text-[#EF4444]'
                            : 'text-[#F59E0B]'
                        }`}
                      >
                        {rec.verificationStatus === 'verified'
                          ? isAr
                            ? 'موثق'
                            : 'Verified'
                          : rec.verificationStatus === 'disputed'
                          ? isAr
                            ? 'متنازع عليه'
                            : 'Disputed'
                          : isAr
                          ? 'قيد المراجعة'
                          : 'Pending Review'}
                      </span>
                    </td>
                    {permissions.canVerifyRecords && (
                      <td className="py-2.5 px-3 text-end whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => updateRecordVerification(rec.id, 'verified')}
                            title={isAr ? 'توثيق الرقم' : 'Verify'}
                            className="inline-flex items-center gap-1 rounded border border-slate-700 px-2 py-1 text-[11px] text-[#22C55E] hover:border-[#22C55E]"
                          >
                            <CheckCircle2 size={12} />
                            <span>{isAr ? 'توثيق' : 'Verify'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => updateRecordVerification(rec.id, 'disputed')}
                            title={isAr ? 'رفض / اعتراض' : 'Dispute'}
                            className="inline-flex items-center gap-1 rounded border border-slate-700 px-2 py-1 text-[11px] text-[#EF4444] hover:border-[#EF4444]"
                          >
                            <ShieldAlert size={12} />
                            <span>{isAr ? 'اعتراض' : 'Dispute'}</span>
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
