import React, { useEffect, useMemo, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { billingApi } from '../../lib/apiClient';
import { getCurrentMonthKey } from '../../shared/financeUtils';
import { evaluateQuotaStatus } from '../../shared/plans';
import type { CompanySize, Language, PlanId } from '../../shared/types';

export function SettingsView() {
  const {
    user,
    userProfile,
    company,
    currentMember,
    permissions,
    usageLogs,
    updateCompanyProfile,
    updateUserSettings,
  } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const isAr = language === 'ar';

  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [emailNotifications, setEmailNotifications] = useState(
    userProfile?.emailNotifications ?? true
  );
  const [usageAlerts, setUsageAlerts] = useState(userProfile?.usageAlerts ?? true);

  const [companyName, setCompanyName] = useState(company?.name || '');
  const [industry, setIndustry] = useState(company?.industry || '');
  const [size, setSize] = useState<CompanySize>(company?.size || '11-50');
  const [country, setCountry] = useState(company?.country || '');
  const [companyLang, setCompanyLang] = useState<Language>(company?.preferredLanguage || 'en');
  const [logoUrl, setLogoUrl] = useState(company?.logoUrl || '');

  const [tokenLimit, setTokenLimit] = useState(company?.monthlyTokenLimit || 250000);
  const [requestLimit, setRequestLimit] = useState(company?.monthlyRequestLimit || 250);

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (userProfile) {
      setDisplayName(userProfile.displayName);
      setEmailNotifications(userProfile.emailNotifications ?? true);
      setUsageAlerts(userProfile.usageAlerts ?? true);
    }
  }, [userProfile]);

  useEffect(() => {
    if (company) {
      setCompanyName(company.name);
      setIndustry(company.industry);
      setSize(company.size);
      setCountry(company.country);
      setCompanyLang(company.preferredLanguage);
      setLogoUrl(company.logoUrl || '');
      setTokenLimit(company.monthlyTokenLimit);
      setRequestLimit(company.monthlyRequestLimit);
    }
  }, [company]);

  const monthKey = getCurrentMonthKey();
  const monthLogs = useMemo(
    () => usageLogs.filter((l) => l.monthKey === monthKey),
    [usageLogs, monthKey]
  );
  const tokensUsed = monthLogs.reduce(
    (s, l) => s + (l.inputTokens || 0) + (l.outputTokens || 0),
    0
  );
  const quota = evaluateQuotaStatus(
    tokensUsed,
    monthLogs.length,
    company?.monthlyTokenLimit || 250000,
    company?.monthlyRequestLimit || 250
  );

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    setErrorMsg(null);
    try {
      await updateUserSettings({
        displayName: displayName.trim(),
        preferredLanguage: language,
        emailNotifications,
        usageAlerts,
      });
      setSaved(true);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save profile settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.canManageCompany) return;
    setSaving(true);
    setSaved(false);
    setErrorMsg(null);
    try {
      await updateCompanyProfile({
        name: companyName.trim(),
        industry: industry.trim(),
        size,
        country: country.trim(),
        preferredLanguage: companyLang,
        logoUrl,
      });
      setSaved(true);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save company settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveLimits = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company || !permissions.canManageCompany) return;
    setSaving(true);
    setSaved(false);
    setErrorMsg(null);
    try {
      await billingApi.updateCompanyLimits({
        companyId: company.id,
        planId: company.planId as PlanId,
        monthlyTokenLimit: Number(tokenLimit),
        monthlyRequestLimit: Number(requestLimit),
      });
      setSaved(true);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to update usage limits.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-[#F8FAFC]">{t.settings.title}</h2>
      </div>

      {errorMsg && (
        <div className="rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-[#FCA5A5]">
          {errorMsg}
        </div>
      )}

      {saved && (
        <div className="flex items-center gap-2 rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3 text-xs text-[#86EFAC]">
          <CheckCircle2 size={15} />
          <span>{t.settings.savedMsg}</span>
        </div>
      )}

      {/* User Profile, Language & Notification Preferences */}
      <form
        onSubmit={handleSaveProfile}
        className="rounded-xl border border-slate-800 bg-[#151E2E] p-6 space-y-4"
      >
        <h3 className="text-sm font-semibold text-[#F8FAFC]">
          {t.settings.profileTab} & {t.settings.preferencesTab}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="set-name" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
              {t.auth.fullNameLabel}
            </label>
            <input
              id="set-name"
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC]"
            />
          </div>
          <div>
            <label htmlFor="set-lang" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
              {t.onboarding.preferredLanguage}
            </label>
            <select
              id="set-lang"
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC]"
            >
              <option value="en">English (LTR)</option>
              <option value="ar">العربية (RTL)</option>
            </select>
          </div>
        </div>

        <div className="space-y-2 pt-2 text-xs text-[#CBD5E1]">
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={emailNotifications}
              onChange={(e) => setEmailNotifications(e.target.checked)}
            />
            <span>
              {isAr
                ? 'استلام إشعارات البريد للتقارير والدعوات'
                : 'Email notifications for completed reports and invites'}
            </span>
          </label>
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={usageAlerts}
              onChange={(e) => setUsageAlerts(e.target.checked)}
            />
            <span>
              {isAr
                ? 'تنبيهات عند الاقتراب من حد الاستهلاك الشهري'
                : 'Usage threshold alerts when approaching monthly limit'}
            </span>
          </label>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB]"
        >
          {t.settings.saveBtn}
        </button>
      </form>

      {/* Company Settings */}
      <form
        onSubmit={handleSaveCompany}
        className="rounded-xl border border-slate-800 bg-[#151E2E] p-6 space-y-4"
      >
        <h3 className="text-sm font-semibold text-[#F8FAFC]">{t.settings.companyTab}</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="set-co-name" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
              {t.onboarding.companyName}
            </label>
            <input
              id="set-co-name"
              type="text"
              disabled={!permissions.canManageCompany}
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC] disabled:opacity-60"
            />
          </div>
          <div>
            <label htmlFor="set-co-ind" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
              {t.onboarding.industry}
            </label>
            <input
              id="set-co-ind"
              type="text"
              disabled={!permissions.canManageCompany}
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC] disabled:opacity-60"
            />
          </div>
          <div>
            <label htmlFor="set-co-size" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
              {t.onboarding.companySize}
            </label>
            <select
              id="set-co-size"
              disabled={!permissions.canManageCompany}
              value={size}
              onChange={(e) => setSize(e.target.value as CompanySize)}
              className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC] disabled:opacity-60"
            >
              <option value="1-10">1-10</option>
              <option value="11-50">11-50</option>
              <option value="51-200">51-200</option>
              <option value="201-1000">201-1000</option>
              <option value="1000+">1000+</option>
            </select>
          </div>
          <div>
            <label htmlFor="set-co-country" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
              {t.onboarding.country}
            </label>
            <input
              id="set-co-country"
              type="text"
              disabled={!permissions.canManageCompany}
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC] disabled:opacity-60"
            />
          </div>
        </div>

        <div>
          <label htmlFor="set-co-logo" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
            {isAr ? 'رابط شعار الشركة (اختياري)' : 'Company Logo URL (optional)'}
          </label>
          <input
            id="set-co-logo"
            type="url"
            disabled={!permissions.canManageCompany}
            value={logoUrl}
            onChange={(e) => setLogoUrl(e.target.value)}
            placeholder="https://..."
            className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs text-[#F8FAFC] disabled:opacity-60"
          />
        </div>

        {permissions.canManageCompany && (
          <button
            type="submit"
            disabled={saving}
            className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB]"
          >
            {t.settings.saveBtn}
          </button>
        )}
      </form>

      {/* Workspace Limits */}
      {company && (
        <form
          onSubmit={handleSaveLimits}
          className="rounded-xl border border-slate-800 bg-[#151E2E] p-6 space-y-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              {isAr ? 'حدود الاستخدام الشهرية لمساحة العمل' : 'Workspace Monthly Quotas'}
            </h3>
            <span className="text-xs font-mono text-[#38BDF8] tabular-nums">
              {monthLogs.length} / {company.monthlyRequestLimit.toLocaleString()}{' '}
              {isAr ? 'طلب' : 'requests'} · {quota.tokensRemaining.toLocaleString()}{' '}
              {isAr ? 'متبقي' : 'remaining'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="set-tok-limit" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {t.billing.tokenLimitLabel}
              </label>
              <input
                id="set-tok-limit"
                type="number"
                min={1000}
                disabled={!permissions.canManageCompany}
                value={tokenLimit}
                onChange={(e) => setTokenLimit(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs font-mono text-[#F8FAFC] disabled:opacity-60"
              />
            </div>
            <div>
              <label htmlFor="set-req-limit" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {t.billing.requestLimitLabel}
              </label>
              <input
                id="set-req-limit"
                type="number"
                min={10}
                disabled={!permissions.canManageCompany}
                value={requestLimit}
                onChange={(e) => setRequestLimit(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2 text-xs font-mono text-[#F8FAFC] disabled:opacity-60"
              />
            </div>
          </div>

          {permissions.canManageCompany && (
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB]"
            >
              {t.billing.saveLimitsBtn}
            </button>
          )}
        </form>
      )}

      {/* Security Session Overview */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-6 space-y-3 text-xs">
        <h3 className="text-sm font-semibold text-[#F8FAFC]">{t.settings.securityTab}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3">
            <div className="text-[#94A3B8]">{isAr ? 'البريد الموثق' : 'Authenticated Email'}</div>
            <div className="mt-1 font-mono text-[#F8FAFC] truncate">{user?.email}</div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3">
            <div className="text-[#94A3B8]">{isAr ? 'حالة التوثيق' : 'Email Verification'}</div>
            <div className="mt-1 font-semibold text-[#22C55E]">
              {user?.emailVerified ? (isAr ? 'موثق' : 'Verified') : isAr ? 'قيد الانتظار' : 'Pending'}
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-[#090D18] p-3">
            <div className="text-[#94A3B8]">{isAr ? 'الدور الوظيفي' : 'Company Role'}</div>
            <div className="mt-1 font-semibold capitalize text-[#38BDF8]">
              {currentMember?.role || 'viewer'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
