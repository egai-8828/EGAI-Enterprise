import React, { useState } from 'react';
import {
  BarChart2,
  Brain,
  FileBarChart2,
  FileText,
  Globe,
  LayoutDashboard,
  Lightbulb,
  LogOut,
  Menu,
  MessageSquare,
  PanelLeftClose,
  PanelLeftOpen,
  ScanSearch,
  Settings,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { BrandLogo } from '../BrandMark';

export type DashboardSection =
  | 'intelligence'
  | 'workspace'
  | 'overview'
  | 'forensics'
  | 'advisor'
  | 'documents'
  | 'reports'
  | 'team'
  | 'settings';

interface DashboardShellProps {
  activeSection: DashboardSection;
  onSelectSection: (section: DashboardSection) => void;
  children: React.ReactNode;
}

export function DashboardShell({
  activeSection,
  onSelectSection,
  children,
}: DashboardShellProps) {
  const { user, company, currentMember, signOut } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const primaryItems: Array<{
    id: DashboardSection;
    label: string;
    icon: React.ComponentType<{ size?: number; className?: string }>;
  }> = [
    { id: 'intelligence', label: t.sidebar.intelligence, icon: Brain },
    { id: 'workspace', label: t.sidebar.workspace, icon: MessageSquare },
    { id: 'overview', label: t.sidebar.overview, icon: LayoutDashboard },
    { id: 'forensics', label: t.sidebar.forensics, icon: ScanSearch },
    { id: 'advisor', label: t.sidebar.advisor, icon: Lightbulb },
    { id: 'documents', label: t.sidebar.documents, icon: FileText },
  ];

  const secondaryItems: Array<{
    id: DashboardSection;
    label: string;
    icon: React.ComponentType<{ size?: number; className?: string }>;
  }> = [
    { id: 'reports', label: t.sidebar.reports, icon: FileBarChart2 },
    { id: 'team', label: t.sidebar.team, icon: Users },
    { id: 'settings', label: t.sidebar.settings, icon: Settings },
  ];

  const allItems = [...primaryItems, ...secondaryItems];
  const activeLabel = allItems.find((n) => n.id === activeSection)?.label || t.sidebar.overview;

  const handleSelect = (id: DashboardSection) => {
    onSelectSection(id);
    setMobileOpen(false);
  };

  const renderLink = (
    item: {
      id: DashboardSection;
      label: string;
      icon: React.ComponentType<{ size?: number; className?: string }>;
    },
    isMobile: boolean
  ) => {
    const Icon = item.icon;
    const active = activeSection === item.id;
    return (
      <button
        key={item.id}
        type="button"
        onClick={() => handleSelect(item.id)}
        title={collapsed && !isMobile ? item.label : undefined}
        className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
          active
            ? 'bg-[#1D4ED8] text-[#F8FAFC]'
            : 'text-[#94A3B8] hover:bg-[#151E2E] hover:text-[#F8FAFC]'
        }`}
      >
        <Icon size={17} className="shrink-0" />
        {(!collapsed || isMobile) && <span className="truncate">{item.label}</span>}
      </button>
    );
  };

  const renderSidebarLinks = (isMobile = false) => (
    <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Workspace Navigation">
      <div className="space-y-1">{primaryItems.map((item) => renderLink(item, isMobile))}</div>
      <div className="my-3 border-t border-slate-800/80" />
      <div className="space-y-1">{secondaryItems.map((item) => renderLink(item, isMobile))}</div>
    </nav>
  );

  return (
    <div className="min-h-screen bg-[#090D18] text-[#F8FAFC] flex">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col border-e border-slate-800/80 bg-[#111827] transition-all duration-150 shrink-0 ${
          collapsed ? 'w-[72px]' : 'w-[264px]'
        }`}
      >
        <div className="h-16 border-b border-slate-800/80 px-4 flex items-center justify-between gap-2">
          {!collapsed && (
            <button
              type="button"
              onClick={() => onSelectSection('overview')}
              className="truncate focus-visible:outline-none"
            >
              <BrandLogo />
            </button>
          )}
          <button
            type="button"
            onClick={() => setCollapsed((c) => !c)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#94A3B8] hover:bg-[#151E2E] hover:text-[#F8FAFC] shrink-0"
          >
            {collapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}
          </button>
        </div>

        {renderSidebarLinks(false)}

        <div className="border-t border-slate-800/80 p-3 space-y-2">
          {!collapsed && company && (
            <div className="rounded-lg border border-slate-800 bg-[#090D18] px-3 py-2.5 text-xs">
              <div className="font-semibold text-[#F8FAFC] truncate">{company.name}</div>
              <div className="text-[#94A3B8] mt-0.5 capitalize truncate">
                {currentMember?.role || 'member'} · {company.planId}
              </div>
            </div>
          )}
          <button
            type="button"
            onClick={() => signOut()}
            className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium text-[#94A3B8] hover:bg-[#151E2E] hover:text-[#F8FAFC]"
          >
            <LogOut size={16} className="shrink-0" />
            {!collapsed && <span>{t.auth.signOutBtn}</span>}
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60"
            onClick={() => setMobileOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-72 max-w-[85vw] bg-[#111827] border-e border-slate-800 flex flex-col h-full">
            <div className="h-16 border-b border-slate-800 px-4 flex items-center justify-between">
              <BrandLogo />
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Close navigation"
                className="h-9 w-9 inline-flex items-center justify-center rounded-lg text-[#94A3B8] hover:text-[#F8FAFC]"
              >
                <X size={18} />
              </button>
            </div>
            {renderSidebarLinks(true)}
            <div className="border-t border-slate-800 p-4 space-y-2">
              {company && (
                <div className="text-xs text-[#94A3B8]">
                  <div className="font-semibold text-[#F8FAFC]">{company.name}</div>
                  <div>{user?.email}</div>
                </div>
              )}
              <button
                type="button"
                onClick={() => signOut()}
                className="w-full flex items-center gap-2 rounded-lg border border-slate-800 px-3 py-2 text-xs font-medium text-[#F8FAFC]"
              >
                <LogOut size={15} />
                <span>{t.auth.signOutBtn}</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 border-b border-slate-800/80 bg-[#090D18]/95 px-4 sm:px-6 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation"
              className="lg:hidden inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-800 bg-[#111827] text-[#F8FAFC]"
            >
              <Menu size={18} />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <BarChart2 size={16} className="text-[#38BDF8] shrink-0 hidden sm:block" />
              <span className="text-[#94A3B8] hidden sm:inline truncate">
                {company?.name || 'Workspace'}
              </span>
              <span className="text-[#94A3B8] hidden sm:inline">/</span>
              <h1 className="font-semibold text-[#F8FAFC] truncate">{activeLabel}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={toggleLanguage}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-[#111827] px-3 py-1.5 text-xs font-medium text-[#F8FAFC] hover:border-slate-700"
              aria-label="Switch Language"
            >
              <Globe size={14} className="text-[#38BDF8]" />
              <span>{language === 'en' ? 'العربية' : 'EN'}</span>
            </button>
            <div className="hidden sm:flex items-center gap-2 text-xs text-[#94A3B8]">
              <span className="truncate max-w-[160px]">{user?.displayName || user?.email}</span>
              <span aria-hidden="true">·</span>
              <span className="capitalize text-[#38BDF8]">{currentMember?.role || 'member'}</span>
            </div>
          </div>
        </header>

        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
