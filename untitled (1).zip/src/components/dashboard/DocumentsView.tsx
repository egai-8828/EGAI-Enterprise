import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckSquare,
  Eye,
  FileText,
  Search,
  Sparkles,
  Square,
  Target,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { documentsApi } from '../../lib/apiClient';
import { formatBytes, getCurrentMonthKey } from '../../shared/financeUtils';
import { WORKSPACE_DATA_DOMAINS } from '../../shared/intelligenceEngine';
import { getActiveSpecialists } from '../../shared/specialists';
import type {
  BusinessDocument,
  SpecialistSelection,
  WorkspaceDataDomain,
} from '../../shared/types';
import { MarkdownRenderer } from '../MarkdownRenderer';

type WorkflowType =
  | 'summarize'
  | 'financial_extraction'
  | 'trend_identification'
  | 'comparison'
  | 'qa'
  | 'report';

export function DocumentsView() {
  const {
    company,
    user,
    permissions,
    documents,
    saveDocumentRecord,
    persistDocumentMemory,
    deleteDocumentRecord,
  } = useAuth();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [search, setSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [uploadDomain, setUploadDomain] = useState<WorkspaceDataDomain | 'auto'>('auto');
  const [uploadPeriod, setUploadPeriod] = useState<string>(getCurrentMonthKey());
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [uploadingFileName, setUploadingFileName] = useState<string | null>(null);
  const [memoryNotice, setMemoryNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [workflow, setWorkflow] = useState<WorkflowType>('summarize');
  const [specialistId, setSpecialistId] = useState<SpecialistSelection>('auto');
  const [question, setQuestion] = useState('');
  const [focusData, setFocusData] = useState(company?.modelFocusData || '');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisOutput, setAnalysisOutput] = useState<string | null>(null);

  const [previewDoc, setPreviewDoc] = useState<BusinessDocument | null>(null);

  useEffect(() => {
    setFocusData(company?.modelFocusData || '');
  }, [company?.modelFocusData]);

  const filteredDocs = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return documents;
    return documents.filter(
      (d) =>
        d.fileName.toLowerCase().includes(q) ||
        d.fileType.toLowerCase().includes(q) ||
        (d.domain || '').toLowerCase().includes(q)
    );
  }, [documents, search]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !company || !user) return;

    setError(null);
    setMemoryNotice(null);
    setUploadingFileName(file.name);
    setUploadProgress(5);
    const docId = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

    try {
      const uploaded = await documentsApi.upload({
        companyId: company.id,
        docId,
        file,
        domain: uploadDomain === 'auto' ? undefined : uploadDomain,
        periodKey: uploadPeriod.trim() || getCurrentMonthKey(),
        onProgress: (pct) => setUploadProgress(pct),
      });

      await saveDocumentRecord({
        id: uploaded.docId,
        companyId: company.id,
        uploadedBy: user.uid,
        uploadedByName: user.displayName || user.email || 'Analyst',
        fileName: uploaded.fileName,
        fileType: uploaded.fileType,
        fileSize: uploaded.fileSize,
        storageLocation: uploaded.storageLocation,
        status: 'ready',
        domain: uploaded.domain,
        periodKey: uploaded.periodKey,
        indexedChunkCount: uploaded.chunks.length,
        structuredRecordCount: uploaded.extractedRecords.length,
        pageCount: uploaded.pageCount ?? undefined,
        sheetNames: uploaded.sheetNames,
        textPreview: uploaded.textPreview,
      });

      await persistDocumentMemory({
        documentId: uploaded.docId,
        fileName: uploaded.fileName,
        domain: uploaded.domain,
        periodKey: uploaded.periodKey,
        chunks: uploaded.chunks,
        records: uploaded.extractedRecords,
      });

      const summaryText = uploaded.aiSummary ? ` — ${uploaded.aiSummary}` : '';
      setMemoryNotice(
        isAr
          ? `تم تصنيف وفهرسة "${uploaded.fileName}" (${uploaded.autoClassified ? 'تصنيف تلقائي: ' : ''}${uploaded.domain} · ${uploaded.periodKey} · ${uploaded.chunks.length} مقطع · ${uploaded.extractedRecords.length} سجل)${summaryText}`
          : `Indexed "${uploaded.fileName}" into Company Memory (${uploaded.autoClassified ? 'AI-classified: ' : ''}${uploaded.domain} · ${uploaded.periodKey} · ${uploaded.chunks.length} RAG chunks · ${uploaded.extractedRecords.length} structured records)${summaryText}`
      );
      setSelectedIds((prev) => [...prev, uploaded.docId]);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Document processing failed.';
      setError(message);
    } finally {
      setUploadProgress(null);
      setUploadingFileName(null);
    }
  };

  const handleDelete = async (docItem: BusinessDocument) => {
    if (!company) return;
    setError(null);
    try {
      await documentsApi.deleteObject(company.id, docItem.id, docItem.storageLocation);
      await deleteDocumentRecord(docItem.id, docItem.fileName);
      setSelectedIds((prev) => prev.filter((id) => id !== docItem.id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Delete failed.');
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company || selectedIds.length === 0) return;

    const readySelected = documents.filter(
      (d) => selectedIds.includes(d.id) && d.status === 'ready'
    );
    if (readySelected.length === 0) {
      setError(
        isAr
          ? 'اختر مستنداً واحداً على الأقل بحالة «جاهز».'
          : 'Select at least one document with Ready status before analyzing.'
      );
      return;
    }

    setError(null);
    setAnalyzing(true);
    try {
      const res = await documentsApi.analyze({
        companyId: company.id,
        documentIds: readySelected.map((d) => d.id),
        workflow,
        question,
        focusData: focusData.trim() || undefined,
        specialistId,
        language,
      });
      setAnalysisOutput(res.content);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Document analysis failed.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">{t.documents.title}</h2>
          <p className="mt-1 text-sm text-[#94A3B8]">
            {isAr
              ? 'ارفع ملفات الشركة مرة واحدة مع تحديد القسم والفترة ليتم تخزينها وفهرستها تلقائياً في ذاكرة الشركة.'
              : 'Upload business files once with a domain tag & period — EGAI extracts, indexes, and remembers them across every assistant and report.'}
          </p>
        </div>

        {permissions.canUploadDocuments && (
          <div className="flex flex-wrap items-center gap-2.5">
            <select
              aria-label={isAr ? 'مجال البيانات' : 'Data Domain'}
              value={uploadDomain}
              onChange={(e) => setUploadDomain(e.target.value as WorkspaceDataDomain | 'auto')}
              className="rounded-lg border border-slate-700 bg-[#111827] px-3 py-2 text-xs text-[#F8FAFC]"
            >
              <option value="auto">{isAr ? 'تصنيف تلقائي للمجال' : 'Auto-Detect Domain'}</option>
              {WORKSPACE_DATA_DOMAINS.map((d) => (
                <option key={d.id} value={d.id}>
                  {isAr ? d.nameAr : d.nameEn}
                </option>
              ))}
            </select>
            <input
              type="text"
              aria-label={isAr ? 'الفترة الزمنية' : 'Period Key'}
              value={uploadPeriod}
              onChange={(e) => setUploadPeriod(e.target.value)}
              placeholder="YYYY-MM"
              className="w-28 rounded-lg border border-slate-700 bg-[#111827] px-3 py-2 text-xs font-mono text-[#F8FAFC]"
            />
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.xlsx,.xls,.csv,.docx,.txt"
              onChange={handleUpload}
              className="hidden"
            />
            <button
              type="button"
              disabled={uploadProgress !== null}
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
            >
              <Upload size={16} />
              <span>{t.documents.uploadBtn}</span>
            </button>
          </div>
        )}
      </div>

      {uploadProgress !== null && (
        <div className="rounded-xl border border-[#38BDF8]/40 bg-[#151E2E] p-4 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-[#F8FAFC]">
              {isAr ? 'جاري رفع ومعالجة وفهرسة:' : 'Uploading, extracting & indexing:'}{' '}
              {uploadingFileName}
            </span>
            <span className="font-mono text-[#38BDF8] tabular-nums">{uploadProgress}%</span>
          </div>
          <div className="h-2 w-full rounded-full bg-[#090D18] overflow-hidden">
            <div
              className="h-full bg-[#38BDF8] transition-all duration-150"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        </div>
      )}

      {memoryNotice && (
        <div className="rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3.5 text-xs text-[#86EFAC]">
          {memoryNotice}
        </div>
      )}

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3.5 text-xs text-[#FCA5A5]">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Document Repository List */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <div className="relative">
            <Search size={15} className="absolute top-3 start-3.5 text-[#94A3B8]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.documents.searchPlaceholder}
              className="w-full rounded-lg border border-slate-800 bg-[#090D18] ps-10 pe-4 py-2.5 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
            />
          </div>

          {filteredDocs.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-800 bg-[#090D18]/40 p-8 text-center text-sm text-[#94A3B8]">
              {t.dashboard.emptyDocuments}
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {filteredDocs.map((docItem) => {
                const selected = selectedIds.includes(docItem.id);
                return (
                  <div
                    key={docItem.id}
                    className="py-3.5 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <button
                        type="button"
                        aria-label={`Select ${docItem.fileName}`}
                        onClick={() => toggleSelect(docItem.id)}
                        className="text-[#94A3B8] hover:text-[#38BDF8] shrink-0"
                      >
                        {selected ? (
                          <CheckSquare size={18} className="text-[#38BDF8]" />
                        ) : (
                          <Square size={18} />
                        )}
                      </button>
                      <FileText size={17} className="text-[#38BDF8] shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-[#F8FAFC] truncate">
                          {docItem.fileName}
                        </div>
                        <div className="mt-0.5 text-xs text-[#94A3B8] font-mono tabular-nums flex flex-wrap items-center gap-2">
                          <span>{docItem.fileType.toUpperCase()}</span>
                          <span>·</span>
                          <span>{formatBytes(docItem.fileSize)}</span>
                          {docItem.domain && (
                            <>
                              <span>·</span>
                              <span className="capitalize text-[#38BDF8]">{docItem.domain}</span>
                            </>
                          )}
                          {docItem.periodKey && (
                            <>
                              <span>·</span>
                              <span>{docItem.periodKey}</span>
                            </>
                          )}
                          {typeof docItem.indexedChunkCount === 'number' && (
                            <>
                              <span>·</span>
                              <span>{docItem.indexedChunkCount} chunks</span>
                            </>
                          )}
                          {typeof docItem.structuredRecordCount === 'number' && (
                            <>
                              <span>·</span>
                              <span>{docItem.structuredRecordCount} records</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`text-xs font-medium ${
                          docItem.status === 'ready'
                            ? 'text-[#22C55E]'
                            : docItem.status === 'error'
                            ? 'text-[#EF4444]'
                            : 'text-[#F59E0B]'
                        }`}
                      >
                        {docItem.status === 'ready'
                          ? t.documents.statusReady
                          : docItem.status === 'error'
                          ? t.documents.statusError
                          : t.documents.statusProcessing}
                      </span>

                      <button
                        type="button"
                        aria-label={`Preview ${docItem.fileName}`}
                        onClick={() => setPreviewDoc(docItem)}
                        className="p-1.5 rounded-lg border border-slate-800 text-[#94A3B8] hover:text-[#F8FAFC]"
                      >
                        <Eye size={14} />
                      </button>

                      {permissions.canDeleteDocuments && (
                        <button
                          type="button"
                          aria-label={`Delete ${docItem.fileName}`}
                          onClick={() => handleDelete(docItem)}
                          className="p-1.5 rounded-lg border border-slate-800 text-[#94A3B8] hover:text-[#EF4444]"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Document Analysis Workflows */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <div className="flex items-center gap-2 text-[#38BDF8]">
            <Sparkles size={17} />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              {t.documents.analyzeSelected}
            </h3>
          </div>

          <form onSubmit={handleAnalyze} className="space-y-4">
            <div>
              <label htmlFor="doc-workflow" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {t.documents.workflowLabel}
              </label>
              <select
                id="doc-workflow"
                value={workflow}
                onChange={(e) => setWorkflow(e.target.value as WorkflowType)}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC]"
              >
                <option value="summarize">{t.documents.workflows.summarize}</option>
                <option value="financial_extraction">
                  {t.documents.workflows.financial_extraction}
                </option>
                <option value="trend_identification">
                  {t.documents.workflows.trend_identification}
                </option>
                <option value="comparison">{t.documents.workflows.comparison}</option>
                <option value="qa">{t.documents.workflows.qa}</option>
                <option value="report">{t.documents.workflows.report}</option>
              </select>
            </div>

            <div>
              <label htmlFor="doc-specialist" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {t.workspace.selectSpecialist}
              </label>
              <select
                id="doc-specialist"
                value={specialistId}
                onChange={(e) => setSpecialistId(e.target.value as SpecialistSelection)}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC]"
              >
                <option value="auto">
                  {isAr ? 'تلقائي (يحدده الذكاء الاصطناعي)' : 'Auto (AI Routing)'}
                </option>
                {getActiveSpecialists().map((spec) => (
                  <option key={spec.id} value={spec.id}>
                    {isAr ? spec.nameAr : spec.nameEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="doc-question" className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                {isAr ? 'سؤال أو تعليمات إضافية' : 'Focus Question / Instructions'}
              </label>
              <textarea
                id="doc-question"
                rows={2}
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder={t.documents.questionPlaceholder}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="doc-focus-data"
                className="flex items-center gap-1.5 text-xs font-medium text-[#38BDF8] mb-1.5"
              >
                <Target size={13} />
                <span>
                  {isAr
                    ? 'بيانات يركز عليها النموذج (اختياري)'
                    : 'Model Focus Data (optional)'}
                </span>
              </label>
              <textarea
                id="doc-focus-data"
                rows={2}
                value={focusData}
                onChange={(e) => setFocusData(e.target.value)}
                placeholder={
                  isAr
                    ? 'أدخل بنوداً أو أرقاماً محددة تريد من النموذج التركيز عليها أثناء تحليل المستندات...'
                    : 'Enter priority figures, lines, or criteria for the model to highlight...'
                }
                className="w-full rounded-lg border border-[#38BDF8]/40 bg-[#090D18] px-3 py-2 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={!permissions.canInvokeAI || analyzing || selectedIds.length === 0}
              className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
            >
              {analyzing
                ? isAr
                  ? 'جاري تحليل المستندات...'
                  : 'Analyzing Documents...'
                : `${t.documents.runAnalysisBtn} (${selectedIds.length})`}
            </button>
          </form>

          {analysisOutput && (
            <div className="mt-4 rounded-lg border border-slate-800 bg-[#090D18] p-4 space-y-2 max-h-[420px] overflow-y-auto">
              <MarkdownRenderer content={analysisOutput} />
            </div>
          )}
        </div>
      </div>

      {/* Extracted Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-3xl max-h-[85vh] rounded-xl border border-slate-800 bg-[#151E2E] flex flex-col overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-[#F8FAFC]">{previewDoc.fileName}</h3>
                <p className="text-xs text-[#94A3B8] font-mono">
                  {previewDoc.fileType.toUpperCase()} · {formatBytes(previewDoc.fileSize)}
                  {previewDoc.domain ? ` · ${previewDoc.domain}` : ''}
                </p>
              </div>
              <button
                type="button"
                aria-label="Close preview"
                onClick={() => setPreviewDoc(null)}
                className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#F8FAFC]"
              >
                <X size={18} />
              </button>
            </div>
            <div className="p-5 overflow-y-auto">
              <pre className="whitespace-pre-wrap font-mono text-xs text-[#CBD5E1] leading-relaxed">
                {previewDoc.textPreview || 'No preview available.'}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
