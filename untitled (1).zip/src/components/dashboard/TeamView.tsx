import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ClipboardList,
  Lock,
  Shield,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { canAssignRole, canRemoveMember } from '../../shared/rbac';
import type { UserRole } from '../../shared/types';

export function TeamView() {
  const {
    user,
    company,
    currentMember,
    permissions,
    members,
    companyInvites,
    auditLogs,
    createInvite,
    revokeInvite,
    updateMemberRole,
    removeCompanyMember,
    updateCompanyGovernance,
    purgeCompanyWorkspaceData,
  } = useAuth();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';

  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<Exclude<UserRole, 'owner'>>('analyst');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [retentionDays, setRetentionDays] = useState<number>(company?.retentionDays ?? 365);
  const [savingRetention, setSavingRetention] = useState(false);
  const [purgeConfirmText, setPurgeConfirmText] = useState('');
  const [purging, setPurging] = useState(false);

  useEffect(() => {
    setRetentionDays(company?.retentionDays ?? 365);
  }, [company?.retentionDays]);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.canManageTeam) return;
    setError(null);
    if (!inviteEmail.trim() || !inviteEmail.includes('@')) {
      setError(isAr ? 'أدخل بريداً إلكترونياً صحيحاً.' : 'Enter a valid email address.');
      return;
    }
    setBusy(true);
    try {
      await createInvite(inviteEmail, inviteRole);
      setInviteEmail('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create invite.');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveRetention = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.canManageCompany) return;
    setError(null);
    setNotice(null);
    setSavingRetention(true);
    try {
      await updateCompanyGovernance({ retentionDays });
      setNotice(
        isAr
          ? 'تم تحديث سياسة الاحتفاظ بالبيانات بنجاح.'
          : 'Data retention policy updated in Firestore.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update retention policy.');
    } finally {
      setSavingRetention(false);
    }
  };

  const handlePurge = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company || !permissions.canDeleteCompanyData) return;
    if (purgeConfirmText.trim() !== company.name) return;
    setError(null);
    setNotice(null);
    setPurging(true);
    try {
      await purgeCompanyWorkspaceData();
      setPurgeConfirmText('');
      setNotice(
        isAr
          ? 'تم مسح كافة مستندات الشركة والسجلات والذاكرة والمحادثات مع الاحتفاظ بسجل التدقيق لأغراض الامتثال.'
          : 'All company documents, indexed memory chunks, structured records, conversations, and reports have been purged. Audit trail retained for compliance.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Workspace purge failed.');
    } finally {
      setPurging(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-[#F8FAFC]">{t.team.title}</h2>
        <p className="mt-1 text-sm text-[#94A3B8]">{t.team.subtitle}</p>
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-[#FCA5A5]">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="flex items-start gap-2 rounded-lg border border-[#22C55E]/40 bg-[#22C55E]/10 p-3 text-xs text-[#86EFAC]">
          <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
          <span>{notice}</span>
        </div>
      )}

      {permissions.canManageTeam && (
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5">
          <div className="flex items-center gap-2 text-[#38BDF8] mb-4">
            <UserPlus size={17} />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">{t.team.inviteTitle}</h3>
          </div>
          <form onSubmit={handleInvite} className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-6">
              <label htmlFor="inv-email" className="sr-only">
                {t.team.inviteEmail}
              </label>
              <input
                id="inv-email"
                type="email"
                required
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder={t.team.inviteEmail}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3.5 py-2.5 text-xs text-[#F8FAFC] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>
            <div className="sm:col-span-3">
              <label htmlFor="inv-role" className="sr-only">
                {t.team.inviteRole}
              </label>
              <select
                id="inv-role"
                value={inviteRole}
                onChange={(e) => setInviteRole(e.target.value as Exclude<UserRole, 'owner'>)}
                className="w-full rounded-lg border border-slate-700 bg-[#090D18] px-3 py-2.5 text-xs text-[#F8FAFC]"
              >
                <option value="administrator">Administrator</option>
                <option value="analyst">Analyst</option>
                <option value="viewer">Viewer</option>
              </select>
            </div>
            <div className="sm:col-span-3">
              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-xs font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
              >
                {t.team.sendInviteBtn}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Active Members */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
        <h3 className="text-sm font-semibold text-[#F8FAFC]">
          {t.team.membersList} ({members.length})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-[#94A3B8]">
                <th className="py-2.5 px-3 text-start font-medium">
                  {isAr ? 'الاسم' : 'Name'}
                </th>
                <th className="py-2.5 px-3 text-start font-medium">
                  {isAr ? 'البريد الإلكتروني' : 'Email'}
                </th>
                <th className="py-2.5 px-3 text-start font-medium">{t.team.inviteRole}</th>
                <th className="py-2.5 px-3 text-end font-medium">
                  {isAr ? 'إدارة' : 'Manage'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {members.map((m) => {
                const isSelf = m.uid === user?.uid;
                const canChangeRole =
                  currentMember &&
                  canAssignRole(currentMember.role, m.role) &&
                  m.role !== 'owner';
                const canDelete =
                  currentMember &&
                  canRemoveMember(currentMember.role, m.role, isSelf);

                return (
                  <tr key={m.uid}>
                    <td className="py-3 px-3 font-medium text-[#F8FAFC]">
                      {m.displayName} {isSelf ? (isAr ? '(أنت)' : '(You)') : ''}
                    </td>
                    <td className="py-3 px-3 font-mono text-[#CBD5E1]">{m.email}</td>
                    <td className="py-3 px-3">
                      {canChangeRole ? (
                        <select
                          aria-label={`Role for ${m.email}`}
                          value={m.role}
                          onChange={(e) =>
                            updateMemberRole(m.uid, e.target.value as Exclude<UserRole, 'owner'>)
                          }
                          className="rounded border border-slate-700 bg-[#090D18] px-2.5 py-1 text-xs text-[#F8FAFC] capitalize"
                        >
                          <option value="administrator">Administrator</option>
                          <option value="analyst">Analyst</option>
                          <option value="viewer">Viewer</option>
                        </select>
                      ) : (
                        <span className="capitalize text-[#38BDF8] font-medium">{m.role}</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-end">
                      {canDelete && (
                        <button
                          type="button"
                          aria-label={`Remove ${m.email}`}
                          onClick={() => removeCompanyMember(m.uid)}
                          className="inline-flex items-center gap-1 rounded border border-slate-800 px-2.5 py-1 text-xs text-[#94A3B8] hover:text-[#EF4444]"
                        >
                          <Trash2 size={12} />
                          <span>{t.team.removeBtn}</span>
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pending Invites */}
      {companyInvites.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#F8FAFC]">{t.team.pendingInvites}</h3>
          <div className="divide-y divide-slate-800">
            {companyInvites.map((inv) => (
              <div key={inv.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-mono text-[#F8FAFC]">{inv.email}</span>
                  <span className="mx-2 text-[#94A3B8]">·</span>
                  <span className="capitalize text-[#38BDF8]">{inv.role}</span>
                  <span className="mx-2 text-[#94A3B8]">·</span>
                  <span className="capitalize text-[#94A3B8]">{inv.status}</span>
                </div>
                {inv.status === 'pending' && permissions.canManageTeam && (
                  <button
                    type="button"
                    onClick={() => revokeInvite(inv.id)}
                    className="rounded border border-slate-700 px-2.5 py-1 text-xs text-[#FCA5A5] hover:border-[#EF4444]"
                  >
                    {t.team.revokeBtn}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Role Permissions Reference */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-3">
        <div className="flex items-center gap-2 text-[#38BDF8]">
          <Shield size={16} />
          <h3 className="text-sm font-semibold text-[#F8FAFC]">
            {isAr ? 'مصفوفة صلاحيات الأدوار (RBAC)' : 'Role Permissions Matrix (Enforced Server & Rules)'}
          </h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {[
            {
              role: 'Owner',
              desc: isAr
                ? 'تحكم كامل: إدارة الفريق، اعتماد خطط النمو، ضبط الحدود، وحذف بيانات الشركة بالكامل.'
                : 'Full control: team management, growth plan approval, limits, and full company data purge.',
            },
            {
              role: 'Administrator',
              desc: isAr
                ? 'إدارة الأعضاء والدعوات، اعتماد خطط النمو، تحديث سياق الشركة وحدود الاستهلاك.'
                : 'Manage members & invites, approve growth plans, update company context and usage limits.',
            },
            {
              role: 'Analyst',
              desc: isAr
                ? 'رفع المستندات، تشغيل الفحص المالي، توثيق الأرقام، وإنشاء المحادثات والتقارير.'
                : 'Upload documents, run forensic scans, verify extracted records, run AI specialists & reports.',
            },
            {
              role: 'Viewer',
              desc: isAr
                ? 'قراءة واستعراض المؤشرات والمستندات والتقارير والبحث داخل الذاكرة دون تعديل.'
                : 'Read-only access to intelligence dashboards, documents, reports, and memory search.',
            },
          ].map((item) => (
            <div key={item.role} className="rounded-lg border border-slate-800 bg-[#090D18] p-3">
              <div className="font-semibold text-[#F8FAFC]">{item.role}</div>
              <p className="mt-1 text-[#94A3B8] leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Data Privacy, Retention & Owner-Only Purge */}
      <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
        <div className="flex items-center gap-2 text-[#38BDF8]">
          <Lock size={16} />
          <h3 className="text-sm font-semibold text-[#F8FAFC]">
            {isAr ? 'الخصوصية والاحتفاظ بالبيانات وحوكمة الشركة' : 'Data Privacy, Retention Policy & Workspace Purge'}
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="rounded-lg border border-slate-800 bg-[#090D18] p-4 space-y-3">
            <div className="font-semibold text-[#22C55E]">
              {isAr
                ? 'عدم استخدام بيانات الشركة في تدريب النماذج المشتركة (مفعّل دائماً)'
                : 'Zero Shared Model Training (Locked Enabled)'}
            </div>
            <p className="text-[#94A3B8] leading-relaxed">
              {isAr
                ? 'تبقى مستندات الشركة وسجلاتها معزولة كلياً داخل مساحة المستأجر (companies/{companyId}) ولا تُستخدم لتدريب أي نماذج عامة.'
                : 'All documents, structured records, and chunks are strictly isolated per company tenant and blocked from shared model training.'}
            </p>

            <form onSubmit={handleSaveRetention} className="pt-2 border-t border-slate-800 flex items-end gap-2">
              <div className="flex-1">
                <label htmlFor="retention-days" className="block text-[#CBD5E1] mb-1">
                  {isAr ? 'مدة الاحتفاظ بالبيانات (بالأيام)' : 'Data Retention Window (Days)'}
                </label>
                <input
                  id="retention-days"
                  type="number"
                  min={30}
                  max={3650}
                  disabled={!permissions.canManageCompany}
                  value={retentionDays}
                  onChange={(e) => setRetentionDays(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-700 bg-[#111827] px-3 py-1.5 font-mono text-xs text-[#F8FAFC] disabled:opacity-60"
                />
              </div>
              {permissions.canManageCompany && (
                <button
                  type="submit"
                  disabled={savingRetention}
                  className="rounded-lg bg-[#1D4ED8] px-3.5 py-1.5 font-semibold text-[#F8FAFC] hover:bg-[#2563EB] disabled:opacity-50"
                >
                  {isAr ? 'حفظ السياسة' : 'Save Policy'}
                </button>
              )}
            </form>
          </div>

          <div className="rounded-lg border border-[#EF4444]/30 bg-[#090D18] p-4 space-y-3">
            <div className="font-semibold text-[#FCA5A5]">
              {isAr ? 'حذف بيانات الشركة بالكامل (للمالك فقط)' : 'Owner-Only Company Data Purge'}
            </div>
            <p className="text-[#94A3B8] leading-relaxed">
              {isAr
                ? 'يحذف جميع المستندات المخزنة، الذاكرة المفهرسة، السجلات المنظمة، المحادثات، والتقارير من التخزين وقاعدة البيانات بشكل نهائي.'
                : 'Permanently removes all stored files, indexed chunks, structured records, forensic findings, growth proposals, chats, and reports.'}
            </p>
            {permissions.canDeleteCompanyData && company ? (
              <form onSubmit={handlePurge} className="space-y-2 pt-1">
                <input
                  type="text"
                  value={purgeConfirmText}
                  onChange={(e) => setPurgeConfirmText(e.target.value)}
                  placeholder={
                    isAr
                      ? `اكتب اسم الشركة "${company.name}" للتأكيد`
                      : `Type "${company.name}" to confirm purge`
                  }
                  className="w-full rounded-lg border border-slate-700 bg-[#111827] px-3 py-1.5 text-xs text-[#F8FAFC] focus:border-[#EF4444] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={purging || purgeConfirmText.trim() !== company.name}
                  className="rounded-lg bg-[#EF4444]/20 border border-[#EF4444]/50 px-3.5 py-1.5 text-xs font-semibold text-[#FCA5A5] hover:bg-[#EF4444]/30 disabled:opacity-40"
                >
                  {purging
                    ? isAr
                      ? 'جاري مسح البيانات...'
                      : 'Purging Workspace...'
                    : isAr
                    ? 'مسح جميع بيانات الشركة نهائياً'
                    : 'Purge All Company Data'}
                </button>
              </form>
            ) : (
              <p className="text-[11px] text-[#64748B]">
                {isAr
                  ? 'هذا الإجراء متاح لحساب المالك (Owner) فقط.'
                  : 'Restricted exclusively to the Company Owner role.'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Immutable Audit Log */}
      {permissions.canViewAuditLogs && (
        <div className="rounded-xl border border-slate-800 bg-[#151E2E] p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-[#38BDF8]">
              <ClipboardList size={16} />
              <h3 className="text-sm font-semibold text-[#F8FAFC]">
                {isAr ? 'سجل التدقيق غير القابل للتعديل (Audit Log)' : 'Immutable Workspace Audit Log'}
              </h3>
            </div>
            <span className="text-xs font-mono text-[#94A3B8] tabular-nums">
              {auditLogs.length} {isAr ? 'عملية مسجلة' : 'events'}
            </span>
          </div>

          {auditLogs.length === 0 ? (
            <p className="text-xs text-[#94A3B8]">
              {isAr
                ? 'ستظهر هنا كل عمليات الرفع والتدقيق والموافقة وتعديل الصلاحيات تلقائياً.'
                : 'Document uploads, verification edits, forensic scans, approvals, and RBAC changes appear here automatically.'}
            </p>
          ) : (
            <div className="overflow-x-auto max-h-[320px] overflow-y-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[#94A3B8]">
                    <th className="py-2 px-3 text-start font-medium">{isAr ? 'المستخدم' : 'Actor'}</th>
                    <th className="py-2 px-3 text-start font-medium">{isAr ? 'الدور' : 'Role'}</th>
                    <th className="py-2 px-3 text-start font-medium">{isAr ? 'الإجراء' : 'Action'}</th>
                    <th className="py-2 px-3 text-start font-medium">{isAr ? 'التفاصيل' : 'Summary'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {auditLogs.slice(0, 50).map((log) => (
                    <tr key={log.id}>
                      <td className="py-2 px-3 font-mono text-[#F8FAFC] whitespace-nowrap">
                        {log.actorEmail}
                      </td>
                      <td className="py-2 px-3 capitalize text-[#38BDF8] whitespace-nowrap">
                        {log.actorRole}
                      </td>
                      <td className="py-2 px-3 font-mono text-[#CBD5E1] whitespace-nowrap">
                        {log.action}
                      </td>
                      <td className="py-2 px-3 text-[#94A3B8]">{log.summary}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
