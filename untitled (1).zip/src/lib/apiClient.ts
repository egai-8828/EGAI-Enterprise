import { auth } from './firebase';
import type {
  AIProviderName,
  ActiveSpecialistId,
  ForensicFinding,
  GrowthAdvisorDomain,
  GrowthProposal,
  IntegrationStatus,
  KnowledgeChunk,
  Language,
  PlanId,
  ReportType,
  SheetSummary,
  SpecialistSelection,
  StructuredBusinessRecord,
  WorkspaceDataDomain,
} from '../shared/types';
import type {
  ChunkDraft,
  CompanyAnalyticsSnapshot,
  ExtractedRecordDraft,
  RankedChunkResult,
} from '../shared/intelligenceEngine';

async function getBearerHeaders(): Promise<Record<string, string>> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Authentication required.');
  }
  const token = await user.getIdToken();
  return {
    Authorization: `Bearer ${token}`,
  };
}

async function parseErrorResponse(res: Response): Promise<string> {
  try {
    const data = (await res.json()) as { error?: string };
    return data.error || `Request failed with status ${res.status}`;
  } catch {
    return `Request failed with status ${res.status}`;
  }
}

export const integrationApi = {
  async getStatus(): Promise<IntegrationStatus> {
    const res = await fetch('/api/system/integrations');
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return (await res.json()) as IntegrationStatus;
  },
};

export interface UploadedDocumentResponse {
  docId: string;
  fileName: string;
  fileType: 'pdf' | 'xlsx' | 'csv' | 'docx' | 'txt';
  fileSize: number;
  storageLocation: string;
  status: 'ready';
  domain: WorkspaceDataDomain;
  periodKey: string;
  aiSummary?: string;
  autoClassified?: boolean;
  provider?: AIProviderName;
  model?: string;
  pageCount: number | null;
  sheetNames: string[];
  sheets: SheetSummary[];
  textPreview: string;
  chunks: ChunkDraft[];
  extractedRecords: ExtractedRecordDraft[];
}

export const documentsApi = {
  async upload(params: {
    companyId: string;
    docId: string;
    file: File;
    domain?: WorkspaceDataDomain | 'auto';
    periodKey?: string;
    onProgress?: (pct: number) => void;
  }): Promise<UploadedDocumentResponse> {
    const headers = await getBearerHeaders();
    const formData = new FormData();
    formData.append('companyId', params.companyId);
    formData.append('docId', params.docId);
    if (params.domain && params.domain !== 'auto') formData.append('domain', params.domain);
    if (params.periodKey) formData.append('periodKey', params.periodKey);
    formData.append('file', params.file);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/documents/upload', true);
      xhr.setRequestHeader('Authorization', headers.Authorization);

      xhr.upload.onprogress = (evt) => {
        if (evt.lengthComputable && params.onProgress) {
          const pct = Math.min(95, Math.round((evt.loaded / evt.total) * 95));
          params.onProgress(pct);
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          params.onProgress?.(100);
          try {
            resolve(JSON.parse(xhr.responseText) as UploadedDocumentResponse);
          } catch {
            reject(new Error('Invalid upload server response.'));
          }
        } else {
          try {
            const parsed = JSON.parse(xhr.responseText) as { error?: string };
            reject(new Error(parsed.error || `Upload failed (${xhr.status})`));
          } catch {
            reject(new Error(`Upload failed (${xhr.status})`));
          }
        }
      };

      xhr.onerror = () => reject(new Error('Network error while uploading document.'));
      xhr.send(formData);
    });
  },

  async getExtract(companyId: string, docId: string) {
    const headers = await getBearerHeaders();
    const res = await fetch(
      `/api/documents/${encodeURIComponent(companyId)}/${encodeURIComponent(docId)}/extract`,
      { headers }
    );
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      docId: string;
      fileName: string;
      fileType: string;
      domain?: WorkspaceDataDomain;
      periodKey?: string;
      pageCount?: number;
      sheetNames?: string[];
      sheets?: SheetSummary[];
      fullText: string;
    }>;
  },

  async deleteObject(companyId: string, docId: string, storageLocation?: string) {
    const headers = await getBearerHeaders();
    const qs = storageLocation ? `?storageLocation=${encodeURIComponent(storageLocation)}` : '';
    const res = await fetch(
      `/api/documents/${encodeURIComponent(companyId)}/${encodeURIComponent(docId)}${qs}`,
      { method: 'DELETE', headers }
    );
    if (!res.ok) throw new Error(await parseErrorResponse(res));
  },

  async analyze(params: {
    companyId: string;
    documentIds: string[];
    workflow:
      | 'summarize'
      | 'financial_extraction'
      | 'trend_identification'
      | 'comparison'
      | 'qa'
      | 'report';
    question?: string;
    specialistId: SpecialistSelection;
    language: Language;
    focusData?: string;
  }) {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/documents/analyze', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      content: string;
      specialistId: ActiveSpecialistId;
      provider: AIProviderName;
      model: string;
      inputTokens: number;
      outputTokens: number;
    }>;
  },
};

export const intelligenceApi = {
  async query(params: {
    companyId: string;
    question: string;
    domain?: WorkspaceDataDomain | 'all';
    language: Language;
    focusData?: string;
    records?: StructuredBusinessRecord[];
    chunks?: KnowledgeChunk[];
  }) {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/intelligence/query', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      answer: string;
      hits: RankedChunkResult[];
      analytics: CompanyAnalyticsSnapshot;
      provider: AIProviderName;
      model: string;
      inputTokens: number;
      outputTokens: number;
    }>;
  },
};

export const forensicsApi = {
  async scan(params: {
    companyId: string;
    records?: StructuredBusinessRecord[];
    language?: Language;
    focusData?: string;
  }) {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/forensics/scan', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      findings: Array<
        Omit<ForensicFinding, 'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'>
      >;
      scannedDocuments: number;
      scannedRecords: number;
      provider: AIProviderName;
      model: string;
    }>;
  },
};

export const advisorApi = {
  async generate(params: {
    companyId: string;
    domains: GrowthAdvisorDomain[];
    records?: StructuredBusinessRecord[];
    chunks?: KnowledgeChunk[];
    language: Language;
    focusData?: string;
  }) {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/advisor/generate', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      proposals: Array<
        Omit<GrowthProposal, 'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'>
      >;
      provider: AIProviderName;
      model: string;
      requiresManagementApproval: boolean;
    }>;
  },
};

export const companyApi = {
  async purgeStorage(companyId: string) {
    const headers = await getBearerHeaders();
    const res = await fetch(`/api/company/${encodeURIComponent(companyId)}/purge`, {
      method: 'DELETE',
      headers,
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{ purged: boolean }>;
  },
};

export const chatApi = {
  async streamMessage(params: {
    companyId: string;
    specialistId: SpecialistSelection;
    message: string;
    history: Array<{ role: 'user' | 'assistant'; content: string }>;
    documentIds: string[];
    language: Language;
    focusData?: string;
    records?: StructuredBusinessRecord[];
    chunks?: KnowledgeChunk[];
    onMeta?: (meta: { specialistId: ActiveSpecialistId }) => void;
    onDelta: (chunk: string) => void;
    signal?: AbortSignal;
  }): Promise<{
    fullText: string;
    specialistId: ActiveSpecialistId;
    provider: AIProviderName;
    model: string;
    inputTokens: number;
    outputTokens: number;
  }> {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        companyId: params.companyId,
        specialistId: params.specialistId,
        message: params.message,
        history: params.history,
        documentIds: params.documentIds,
        language: params.language,
        focusData: params.focusData,
        records: params.records,
        chunks: params.chunks,
      }),
      signal: params.signal,
    });

    if (!res.ok) {
      throw new Error(await parseErrorResponse(res));
    }

    if (!res.body) {
      throw new Error('Streaming response body unavailable.');
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let fullText = '';
    let resolvedSpecialistId: ActiveSpecialistId =
      params.specialistId === 'auto' ? 'bi' : params.specialistId;
    let finalMeta: {
      provider: AIProviderName;
      model: string;
      inputTokens: number;
      outputTokens: number;
    } = {
      provider: 'gemini',
      model: 'gemini-4-hydrogen',
      inputTokens: 0,
      outputTokens: 0,
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const parts = buffer.split('\n\n');
      buffer = parts.pop() ?? '';

      for (const part of parts) {
        const line = part.trim();
        if (!line.startsWith('data:')) continue;
        const payload = line.slice(5).trim();
        if (!payload) continue;
        const evt = JSON.parse(payload) as
          | { type: 'meta'; specialistId: ActiveSpecialistId }
          | { type: 'delta'; text: string }
          | {
              type: 'done';
              specialistId?: ActiveSpecialistId;
              provider: AIProviderName;
              model: string;
              inputTokens: number;
              outputTokens: number;
            }
          | { type: 'error'; error: string };

        if (evt.type === 'meta') {
          resolvedSpecialistId = evt.specialistId;
          params.onMeta?.({ specialistId: evt.specialistId });
        } else if (evt.type === 'delta') {
          fullText += evt.text;
          params.onDelta(evt.text);
        } else if (evt.type === 'done') {
          if (evt.specialistId) {
            resolvedSpecialistId = evt.specialistId;
          }
          finalMeta = {
            provider: evt.provider,
            model: evt.model,
            inputTokens: evt.inputTokens,
            outputTokens: evt.outputTokens,
          };
        } else if (evt.type === 'error') {
          throw new Error(evt.error);
        }
      }
    }

    return {
      fullText,
      specialistId: resolvedSpecialistId,
      ...finalMeta,
    };
  },
};

export const reportsApi = {
  async generate(params: {
    companyId: string;
    title: string;
    reportType: ReportType;
    specialistId: SpecialistSelection;
    documentIds: string[];
    conversationSummary?: string;
    instructions?: string;
    language: Language;
    focusData?: string;
  }) {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/reports/generate', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      content: string;
      specialistId: ActiveSpecialistId;
      provider: AIProviderName;
      model: string;
      inputTokens: number;
      outputTokens: number;
    }>;
  },
};

export const billingApi = {
  async getStatus() {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/billing/status', { headers });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json();
  },

  async updateCompanyLimits(params: {
    companyId: string;
    planId: PlanId;
    monthlyTokenLimit: number;
    monthlyRequestLimit: number;
  }) {
    const headers = await getBearerHeaders();
    const res = await fetch('/api/company/limits', {
      method: 'POST',
      headers: {
        ...headers,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await parseErrorResponse(res));
    return res.json() as Promise<{
      updated: boolean;
      planId: PlanId;
      monthlyTokenLimit: number;
      monthlyRequestLimit: number;
    }>;
  },
};
