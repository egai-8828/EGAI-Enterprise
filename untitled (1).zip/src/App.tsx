import { useCallback, useEffect, useState } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LandingPage } from './components/LandingPage';
import { AuthViews, type AuthMode } from './components/AuthViews';
import { OnboardingView } from './components/OnboardingView';
import { DashboardShell, type DashboardSection } from './components/dashboard/DashboardShell';
import { CompanyIntelligenceView } from './components/dashboard/CompanyIntelligenceView';
import { FinancialForensicsView } from './components/dashboard/FinancialForensicsView';
import { GrowthAdvisorView } from './components/dashboard/GrowthAdvisorView';
import { OverviewView } from './components/dashboard/OverviewView';
import { WorkspaceView } from './components/dashboard/WorkspaceView';
import { DocumentsView } from './components/dashboard/DocumentsView';
import { ReportsView } from './components/dashboard/ReportsView';
import { TeamView } from './components/dashboard/TeamView';
import { SettingsView } from './components/dashboard/SettingsView';

const VALID_SECTIONS: DashboardSection[] = [
  'intelligence',
  'workspace',
  'overview',
  'forensics',
  'advisor',
  'documents',
  'reports',
  'team',
  'settings',
];

function normalizeSection(raw: string): DashboardSection {
  if (raw === 'specialists' || raw === 'history') return 'workspace';
  if (raw === 'billing' || raw === 'help') return 'settings';
  return VALID_SECTIONS.includes(raw as DashboardSection)
    ? (raw as DashboardSection)
    : 'overview';
}

function AppRouter() {
  const { user, authReady, userProfile, company, dataLoading } = useAuth();
  const [pathname, setPathname] = useState(() => window.location.pathname || '/');
  const [searchParams, setSearchParams] = useState(() => new URLSearchParams(window.location.search));

  useEffect(() => {
    const onPopState = () => {
      setPathname(window.location.pathname || '/');
      setSearchParams(new URLSearchParams(window.location.search));
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigate = useCallback((target: string) => {
    if (window.location.pathname !== target) {
      window.history.pushState({}, '', target);
    }
    setPathname(target.split('?')[0] || '/');
    const qIdx = target.indexOf('?');
    setSearchParams(new URLSearchParams(qIdx >= 0 ? target.slice(qIdx + 1) : ''));
    window.scrollTo(0, 0);
  }, []);

  // Handle Firebase email action links (?mode=resetPassword&oobCode=... or verifyEmail)
  const firebaseMode = searchParams.get('mode');
  const oobCode = searchParams.get('oobCode');

  if (firebaseMode === 'resetPassword' && oobCode) {
    return <AuthViews mode="reset" oobCode={oobCode} onNavigate={navigate} />;
  }
  if (firebaseMode === 'verifyEmail' && oobCode) {
    return <AuthViews mode="verify" oobCode={oobCode} onNavigate={navigate} />;
  }

  // Protected route handling
  const isAppRoute = pathname.startsWith('/app') || pathname === '/onboarding';
  const isAuthRoute = pathname.startsWith('/auth');

  if (!authReady && isAppRoute) {
    return (
      <div className="min-h-screen bg-[#090D18] text-[#94A3B8] flex items-center justify-center text-sm">
        Initializing EGAI Enterprise...
      </div>
    );
  }

  // Redirect authenticated users away from /auth
  if (authReady && user && isAuthRoute) {
    if (!user.emailVerified) {
      return <AuthViews mode="verify" onNavigate={navigate} />;
    }
    if (!userProfile?.companyId) {
      return <OnboardingView />;
    }
  }

  // Unauthenticated trying to access private workspace
  if (authReady && !user && isAppRoute) {
    return <AuthViews mode="signin" onNavigate={navigate} />;
  }

  // Authenticated user routing
  if (user && (isAppRoute || (isAuthRoute && user.emailVerified && userProfile?.companyId))) {
    if (!user.emailVerified) {
      return <AuthViews mode="verify" onNavigate={navigate} />;
    }
    if (!userProfile?.companyId) {
      return <OnboardingView />;
    }
    if (dataLoading && !company) {
      return (
        <div className="min-h-screen bg-[#090D18] text-[#94A3B8] flex items-center justify-center text-sm">
          Loading Company Workspace...
        </div>
      );
    }
    if (!dataLoading && !company) {
      return <OnboardingView />;
    }

    const rawSection = pathname.replace(/^\/app\/?/, '');
    const activeSection: DashboardSection = normalizeSection(rawSection);

    const goToSection = (section: DashboardSection) => navigate(`/app/${section}`);

    return (
      <DashboardShell activeSection={activeSection} onSelectSection={goToSection}>
        {activeSection === 'intelligence' && <CompanyIntelligenceView />}
        {activeSection === 'forensics' && <FinancialForensicsView />}
        {activeSection === 'advisor' && <GrowthAdvisorView />}
        {activeSection === 'overview' && <OverviewView onNavigateSection={goToSection} />}
        {activeSection === 'workspace' && <WorkspaceView />}
        {activeSection === 'documents' && <DocumentsView />}
        {activeSection === 'reports' && <ReportsView />}
        {activeSection === 'team' && <TeamView />}
        {activeSection === 'settings' && <SettingsView />}
      </DashboardShell>
    );
  }

  // Auth routes when signed out
  if (isAuthRoute) {
    let mode: AuthMode = 'signin';
    if (pathname === '/auth/signup') mode = 'signup';
    else if (pathname === '/auth/forgot-password') mode = 'forgot';
    else if (pathname === '/auth/reset-password') mode = 'reset';
    else if (pathname === '/auth/verify-email') mode = 'verify';
    return <AuthViews mode={mode} oobCode={oobCode} onNavigate={navigate} />;
  }

  // Public Marketing Landing Page
  return <LandingPage onNavigate={navigate} />;
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppRouter />
      </AuthProvider>
    </LanguageProvider>
  );
}
