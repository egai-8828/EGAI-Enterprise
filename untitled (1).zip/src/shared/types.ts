export type Language = 'en' | 'ar';

export type UserRole = 'owner' | 'administrator' | 'analyst' | 'viewer';

export type SpecialistId =
  | 'finance'
  | 'bi'
  | 'hr'
  | 'marketing'
  | 'sales'
  | 'operations'
  | 'procurement'
  | 'customer_success'
  | 'risk_compliance'
  | 'strategy';

export type ActiveSpecialistId = SpecialistId;

export type SpecialistSelection = ActiveSpecialistId | 'auto';

export type WorkspaceDataDomain =
  | 'finance'
  | 'sales'
  | 'hr'
  | 'operations'
  | 'procurement'
  | 'marketing'
  | 'strategy';

export type GrowthAdvisorDomain =
  | 'finance'
  | 'sales'
  | 'marketing'
  | 'products'
  | 'operations'
  | 'hr'
  | 'procurement'
  | 'strategy';

export type PlanId = 'starter' | 'growth' | 'enterprise';

export type DocumentFormat = 'pdf' | 'xlsx' | 'csv' | 'docx' | 'txt';

export type DocumentStatus = 'processing' | 'ready' | 'error';

export type ReportType =
  | 'financial'
  | 'business_performance'
  | 'executive_summary'
  | 'data_analysis';

export type ReportStatus = 'generating' | 'ready' | 'failed';

export type AIProviderName = 'gemini' | 'bedrock';

export type CompanySize = '1-10' | '11-50' | '51-200' | '201-1000' | '1000+';

export type RecordVerificationStatus = 'pending_review' | 'verified' | 'disputed';

export type ForensicSeverity = 'high' | 'medium' | 'low';

export type ForensicStatus = 'open' | 'investigating' | 'resolved' | 'dismissed';

export type ForensicCategory =
  | 'duplicate_entry'
  | 'expense_spike'
  | 'statistical_outlier'
  | 'round_number_pattern'
  | 'margin_compression'
  | 'vendor_variance';

export type GrowthProposalStatus =
  | 'pending_approval'
  | 'approved'
  | 'rejected'
  | 'implemented';

export type AuditActionType =
  | 'document_uploaded'
  | 'document_deleted'
  | 'record_verified'
  | 'record_disputed'
  | 'rag_query'
  | 'forensics_scan'
  | 'forensic_status_updated'
  | 'proposal_generated'
  | 'proposal_approved'
  | 'proposal_rejected'
  | 'company_settings_updated'
  | 'member_invited'
  | 'member_role_changed'
  | 'member_removed'
  | 'company_purge_requested';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  preferredLanguage: Language;
  companyId?: string;
  appearance?: 'dark' | 'midnight';
  emailNotifications?: boolean;
  usageAlerts?: boolean;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface CompanyProfile {
  id: string;
  name: string;
  industry: string;
  size: CompanySize;
  country: string;
  preferredLanguage: Language;
  logoUrl?: string;
  ownerId: string;
  planId: PlanId;
  monthlyTokenLimit: number;
  monthlyRequestLimit: number;
  retentionDays?: number;
  allowSharedModelTraining?: boolean;
  companySummary?: string;
  strategicGoals?: string[];
  modelFocusData?: string;
  deletionRequestedAt?: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface CompanyMember {
  uid: string;
  companyId: string;
  email: string;
  displayName: string;
  role: UserRole;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface CompanyInvite {
  id: string;
  companyId: string;
  companyName: string;
  email: string;
  role: Exclude<UserRole, 'owner'>;
  invitedBy: string;
  status: 'pending' | 'accepted' | 'revoked';
  createdAt: unknown;
  updatedAt: unknown;
}

export interface BusinessDocument {
  id: string;
  companyId: string;
  uploadedBy: string;
  uploadedByName: string;
  fileName: string;
  fileType: DocumentFormat;
  fileSize: number;
  storageLocation: string;
  status: DocumentStatus;
  domain?: WorkspaceDataDomain;
  periodKey?: string;
  indexedChunkCount?: number;
  structuredRecordCount?: number;
  errorMessage?: string;
  pageCount?: number;
  sheetNames?: string[];
  textPreview?: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface StructuredBusinessRecord {
  id: string;
  companyId: string;
  domain: WorkspaceDataDomain;
  periodKey: string;
  metricKey: string;
  metricLabel: string;
  category: string;
  numericValue: number;
  unit: string;
  sourceDocumentId: string;
  sourceDocumentName: string;
  sourceLocation: string;
  verificationStatus: RecordVerificationStatus;
  verifiedBy?: string;
  createdBy: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface KnowledgeChunk {
  id: string;
  companyId: string;
  documentId: string;
  documentName: string;
  domain: WorkspaceDataDomain;
  periodKey: string;
  chunkIndex: number;
  locationLabel: string;
  content: string;
  keywords: string[];
  createdAt: unknown;
}

export interface ForensicFinding {
  id: string;
  companyId: string;
  category: ForensicCategory;
  severity: ForensicSeverity;
  titleEn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  evidence: string;
  sourceDocumentId: string;
  sourceDocumentName: string;
  sourceLocation: string;
  status: ForensicStatus;
  reviewedBy?: string;
  createdBy: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface GrowthProposal {
  id: string;
  companyId: string;
  domain: GrowthAdvisorDomain;
  title: string;
  detectedProblem: string;
  evidenceAndNumbers: string;
  proposedSolution: string;
  expectedCost: string;
  expectedReturn: string;
  executionPlan: string[];
  successMetrics: string;
  requiresManagementApproval: boolean;
  status: GrowthProposalStatus;
  sourceDocumentIds: string[];
  createdBy: string;
  approvedBy?: string;
  approvedByEmail?: string;
  approvalNote?: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface AuditLogEntry {
  id: string;
  companyId: string;
  actorUid: string;
  actorEmail: string;
  actorRole: UserRole;
  action: AuditActionType;
  targetType: string;
  targetId: string;
  summary: string;
  createdAt: unknown;
}

export interface Conversation {
  id: string;
  companyId: string;
  createdBy: string;
  title: string;
  specialistId: ActiveSpecialistId;
  documentIds?: string[];
  messageCount: number;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  companyId: string;
  senderId: string;
  role: 'user' | 'assistant';
  content: string;
  specialistId: ActiveSpecialistId;
  provider?: AIProviderName | 'user';
  model?: string;
  inputTokens?: number;
  outputTokens?: number;
  feedback?: 'none' | 'up' | 'down';
  createdAt: unknown;
  updatedAt: unknown;
}

export interface EnterpriseReport {
  id: string;
  companyId: string;
  createdBy: string;
  title: string;
  reportType: ReportType;
  specialistId: ActiveSpecialistId;
  conversationId?: string;
  documentIds?: string[];
  status: ReportStatus;
  content?: string;
  provider?: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface UsageLog {
  id: string;
  companyId: string;
  userId: string;
  userEmail: string;
  specialistId: ActiveSpecialistId;
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
  monthKey: string;
  action:
    | 'chat'
    | 'document_analysis'
    | 'report_generation'
    | 'intelligence_query'
    | 'growth_advisor'
    | 'forensics_scan'
    | 'document_classification';
  createdAt: unknown;
}

export interface IntegrationStatus {
  firebaseAuth: {
    configured: boolean;
    projectId: string;
  };
  firestore: {
    configured: boolean;
    databaseId: string;
  };
  bedrock: {
    configured: boolean;
    region: string;
    modelId: string;
    requiredEnv: string[];
  };
  gemini: {
    configured: boolean;
    model: string;
  };
  s3Storage: {
    configured: boolean;
    bucket: string;
    mode: 'aws_s3' | 'local_disk';
  };
  billingProvider: {
    configured: boolean;
    provider: 'paymob';
    requiredEnv: string[];
  };
  activeAiProvider: AIProviderName;
}

export interface NumericColumnSummary {
  column: string;
  count: number;
  sum: number;
  mean: number;
  min: number;
  max: number;
  anomalies: number[];
}

export interface SheetSummary {
  sheetName: string;
  rowCount: number;
  headers: string[];
  numericSummaries: NumericColumnSummary[];
  sampleRows: Record<string, string | number>[];
}
