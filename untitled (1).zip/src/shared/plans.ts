import type { PlanId } from './types.ts';

export interface PlanDefinition {
  id: PlanId;
  nameEn: string;
  nameAr: string;
  audienceEn: string;
  audienceAr: string;
  priceMonthlyUsd: number | null;
  monthlyTokenLimit: number;
  monthlyRequestLimit: number;
  maxFileSizeMb: number;
  maxTeamMembers: number;
  featuresEn: string[];
  featuresAr: string[];
}

export const PLANS: Record<PlanId, PlanDefinition> = {
  starter: {
    id: 'starter',
    nameEn: 'Starter Workspace',
    nameAr: 'باقة البداية',
    audienceEn: 'For small teams validating AI financial & BI workflows',
    audienceAr: 'للفرق الصغيرة التي تبدأ بتحليل المالية وذكاء الأعمال',
    priceMonthlyUsd: 0,
    monthlyTokenLimit: 250000,
    monthlyRequestLimit: 250,
    maxFileSizeMb: 10,
    maxTeamMembers: 5,
    featuresEn: [
      '250,000 monthly AI tokens',
      '250 monthly AI requests',
      'Up to 5 team members',
      '10 MB max document size (PDF, XLSX, CSV, DOCX, TXT)',
      'Finance & Business Intelligence Specialists',
    ],
    featuresAr: [
      '250,000 توكن ذكاء اصطناعي شهرياً',
      '250 طلب تحليل ومحادثة شهرياً',
      'حتى 5 أعضاء في الفريق',
      'حد أقصى 10 ميجابايت للملف (PDF, XLSX, CSV, DOCX, TXT)',
      'أخصائيا المالية وذكاء الأعمال',
    ],
  },
  growth: {
    id: 'growth',
    nameEn: 'Growth Enterprise',
    nameAr: 'باقة النمو المؤسسي',
    audienceEn: 'For scaling finance, operations, and analytics teams',
    audienceAr: 'للفرق النامية في المالية والعمليات والتحليلات',
    priceMonthlyUsd: 199,
    monthlyTokenLimit: 2500000,
    monthlyRequestLimit: 2500,
    maxFileSizeMb: 20,
    maxTeamMembers: 25,
    featuresEn: [
      '2,500,000 monthly AI tokens',
      '2,500 monthly AI requests',
      'Up to 25 team members with RBAC',
      '20 MB max document size',
      'Priority Amazon Bedrock & multi-document reports',
    ],
    featuresAr: [
      '2,500,000 توكن ذكاء اصطناعي شهرياً',
      '2,500 طلب شهرياً',
      'حتى 25 عضواً بصلاحيات الأدوار RBAC',
      'حد أقصى 20 ميجابايت للملف',
      'تكامل Amazon Bedrock وتقارير متعددة المستندات',
    ],
  },
  enterprise: {
    id: 'enterprise',
    nameEn: 'Dedicated Enterprise',
    nameAr: 'الباقة المؤسسية المتقدمة',
    audienceEn: 'For organizations with custom governance and volume SLAs',
    audienceAr: 'للمؤسسات الكبيرة ذات متطلبات الحوكمة والسعة المخصصة',
    priceMonthlyUsd: null,
    monthlyTokenLimit: 20000000,
    monthlyRequestLimit: 25000,
    maxFileSizeMb: 50,
    maxTeamMembers: 500,
    featuresEn: [
      '20,000,000+ configurable monthly AI tokens',
      '25,000+ monthly AI requests',
      'Unlimited department rollout & custom RBAC',
      'Dedicated AWS Bedrock & S3 VPC storage option',
      'Executive governance & custom retention rules',
    ],
    featuresAr: [
      '20,000,000+ توكن شهرياً قابلة للتخصيص',
      '25,000+ طلب شهرياً',
      'دعم التوسع لجميع الأقسام وصلاحيات مخصصة',
      'خيار تخزين AWS S3 وربط Bedrock مخصص',
      'حوكمة تنفيذية وسياسات احتفاظ مخصصة',
    ],
  },
};

export interface QuotaEvaluation {
  tokensUsed: number;
  requestsUsed: number;
  tokenLimit: number;
  requestLimit: number;
  tokensRemaining: number;
  requestsRemaining: number;
  tokenUsagePct: number;
  requestUsagePct: number;
  exceeded: boolean;
  reason: 'ok' | 'token_limit_exceeded' | 'request_limit_exceeded';
}

export function evaluateQuotaStatus(
  tokensUsed: number,
  requestsUsed: number,
  tokenLimit: number,
  requestLimit: number
): QuotaEvaluation {
  const safeTokenLimit = Math.max(1, tokenLimit);
  const safeRequestLimit = Math.max(1, requestLimit);
  const tokensRemaining = Math.max(0, safeTokenLimit - tokensUsed);
  const requestsRemaining = Math.max(0, safeRequestLimit - requestsUsed);
  const tokenUsagePct = Math.min(100, Math.round((tokensUsed / safeTokenLimit) * 100));
  const requestUsagePct = Math.min(100, Math.round((requestsUsed / safeRequestLimit) * 100));

  let reason: QuotaEvaluation['reason'] = 'ok';
  if (tokensUsed >= safeTokenLimit) {
    reason = 'token_limit_exceeded';
  } else if (requestsUsed >= safeRequestLimit) {
    reason = 'request_limit_exceeded';
  }

  return {
    tokensUsed,
    requestsUsed,
    tokenLimit: safeTokenLimit,
    requestLimit: safeRequestLimit,
    tokensRemaining,
    requestsRemaining,
    tokenUsagePct,
    requestUsagePct,
    exceeded: reason !== 'ok',
    reason,
  };
}
