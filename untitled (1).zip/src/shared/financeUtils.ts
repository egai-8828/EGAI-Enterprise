import type { NumericColumnSummary, SheetSummary } from './types.ts';

export function summarizeTabularRows(
  sheetName: string,
  rows: Record<string, unknown>[]
): SheetSummary {
  const headers = Array.from(
    rows.reduce<Set<string>>((acc, row) => {
      for (const key of Object.keys(row)) {
        acc.add(key);
      }
      return acc;
    }, new Set<string>())
  );

  const numericSummaries: NumericColumnSummary[] = [];

  for (const col of headers) {
    const values: number[] = [];
    for (const row of rows) {
      const raw = row[col];
      if (typeof raw === 'number' && Number.isFinite(raw)) {
        values.push(raw);
      } else if (typeof raw === 'string') {
        const cleaned = raw.replace(/[$,%\s,]/g, '');
        if (cleaned.length > 0 && !Number.isNaN(Number(cleaned))) {
          values.push(Number(cleaned));
        }
      }
    }

    if (values.length >= 2) {
      const sum = values.reduce((a, b) => a + b, 0);
      const mean = sum / values.length;
      const min = Math.min(...values);
      const max = Math.max(...values);

      const variance =
        values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / values.length;
      const stdDev = Math.sqrt(variance);
      const anomalies =
        stdDev > 0
          ? values.filter((v) => Math.abs(v - mean) > 2 * stdDev).slice(0, 5)
          : [];

      numericSummaries.push({
        column: col,
        count: values.length,
        sum: Number(sum.toFixed(4)),
        mean: Number(mean.toFixed(4)),
        min,
        max,
        anomalies,
      });
    }
  }

  const sampleRows = rows.slice(0, 15).map((r) => {
    const clean: Record<string, string | number> = {};
    for (const h of headers) {
      const v = r[h];
      clean[h] = typeof v === 'number' || typeof v === 'string' ? v : String(v ?? '');
    }
    return clean;
  });

  return {
    sheetName,
    rowCount: rows.length,
    headers,
    numericSummaries,
    sampleRows,
  };
}

export function getCurrentMonthKey(date: Date = new Date()): string {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

export function sanitizeEnvSetting(raw: string | undefined, keyName: string): string {
  if (!raw) return '';
  let trimmed = raw.trim();
  const prefix = `${keyName}=`;
  if (trimmed.toUpperCase().startsWith(prefix.toUpperCase())) {
    trimmed = trimmed.slice(prefix.length).trim();
  }
  return trimmed.replace(/^["']|["']$/g, '').trim();
}

