import type {
  ForensicFinding,
  GrowthAdvisorDomain,
  GrowthProposal,
  KnowledgeChunk,
  Language,
  SheetSummary,
  StructuredBusinessRecord,
  WorkspaceDataDomain,
} from './types.ts';

export interface DataDomainMeta {
  id: WorkspaceDataDomain;
  nameEn: string;
  nameAr: string;
  examplesEn: string;
  examplesAr: string;
}

export const WORKSPACE_DATA_DOMAINS: DataDomainMeta[] = [
  {
    id: 'finance',
    nameEn: 'Finance',
    nameAr: 'المالية',
    examplesEn: 'Invoices, Expenses, Revenues, P&L',
    examplesAr: 'الفواتير، المصروفات، الإيرادات، القوائم المالية',
  },
  {
    id: 'sales',
    nameEn: 'Sales',
    nameAr: 'المبيعات',
    examplesEn: 'Sales ledger, Customers, Products',
    examplesAr: 'المبيعات، العملاء، المنتجات',
  },
  {
    id: 'hr',
    nameEn: 'HR',
    nameAr: 'الموارد البشرية',
    examplesEn: 'Employees, Payroll, Attendance',
    examplesAr: 'الموظفون، الرواتب، الحضور',
  },
  {
    id: 'operations',
    nameEn: 'Operations',
    nameAr: 'العمليات',
    examplesEn: 'Operations, Production, Throughput',
    examplesAr: 'التشغيل، الإنتاج، الأداء',
  },
  {
    id: 'procurement',
    nameEn: 'Procurement',
    nameAr: 'المشتريات',
    examplesEn: 'Suppliers, Purchases, Contracts',
    examplesAr: 'الموردون، المشتريات، العقود',
  },
  {
    id: 'marketing',
    nameEn: 'Marketing',
    nameAr: 'التسويق',
    examplesEn: 'Campaigns, Ad Spend, Conversion Results',
    examplesAr: 'الحملات، الإعلانات، النتائج',
  },
  {
    id: 'strategy',
    nameEn: 'Strategy',
    nameAr: 'الاستراتيجية',
    examplesEn: 'Goals, Annual Plans, KPIs',
    examplesAr: 'الأهداف، الخطط، مؤشرات الأداء',
  },
];

export interface GrowthDomainMeta {
  id: GrowthAdvisorDomain;
  nameEn: string;
  nameAr: string;
  focusEn: string;
  focusAr: string;
}

export const GROWTH_ADVISOR_DOMAINS: GrowthDomainMeta[] = [
  {
    id: 'finance',
    nameEn: 'Finance',
    nameAr: 'المالية',
    focusEn: 'Reduce unnecessary operating expenses & protect cash margin',
    focusAr: 'تقليل المصروفات غير الضرورية وحماية هامش الربح',
  },
  {
    id: 'sales',
    nameEn: 'Sales',
    nameAr: 'المبيعات',
    focusEn: 'Improve lead-to-customer conversion & account expansion',
    focusAr: 'تحسين معدل تحويل العملاء ورفع قيمة الصفقة',
  },
  {
    id: 'marketing',
    nameEn: 'Marketing',
    nameAr: 'التسويق',
    focusEn: 'Reallocate ad budget toward highest-ROAS channels',
    focusAr: 'إعادة توزيع ميزانية الإعلانات نحو القنوات الأعلى عائداً',
  },
  {
    id: 'products',
    nameEn: 'Products',
    nameAr: 'المنتجات',
    focusEn: 'Identify underperforming SKUs & margin-dilutive lines',
    focusAr: 'تحديد المنتجات ضعيفة الأداء وتحسين مزيج المنتجات',
  },
  {
    id: 'operations',
    nameEn: 'Operations',
    nameAr: 'العمليات',
    focusEn: 'Reduce operational waste & boost throughput productivity',
    focusAr: 'تقليل الهدر وتحسين الإنتاجية التشغيلية',
  },
  {
    id: 'hr',
    nameEn: 'HR',
    nameAr: 'الموارد البشرية',
    focusEn: 'Close critical skill gaps & align payroll to output',
    focusAr: 'اكتشاف فجوات المهارات ومواءمة تكلفة الرواتب',
  },
  {
    id: 'procurement',
    nameEn: 'Procurement',
    nameAr: 'المشتريات',
    focusEn: 'Benchmark vendor pricing & consolidate supplier contracts',
    focusAr: 'مقارنة أسعار الموردين وتوحيد عقود الشراء',
  },
  {
    id: 'strategy',
    nameEn: 'Strategy',
    nameAr: 'الاستراتيجية',
    focusEn: 'Establish measurable quarterly growth & margin targets',
    focusAr: 'اقتراح أهداف نمو قابلة للقياس ومؤشرات متابعة',
  },
];

const STOP_WORDS = new Set([
  'the',
  'and',
  'for',
  'with',
  'that',
  'this',
  'from',
  'are',
  'was',
  'were',
  'have',
  'has',
  'why',
  'what',
  'how',
  'our',
  'your',
  'في',
  'من',
  'على',
  'إلى',
  'عن',
  'مع',
  'هذا',
  'هذه',
  'التي',
  'الذي',
  'ما',
  'هل',
  'تم',
  'كل',
  'او',
  'و',
]);

export function normalizeTextToken(input: string): string {
  return input
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '') // strip Arabic diacritics
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .trim();
}

export function tokenizeForSearch(text: string): string[] {
  const normalized = normalizeTextToken(text);
  const matches = normalized.match(/[a-z0-9\u0600-\u06FF_]{2,}/g) || [];
  return matches.filter((tok) => !STOP_WORDS.has(tok));
}

export function extractTopKeywords(text: string, limit = 14): string[] {
  const tokens = tokenizeForSearch(text);
  const freq = new Map<string, number>();
  for (const t of tokens) {
    freq.set(t, (freq.get(t) || 0) + 1);
  }
  return Array.from(freq.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([k]) => k.slice(0, 48));
}

export function inferDomainFromText(fileName: string, textSample = ''): WorkspaceDataDomain {
  const combined = normalizeTextToken(`${fileName} ${textSample.slice(0, 800)}`);
  if (/(invoice|expense|revenue|profit|p&l|ledger|balance|budget|فاتور|مصروف|ايراد|ربح|ميزان)/.test(combined)) {
    return 'finance';
  }
  if (/(sale|customer|deal|pipeline|crm|product|sku|مبيع|عميل|عملاء|منتج)/.test(combined)) {
    return 'sales';
  }
  if (/(payroll|salary|employee|attendance|hr|staff|موظف|راتب|رواتب|حضور)/.test(combined)) {
    return 'hr';
  }
  if (/(supplier|vendor|procurement|purchase|contract|po|مورد|مشتري|عقد|عقود)/.test(combined)) {
    return 'procurement';
  }
  if (/(campaign|marketing|ad|roas|ctr|impression|حمل|اعلان|تسويق)/.test(combined)) {
    return 'marketing';
  }
  if (/(operation|production|factory|supply|waste|throughput|تشغيل|انتاج|اداء)/.test(combined)) {
    return 'operations';
  }
  if (/(strategy|goal|okr|roadmap|kpi|objective|استراتيج|هدف|اهداف|خطه)/.test(combined)) {
    return 'strategy';
  }
  return 'finance';
}

export interface ChunkDraft {
  chunkIndex: number;
  locationLabel: string;
  content: string;
  keywords: string[];
}

export function chunkDocumentText(params: {
  fullText: string;
  fileName: string;
  maxChunkChars?: number;
  maxChunks?: number;
}): ChunkDraft[] {
  const maxChunkChars = params.maxChunkChars ?? 680;
  const maxChunks = params.maxChunks ?? 24;
  const raw = (params.fullText || '').trim();
  if (!raw) return [];

  const blocks = raw.split(/\n{2,}/);
  const chunks: ChunkDraft[] = [];
  let currentLocation = params.fileName;
  let buffer = '';

  const flush = () => {
    const trimmed = buffer.trim();
    if (!trimmed) return;
    chunks.push({
      chunkIndex: chunks.length,
      locationLabel: currentLocation.slice(0, 120),
      content: trimmed.slice(0, 2400),
      keywords: extractTopKeywords(trimmed),
    });
    buffer = '';
  };

  for (const block of blocks) {
    const clean = block.trim();
    if (!clean) continue;

    const pageMatch = clean.match(/^\[Page\s+(\d+)\]/i);
    const sheetMatch = clean.match(/^\[Sheet\s+"([^"]+)"/i);
    if (pageMatch) {
      if (buffer.trim().length > 0) {
        flush();
        if (chunks.length >= maxChunks) break;
      }
      currentLocation = `Page ${pageMatch[1]}`;
    } else if (sheetMatch) {
      if (buffer.trim().length > 0) {
        flush();
        if (chunks.length >= maxChunks) break;
      }
      currentLocation = `Sheet "${sheetMatch[1]}"`;
    }

    if ((buffer + '\n\n' + clean).length > maxChunkChars && buffer.length > 0) {
      flush();
      if (chunks.length >= maxChunks) break;
    }

    if (clean.length > maxChunkChars) {
      let offset = 0;
      while (offset < clean.length && chunks.length < maxChunks) {
        const slice = clean.slice(offset, offset + maxChunkChars);
        chunks.push({
          chunkIndex: chunks.length,
          locationLabel: currentLocation.slice(0, 120),
          content: slice,
          keywords: extractTopKeywords(slice),
        });
        offset += Math.max(200, maxChunkChars - 100);
      }
      buffer = '';
    } else {
      buffer = buffer ? `${buffer}\n\n${clean}` : clean;
    }

    if (chunks.length >= maxChunks) break;
  }

  if (buffer.trim() && chunks.length < maxChunks) {
    flush();
  }

  return chunks;
}

export interface ExtractedRecordDraft {
  domain: WorkspaceDataDomain;
  periodKey: string;
  metricKey: string;
  metricLabel: string;
  category: string;
  numericValue: number;
  unit: string;
  sourceLocation: string;
}

function parseNumericCell(val: unknown): number | null {
  if (typeof val === 'number' && Number.isFinite(val)) return val;
  if (typeof val === 'string') {
    const cleaned = val.replace(/[$,%\s,]/g, '').trim();
    if (cleaned.length > 0 && /^-?\d+(\.\d+)?$/.test(cleaned)) {
      const n = Number(cleaned);
      return Number.isFinite(n) ? n : null;
    }
  }
  return null;
}

function classifyMetricKey(columnOrLabel: string): { metricKey: string; unit: string } {
  const norm = normalizeTextToken(columnOrLabel);
  if (/(revenue|sales|income|turnover|ايراد|مبيع|دخل)/.test(norm)) {
    return { metricKey: 'revenue', unit: 'currency' };
  }
  if (/(expense|cost|opex|cogs|spend|مصروف|تكلف|نفق)/.test(norm)) {
    return { metricKey: 'expenses', unit: 'currency' };
  }
  if (/(profit|ebitda|net|margin|ربح|صافي|هامش)/.test(norm)) {
    return {
      metricKey: /(margin|%|pct|نسبه|هامش)/.test(norm) ? 'profit_margin' : 'net_profit',
      unit: /(margin|%|pct|نسبه|هامش)/.test(norm) ? '%' : 'currency',
    };
  }
  if (/(payroll|salary|wages|راتب|رواتب)/.test(norm)) {
    return { metricKey: 'payroll', unit: 'currency' };
  }
  if (/(headcount|employee|staff|موظف)/.test(norm)) {
    return { metricKey: 'headcount', unit: 'count' };
  }
  if (/(marketing|ad|campaign|تسويق|اعلان)/.test(norm)) {
    return { metricKey: 'marketing_spend', unit: 'currency' };
  }
  if (/(procure|vendor|supplier|purchase|مورد|مشتري)/.test(norm)) {
    return { metricKey: 'procurement_spend', unit: 'currency' };
  }
  if (/(conversion|rate|roas|ctr|تحويل)/.test(norm)) {
    return { metricKey: 'conversion_rate', unit: '%' };
  }
  return { metricKey: 'kpi_metric', unit: 'value' };
}

function normalizePeriodFromRow(row: Record<string, string | number>, fallbackPeriod: string): string {
  for (const [k, v] of Object.entries(row)) {
    const keyNorm = normalizeTextToken(k);
    if (/(month|period|date|quarter|year|شهر|فتره|تاريخ|ربع)/.test(keyNorm)) {
      const s = String(v).trim();
      if (s.length >= 2 && s.length <= 32) {
        return s.slice(0, 32);
      }
    }
  }
  return fallbackPeriod;
}

export function extractStructuredRecordsFromSheets(params: {
  sheets: SheetSummary[];
  domain: WorkspaceDataDomain;
  defaultPeriodKey: string;
  maxRecords?: number;
}): ExtractedRecordDraft[] {
  const maxRecords = params.maxRecords ?? 40;
  const records: ExtractedRecordDraft[] = [];

  for (const sheet of params.sheets) {
    if (sheet.sampleRows.length > 0) {
      for (let rowIdx = 0; rowIdx < sheet.sampleRows.length; rowIdx++) {
        const row = sheet.sampleRows[rowIdx];
        const rowPeriod = normalizePeriodFromRow(row, params.defaultPeriodKey);
        const categoryCell =
          Object.entries(row).find(([k]) =>
            /(category|department|vendor|product|name|item|channel|بند|قسم|مورد|منتج|تصنيف)/i.test(k)
          )?.[1] ?? sheet.sheetName;

        for (const [col, val] of Object.entries(row)) {
          if (/(month|period|date|year|id|code|شهر|تاريخ|كود)/i.test(col)) continue;
          const num = parseNumericCell(val);
          if (num === null) continue;
          const classified = classifyMetricKey(col);
          records.push({
            domain: params.domain,
            periodKey: rowPeriod,
            metricKey: classified.metricKey,
            metricLabel: col.slice(0, 100),
            category: String(categoryCell || sheet.sheetName).slice(0, 100) || sheet.sheetName,
            numericValue: num,
            unit: classified.unit,
            sourceLocation: `Sheet "${sheet.sheetName}" Row ${rowIdx + 2}`,
          });
          if (records.length >= maxRecords) return records;
        }
      }
    } else {
      for (const summary of sheet.numericSummaries) {
        const classified = classifyMetricKey(summary.column);
        records.push({
          domain: params.domain,
          periodKey: params.defaultPeriodKey,
          metricKey: classified.metricKey,
          metricLabel: `${summary.column} (Total)`.slice(0, 100),
          category: sheet.sheetName.slice(0, 100),
          numericValue: summary.sum,
          unit: classified.unit,
          sourceLocation: `Sheet "${sheet.sheetName}" Summary`,
        });
        if (records.length >= maxRecords) return records;
      }
    }
  }

  return records;
}

export function extractStructuredRecordsFromText(params: {
  fullText: string;
  domain: WorkspaceDataDomain;
  defaultPeriodKey: string;
  maxRecords?: number;
}): ExtractedRecordDraft[] {
  const maxRecords = params.maxRecords ?? 25;
  const records: ExtractedRecordDraft[] = [];
  const lines = params.fullText.split(/\r?\n/);
  let currentPage = 'Document Text';

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const pageMatch = trimmed.match(/^\[Page\s+(\d+)\]/i);
    if (pageMatch) {
      currentPage = `Page ${pageMatch[1]}`;
      continue;
    }

    const kvMatch = trimmed.match(
      /^([A-Za-z\u0600-\u06FF][A-Za-z0-9\u0600-\u06FF\s/&_-]{2,50})[:\-–]\s*([$£€]?\s*-?\d[\d,]*(?:\.\d+)?\s*%?)/
    );
    if (kvMatch) {
      const label = kvMatch[1].trim();
      const rawVal = kvMatch[2].trim();
      const num = parseNumericCell(rawVal);
      if (num !== null) {
        const classified = classifyMetricKey(label);
        records.push({
          domain: params.domain,
          periodKey: params.defaultPeriodKey,
          metricKey: classified.metricKey,
          metricLabel: label.slice(0, 100),
          category: params.domain,
          numericValue: num,
          unit: rawVal.includes('%') ? '%' : classified.unit,
          sourceLocation: currentPage,
        });
        if (records.length >= maxRecords) break;
      }
    }
  }

  return records;
}

export interface RankedChunkResult {
  chunk: KnowledgeChunk;
  score: number;
  matchedTerms: string[];
}

export function searchKnowledgeChunks(
  query: string,
  chunks: KnowledgeChunk[],
  limit = 6,
  domainFilter?: WorkspaceDataDomain | 'all'
): RankedChunkResult[] {
  const candidates =
    domainFilter && domainFilter !== 'all'
      ? chunks.filter((c) => c.domain === domainFilter)
      : chunks;
  if (candidates.length === 0) return [];

  const queryTokens = tokenizeForSearch(query);
  if (queryTokens.length === 0) {
    return candidates.slice(0, limit).map((chunk) => ({
      chunk,
      score: 0.5,
      matchedTerms: [],
    }));
  }

  // Compute IDF across chunks
  const df = new Map<string, number>();
  for (const c of candidates) {
    const docTokens = new Set([...tokenizeForSearch(c.content), ...(c.keywords || [])]);
    for (const qt of queryTokens) {
      if (docTokens.has(qt)) {
        df.set(qt, (df.get(qt) || 0) + 1);
      }
    }
  }

  const normalizedQuery = normalizeTextToken(query);
  const scored: RankedChunkResult[] = [];

  for (const c of candidates) {
    const contentNorm = normalizeTextToken(c.content);
    const contentTokens = tokenizeForSearch(c.content);
    const keywordSet = new Set(c.keywords || []);
    const tf = new Map<string, number>();
    for (const t of contentTokens) {
      tf.set(t, (tf.get(t) || 0) + 1);
    }

    let score = 0;
    const matchedTerms: string[] = [];

    for (const qt of new Set(queryTokens)) {
      const termFreq = tf.get(qt) || 0;
      const inKeywords = keywordSet.has(qt) ? 1 : 0;
      if (termFreq > 0 || inKeywords > 0) {
        matchedTerms.push(qt);
        const docFreq = df.get(qt) || 1;
        const idf = Math.log(1 + candidates.length / docFreq);
        score += (termFreq + inKeywords * 1.5) * idf;
      }
    }

    if (normalizedQuery.length >= 4 && contentNorm.includes(normalizedQuery)) {
      score += 3;
    }

    if (score > 0) {
      scored.push({
        chunk: c,
        score: Number(score.toFixed(3)),
        matchedTerms,
      });
    }
  }

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}

export interface PeriodSummaryPoint {
  periodKey: string;
  revenue: number;
  expenses: number;
  netProfit: number;
  recordCount: number;
}

export interface CompanyAnalyticsSnapshot {
  totalRecords: number;
  verifiedCount: number;
  pendingCount: number;
  disputedCount: number;
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  profitMarginPct: number | null;
  revenueGrowthPct: number | null;
  expenseGrowthPct: number | null;
  periods: PeriodSummaryPoint[];
  domainCounts: Record<WorkspaceDataDomain, number>;
}

export function computePeriodAnalytics(records: StructuredBusinessRecord[]): CompanyAnalyticsSnapshot {
  const domainCounts: Record<WorkspaceDataDomain, number> = {
    finance: 0,
    sales: 0,
    hr: 0,
    operations: 0,
    procurement: 0,
    marketing: 0,
    strategy: 0,
  };

  let verifiedCount = 0;
  let pendingCount = 0;
  let disputedCount = 0;

  const byPeriod = new Map<string, PeriodSummaryPoint>();

  for (const r of records) {
    if (r.domain in domainCounts) {
      domainCounts[r.domain] += 1;
    }
    if (r.verificationStatus === 'verified') verifiedCount += 1;
    else if (r.verificationStatus === 'disputed') disputedCount += 1;
    else pendingCount += 1;

    if (r.verificationStatus === 'disputed') continue;

    const pt = byPeriod.get(r.periodKey) || {
      periodKey: r.periodKey,
      revenue: 0,
      expenses: 0,
      netProfit: 0,
      recordCount: 0,
    };
    pt.recordCount += 1;

    if (r.metricKey === 'revenue') {
      pt.revenue += r.numericValue;
    } else if (
      r.metricKey === 'expenses' ||
      r.metricKey === 'payroll' ||
      r.metricKey === 'marketing_spend' ||
      r.metricKey === 'procurement_spend'
    ) {
      pt.expenses += r.numericValue;
    } else if (r.metricKey === 'net_profit') {
      pt.netProfit += r.numericValue;
    }
    byPeriod.set(r.periodKey, pt);
  }

  const periods = Array.from(byPeriod.values())
    .map((p) => ({
      ...p,
      netProfit: p.netProfit !== 0 ? p.netProfit : p.revenue - p.expenses,
    }))
    .sort((a, b) => a.periodKey.localeCompare(b.periodKey));

  const totalRevenue = periods.reduce((s, p) => s + p.revenue, 0);
  const totalExpenses = periods.reduce((s, p) => s + p.expenses, 0);
  const netProfit = totalRevenue - totalExpenses;
  const profitMarginPct =
    totalRevenue > 0 ? Number(((netProfit / totalRevenue) * 100).toFixed(2)) : null;

  let revenueGrowthPct: number | null = null;
  let expenseGrowthPct: number | null = null;

  if (periods.length >= 2) {
    const first = periods[0];
    const last = periods[periods.length - 1];
    if (first.revenue > 0) {
      revenueGrowthPct = Number((((last.revenue - first.revenue) / first.revenue) * 100).toFixed(2));
    }
    if (first.expenses > 0) {
      expenseGrowthPct = Number(
        (((last.expenses - first.expenses) / first.expenses) * 100).toFixed(2)
      );
    }
  }

  return {
    totalRecords: records.length,
    verifiedCount,
    pendingCount,
    disputedCount,
    totalRevenue: Number(totalRevenue.toFixed(2)),
    totalExpenses: Number(totalExpenses.toFixed(2)),
    netProfit: Number(netProfit.toFixed(2)),
    profitMarginPct,
    revenueGrowthPct,
    expenseGrowthPct,
    periods,
    domainCounts,
  };
}

export type ForensicFindingDraft = Omit<
  ForensicFinding,
  'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'
>;

export function runFinancialForensics(params: {
  records: StructuredBusinessRecord[];
  sheets?: Array<{
    docId: string;
    fileName: string;
    sheets: SheetSummary[];
  }>;
}): ForensicFindingDraft[] {
  const findings: ForensicFindingDraft[] = [];
  const analytics = computePeriodAnalytics(params.records);

  // 1. Margin compression: expenses outgrowing revenue
  if (
    analytics.revenueGrowthPct !== null &&
    analytics.expenseGrowthPct !== null &&
    analytics.expenseGrowthPct > analytics.revenueGrowthPct
  ) {
    const gap = Number((analytics.expenseGrowthPct - analytics.revenueGrowthPct).toFixed(1));
    const latestDoc = params.records[0];
    findings.push({
      category: 'margin_compression',
      severity: gap >= 10 ? 'high' : 'medium',
      titleEn: 'Expense Growth Outpacing Revenue Growth',
      titleAr: 'نمو المصروفات يتجاوز نمو الإيرادات',
      descriptionEn: `Expenses increased by ${analytics.expenseGrowthPct}% while revenue grew by ${analytics.revenueGrowthPct}% across stored periods, compressing net operating margin by ${gap} percentage points.`,
      descriptionAr: `ارتفعت المصروفات بنسبة ${analytics.expenseGrowthPct}% مقارنة بنمو الإيرادات بنسبة ${analytics.revenueGrowthPct}% عبر الفترات المسجلة، مما يضغط على هامش الربح بفارق ${gap} نقطة مئوية.`,
      evidence: `Revenue growth: ${analytics.revenueGrowthPct}% vs Expense growth: ${analytics.expenseGrowthPct}% across ${analytics.periods.length} periods.`,
      sourceDocumentId: latestDoc?.sourceDocumentId || 'workspace_analytics',
      sourceDocumentName: latestDoc?.sourceDocumentName || 'Period Comparison Engine',
      sourceLocation: analytics.periods.map((p) => p.periodKey).join(' -> ').slice(0, 120),
      status: 'open',
    });
  }

  // 2. Period-over-period expense spike (> 25%)
  for (let i = 1; i < analytics.periods.length; i++) {
    const prev = analytics.periods[i - 1];
    const curr = analytics.periods[i];
    if (prev.expenses > 0) {
      const pct = ((curr.expenses - prev.expenses) / prev.expenses) * 100;
      if (pct >= 25) {
        const refRec = params.records.find((r) => r.periodKey === curr.periodKey);
        findings.push({
          category: 'expense_spike',
          severity: pct >= 50 ? 'high' : 'medium',
          titleEn: `Sharp Expense Spike in ${curr.periodKey} (+${pct.toFixed(1)}%)`,
          titleAr: `قفزة حادة في المصروفات خلال ${curr.periodKey} (+${pct.toFixed(1)}%)`,
          descriptionEn: `Total recorded expenses jumped from ${prev.expenses.toLocaleString()} (${prev.periodKey}) to ${curr.expenses.toLocaleString()} (${curr.periodKey}).`,
          descriptionAr: `ارتفع إجمالي المصروفات من ${prev.expenses.toLocaleString()} (${prev.periodKey}) إلى ${curr.expenses.toLocaleString()} (${curr.periodKey}).`,
          evidence: `${prev.periodKey}: ${prev.expenses} -> ${curr.periodKey}: ${curr.expenses} (+${pct.toFixed(1)}%)`,
          sourceDocumentId: refRec?.sourceDocumentId || 'period_diff',
          sourceDocumentName: refRec?.sourceDocumentName || 'Structured Ledger',
          sourceLocation: refRec?.sourceLocation || curr.periodKey,
          status: 'open',
        });
      }
    }
  }

  // 3. Duplicate exact expense/procurement amounts in same category/period
  const seenExpenseMap = new Map<string, StructuredBusinessRecord>();
  for (const r of params.records) {
    if (
      (r.metricKey === 'expenses' ||
        r.metricKey === 'procurement_spend' ||
        r.metricKey === 'marketing_spend') &&
      r.numericValue > 0
    ) {
      const sig = `${r.periodKey}|${normalizeTextToken(r.category)}|${r.numericValue.toFixed(2)}`;
      const existing = seenExpenseMap.get(sig);
      if (existing && existing.id !== r.id) {
        findings.push({
          category: 'duplicate_entry',
          severity: 'high',
          titleEn: `Potential Duplicate Charge: ${r.category} (${r.numericValue.toLocaleString()})`,
          titleAr: `اشتباه في تكرار قيد مالي: ${r.category} (${r.numericValue.toLocaleString()})`,
          descriptionEn: `Identical amount (${r.numericValue.toLocaleString()}) under "${r.category}" for ${r.periodKey} appears in multiple entries.`,
          descriptionAr: `تم رصد مبلغ متطابق (${r.numericValue.toLocaleString()}) لنفس الفئة "${r.category}" في الفترة ${r.periodKey} عبر أكثر من سجل.`,
          evidence: `Entry 1: ${existing.sourceDocumentName} (${existing.sourceLocation}) | Entry 2: ${r.sourceDocumentName} (${r.sourceLocation})`,
          sourceDocumentId: r.sourceDocumentId,
          sourceDocumentName: r.sourceDocumentName,
          sourceLocation: r.sourceLocation,
          status: 'open',
        });
      } else {
        seenExpenseMap.set(sig, r);
      }
    }
  }

  // 4. Round-number clustering in financial/procurement expenses (>=3 exact multiples of 1000)
  const roundExpenseRecords = params.records.filter(
    (r) =>
      (r.metricKey === 'expenses' || r.metricKey === 'procurement_spend') &&
      r.numericValue >= 1000 &&
      r.numericValue % 1000 === 0
  );
  if (roundExpenseRecords.length >= 3) {
    const sample = roundExpenseRecords[0];
    findings.push({
      category: 'round_number_pattern',
      severity: 'medium',
      titleEn: `Round-Number Expense Pattern (${roundExpenseRecords.length} entries)`,
      titleAr: `نمط مبالغ مصروفات دائرية غير مفصلة (${roundExpenseRecords.length} سجلات)`,
      descriptionEn: `Detected ${roundExpenseRecords.length} expense/procurement entries in exact multiples of 1,000, which warrants invoice-level verification for split or estimated billing.`,
      descriptionAr: `تم رصد ${roundExpenseRecords.length} مصروفات بمبالغ دائرية مضاعفة للألف، مما يستدعي مطابقة الفواتير الأصلية للتأكد من عدم وجود تجزئة فواتير أو تقديرات غير موثقة.`,
      evidence: roundExpenseRecords
        .slice(0, 4)
        .map((r) => `${r.metricLabel}: ${r.numericValue} (${r.sourceLocation})`)
        .join('; '),
      sourceDocumentId: sample.sourceDocumentId,
      sourceDocumentName: sample.sourceDocumentName,
      sourceLocation: sample.sourceLocation,
      status: 'open',
    });
  }

  // 5. Statistical >2σ outliers from spreadsheet parser summaries
  for (const docItem of params.sheets || []) {
    for (const sheet of docItem.sheets) {
      for (const col of sheet.numericSummaries) {
        if (col.anomalies.length > 0) {
          findings.push({
            category: 'statistical_outlier',
            severity: 'medium',
            titleEn: `Statistical Outlier in "${col.column}" (${sheet.sheetName})`,
            titleAr: `قيمة شاذة إحصائياً في عمود "${col.column}" (${sheet.sheetName})`,
            descriptionEn: `Values [${col.anomalies.join(', ')}] exceed 2 standard deviations from the column mean (${col.mean.toFixed(2)}).`,
            descriptionAr: `القيم [${col.anomalies.join(', ')}] تتجاوز ضعف الانحراف المعياري عن المتوسط (${col.mean.toFixed(2)}).`,
            evidence: `Column "${col.column}": mean=${col.mean}, min=${col.min}, max=${col.max}, outliers=[${col.anomalies.join(', ')}]`,
            sourceDocumentId: docItem.docId,
            sourceDocumentName: docItem.fileName,
            sourceLocation: `Sheet "${sheet.sheetName}"`,
            status: 'open',
          });
        }
      }
    }
  }

  return findings.slice(0, 20);
}

export type GrowthProposalDraft = Omit<
  GrowthProposal,
  'id' | 'companyId' | 'createdBy' | 'createdAt' | 'updatedAt'
>;

export function extractFocusSpotlight(focusData?: string): {
  cleaned: string;
  lines: string[];
  tokens: string[];
  numbers: number[];
} {
  const cleaned = (focusData || '').trim().slice(0, 8000);
  if (!cleaned) {
    return { cleaned: '', lines: [], tokens: [], numbers: [] };
  }
  const lines = cleaned
    .split(/\r?\n+/)
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, 12);
  const tokens = Array.from(new Set(tokenizeForSearch(cleaned))).slice(0, 20);
  const numMatches = cleaned.match(/-?\d[\d,]*(?:\.\d+)?/g) || [];
  const numbers = numMatches
    .map((m) => Number(m.replace(/,/g, '')))
    .filter((n) => Number.isFinite(n));
  return { cleaned, lines, tokens, numbers };
}

const VALID_DATA_DOMAIN_SET = new Set<WorkspaceDataDomain>([
  'finance',
  'sales',
  'hr',
  'operations',
  'procurement',
  'marketing',
  'strategy',
]);

const VALID_GROWTH_DOMAIN_SET = new Set<GrowthAdvisorDomain>([
  'finance',
  'sales',
  'marketing',
  'products',
  'operations',
  'hr',
  'procurement',
  'strategy',
]);

const VALID_FORENSIC_CATEGORIES = new Set<ForensicFinding['category']>([
  'duplicate_entry',
  'expense_spike',
  'statistical_outlier',
  'round_number_pattern',
  'margin_compression',
  'vendor_variance',
]);

const VALID_FORENSIC_SEVERITIES = new Set<ForensicFinding['severity']>(['high', 'medium', 'low']);

function cleanStr(val: unknown, maxLen: number, fallback: string): string {
  const s = typeof val === 'string' ? val.trim() : '';
  return (s || fallback).slice(0, maxLen);
}

export function sanitizeStructuredRecordDraft(
  draft: Partial<ExtractedRecordDraft>,
  fallbackDomain: WorkspaceDataDomain = 'finance',
  fallbackPeriod = '2026-01',
  fallbackSourceLocation = 'Document'
): ExtractedRecordDraft {
  const safeDomain =
    draft.domain && VALID_DATA_DOMAIN_SET.has(draft.domain)
      ? draft.domain
      : VALID_DATA_DOMAIN_SET.has(fallbackDomain)
      ? fallbackDomain
      : 'finance';
  const num =
    typeof draft.numericValue === 'number' && Number.isFinite(draft.numericValue)
      ? draft.numericValue
      : Number(draft.numericValue) || 0;

  return {
    domain: safeDomain,
    periodKey: cleanStr(draft.periodKey, 32, cleanStr(fallbackPeriod, 32, '2026-01')),
    metricKey: cleanStr(draft.metricKey, 64, 'kpi_metric'),
    metricLabel: cleanStr(draft.metricLabel, 120, 'Extracted Metric'),
    category: cleanStr(draft.category, 120, safeDomain),
    numericValue: Number.isFinite(num) ? num : 0,
    unit: cleanStr(draft.unit, 32, 'value'),
    sourceLocation: cleanStr(draft.sourceLocation, 160, cleanStr(fallbackSourceLocation, 160, 'Document')),
  };
}

export function sanitizeKnowledgeChunkDraft(
  draft: Partial<ChunkDraft>,
  fallbackLocation = 'Document'
): ChunkDraft {
  const idx =
    typeof draft.chunkIndex === 'number' && Number.isFinite(draft.chunkIndex)
      ? Math.max(0, Math.min(500, Math.round(draft.chunkIndex)))
      : 0;
  const keywords = Array.isArray(draft.keywords)
    ? draft.keywords
        .map((k) => (typeof k === 'string' ? k.trim().slice(0, 48) : ''))
        .filter(Boolean)
        .slice(0, 30)
    : [];

  return {
    chunkIndex: idx,
    locationLabel: cleanStr(draft.locationLabel, 120, cleanStr(fallbackLocation, 120, 'Document')),
    content: cleanStr(draft.content, 2900, 'Document excerpt'),
    keywords,
  };
}

export function sanitizeForensicFindingDraft(
  draft: Partial<ForensicFindingDraft>,
  fallbackDocId = 'workspace_audit',
  fallbackDocName = 'Company Workspace'
): ForensicFindingDraft {
  const category =
    draft.category && VALID_FORENSIC_CATEGORIES.has(draft.category)
      ? draft.category
      : 'vendor_variance';
  const severity =
    draft.severity && VALID_FORENSIC_SEVERITIES.has(draft.severity) ? draft.severity : 'medium';

  return {
    category,
    severity,
    titleEn: cleanStr(draft.titleEn, 200, 'Financial Audit Finding'),
    titleAr: cleanStr(draft.titleAr, 200, 'ملاحظة تدقيق مالي'),
    descriptionEn: cleanStr(draft.descriptionEn, 2000, 'Anomaly flagged for financial review.'),
    descriptionAr: cleanStr(draft.descriptionAr, 2000, 'تم رصد مؤشر مالي يتطلب المراجعة والتدقيق.'),
    evidence: cleanStr(draft.evidence, 2000, 'Refer to attached workspace records and documents.'),
    sourceDocumentId: cleanStr(draft.sourceDocumentId, 128, cleanStr(fallbackDocId, 128, 'workspace_audit')),
    sourceDocumentName: cleanStr(draft.sourceDocumentName, 255, cleanStr(fallbackDocName, 255, 'Company Workspace')),
    sourceLocation: cleanStr(draft.sourceLocation, 160, 'Workspace Analysis'),
    status: 'open',
  };
}

export function sanitizeGrowthProposalDraft(
  draft: Partial<GrowthProposalDraft>,
  fallbackDocIds: string[] = []
): GrowthProposalDraft {
  const domain =
    draft.domain && VALID_GROWTH_DOMAIN_SET.has(draft.domain) ? draft.domain : 'strategy';
  const rawSteps = Array.isArray(draft.executionPlan) ? draft.executionPlan : [];
  const steps = rawSteps
    .map((s) => (typeof s === 'string' ? s.trim().slice(0, 400) : ''))
    .filter(Boolean)
    .slice(0, 20);
  const executionPlan =
    steps.length > 0 ? steps : ['Review baseline metrics and submit execution budget for management approval.'];

  const rawDocIds = Array.isArray(draft.sourceDocumentIds) ? draft.sourceDocumentIds : fallbackDocIds;
  const sourceDocumentIds = rawDocIds
    .map((id) => (typeof id === 'string' ? id.trim().slice(0, 128) : ''))
    .filter(Boolean)
    .slice(0, 20);

  return {
    domain,
    title: cleanStr(draft.title, 200, 'Strategic Improvement Proposal'),
    detectedProblem: cleanStr(draft.detectedProblem, 3000, 'Performance optimization opportunity identified.'),
    evidenceAndNumbers: cleanStr(draft.evidenceAndNumbers, 5000, 'Derived from workspace records and focus data.'),
    proposedSolution: cleanStr(draft.proposedSolution, 3000, 'Implement structured governance and optimization workflow.'),
    expectedCost: cleanStr(draft.expectedCost, 1000, 'Internal operational allocation pending management review.'),
    expectedReturn: cleanStr(draft.expectedReturn, 1000, 'Measurable operating efficiency and margin improvement.'),
    executionPlan,
    successMetrics: cleanStr(draft.successMetrics, 1500, 'Quarterly KPI attainment and margin stability.'),
    requiresManagementApproval: true,
    status: 'pending_approval',
    sourceDocumentIds,
  };
}

export function dedupeForensicFindings(findings: ForensicFindingDraft[]): ForensicFindingDraft[] {
  const seen = new Set<string>();
  const out: ForensicFindingDraft[] = [];
  for (const f of findings) {
    const key = [
      f.category,
      normalizeTextToken(f.titleEn).slice(0, 80),
      normalizeTextToken(f.sourceDocumentName).slice(0, 80),
      normalizeTextToken(f.sourceLocation).slice(0, 80),
    ].join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(f);
    if (out.length >= 20) break;
  }
  return out;
}

