import type { ActiveSpecialistId, SpecialistId } from './types.ts';

export interface SpecialistDefinition {
  id: SpecialistId;
  active: boolean;
  nameEn: string;
  nameAr: string;
  departmentEn: string;
  departmentAr: string;
  descriptionEn: string;
  descriptionAr: string;
  color: string;
  iconName:
    | 'Landmark'
    | 'BarChart3'
    | 'Users'
    | 'Megaphone'
    | 'TrendingUp'
    | 'Settings2'
    | 'PackageCheck'
    | 'HeartHandshake'
    | 'ShieldAlert'
    | 'Compass';
  capabilitiesEn: string[];
  capabilitiesAr: string[];
  examplePromptsEn: string[];
  examplePromptsAr: string[];
  systemInstruction: string;
}

const GROUNDING_CORE = `
CRITICAL ENTERPRISE GROUNDING RULES:
1. Distinguish clearly between:
   - **Document Evidence**: Facts, tables, and numbers found directly in attached company documents. Always cite the exact source file and location, e.g. [Source: filename.pdf, Page 3] or [Source: ledger.xlsx, Sheet "Q3"].
   - **General Domain Knowledge**: Industry benchmarks, formulas, or analytical frameworks you supply.
2. Never invent, extrapolate, or fabricate financial figures, KPIs, dates, or citations.
3. Explicitly identify missing data, incomplete periods, or unverified assumptions before giving conclusions.
4. Clearly separate actual reported figures from estimates or scenario projections.
5. Respond in the same language the user wrote in (English or Arabic) unless they explicitly request another language.
6. Format structured comparisons with clean Markdown tables and explicit units/currencies.
`;

export const SPECIALISTS: SpecialistDefinition[] = [
  {
    id: 'finance',
    active: true,
    nameEn: 'Finance Specialist',
    nameAr: 'أخصائي المالية',
    departmentEn: 'Corporate Finance & FP&A',
    departmentAr: 'المالية المؤسسية والتخطيط',
    descriptionEn:
      'Analyzes financial statements, cash flow, margins, expense structures, financial ratios, and budget variances with verifiable calculations.',
    descriptionAr:
      'يحلل القوائم المالية والتدفقات النقدية والهوامش وهيكل المصروفات والنسب المالية وانحرافات الميزانية بحسابات موثقة.',
    color: '#1D4ED8',
    iconName: 'Landmark',
    capabilitiesEn: [
      'Financial statement analysis (Income, Balance Sheet, Cash Flow)',
      'Revenue & expense driver breakdown',
      'Profit & loss margin diagnostics',
      'Liquidity, solvency & profitability ratios',
      'Budget vs. actual variance analysis',
      'Structured financial report generation',
    ],
    capabilitiesAr: [
      'تحليل القوائم المالية (الدخل، المركز المالي، التدفق النقدي)',
      'تحليل محركات الإيرادات والمصروفات',
      'تشخيص هوامش الربح والخسارة',
      'حساب نسب السيولة والملاءة والربحية',
      'مقارنة الميزانية التقديرية بالأداء الفعلي',
      'إعداد التقارير المالية المهيكلة',
    ],
    examplePromptsEn: [
      'Calculate gross margin, operating margin, and net margin from the attached income statement and explain each formula.',
      'Compare Q1 vs Q2 operating expenses and highlight any line items with >10% variance or missing values.',
      'Evaluate our cash flow sustainability and identify missing balance sheet items needed for a full liquidity review.',
    ],
    examplePromptsAr: [
      'احسب هامش الربح الإجمالي والتشغيلي والصافي من قائمة الدخل المرفقة مع شرح كل معادلة.',
      'قارن المصروفات التشغيلية بين الربع الأول والثاني وحدد البنود التي تجاوز انحرافها 10% أو البيانات الناقصة.',
      'قيّم استدامة التدفق النقدي وحدد البنود المفقودة اللازمة لتقييم السيولة بدقة.',
    ],
    systemInstruction: `You are the EGAI Enterprise Finance Specialist (Corporate Finance & FP&A).
Your responsibilities:
- Perform rigorous financial statement, revenue, expense, P&L, cash flow, ratio, and budget-vs-actual analyses.
- Show step-by-step formulas and intermediate numbers for every calculation you perform.
- Identify missing line items (e.g., missing depreciation, tax rate, debt schedule, working capital) rather than guessing them.
- Clearly distinguish actual historical figures from estimates/forecasts.
${GROUNDING_CORE}`,
  },
  {
    id: 'bi',
    active: true,
    nameEn: 'Business Intelligence Specialist',
    nameAr: 'أخصائي ذكاء الأعمال',
    departmentEn: 'Analytics & KPI Intelligence',
    departmentAr: 'التحليلات ومؤشرات الأداء',
    descriptionEn:
      'Transforms Excel and CSV datasets into KPI diagnostics, trend summaries, anomaly detection, comparative matrices, and executive briefs.',
    descriptionAr:
      'يحوّل ملفات Excel وCSV إلى تشخيص لمؤشرات الأداء وتحليل الاتجاهات وكشف الشذوذ ومقارنات الأداء والملخصات التنفيذية.',
    color: '#38BDF8',
    iconName: 'BarChart3',
    capabilitiesEn: [
      'Excel (XLSX) and CSV multi-sheet dataset analysis',
      'KPI definition, tracking & variance attribution',
      'Period-over-period trend & seasonality analysis',
      'Statistical anomaly & outlier identification',
      'Cross-segment & regional performance comparisons',
      'Executive summary & board-ready data briefs',
    ],
    capabilitiesAr: [
      'تحليل جداول Excel وCSV متعددة الأوراق',
      'تحليل مؤشرات الأداء الرئيسية وتفسير التغيرات',
      'تحليل الاتجاهات الزمنية والموسمية',
      'رصد القيم الشاذة والانحرافات الإحصائية',
      'مقارنة الأداء عبر الفروع والقطاعات',
      'إعداد الملخصات التنفيذية لصنّاع القرار',
    ],
    examplePromptsEn: [
      'Summarize the key KPIs, column distributions, and notable outliers in the uploaded CSV/Excel dataset.',
      'Compare performance across regions or product categories and present a Markdown summary table.',
      'Draft an executive performance summary highlighting top trends, risks, and data quality gaps.',
    ],
    examplePromptsAr: [
      'لخّص مؤشرات الأداء الرئيسية وتوزيع الأعمدة والقيم الشاذة في ملف البيانات المرفق.',
      'قارن الأداء عبر المناطق أو الفئات وقدّم جدولاً تحليلياً منظماً.',
      'أعد ملخصاً تنفيذياً للأداء يوضح أبرز الاتجاهات والمخاطر والفجوات في جودة البيانات.',
    ],
    systemInstruction: `You are the EGAI Enterprise Business Intelligence Specialist (Analytics & KPI Intelligence).
Your responsibilities:
- Analyze structured spreadsheets (XLSX, CSV) and operational reports to uncover KPI movements, trends, comparisons, and anomalies.
- Use verified computed statistics provided in the context (sums, means, min/max, counts) and never hallucinate row values.
- Suggest concrete visualizations (chart type, X-axis, Y-axis, grouping) when presenting analytical findings.
- Flag data quality issues (nulls, inconsistent units, duplicate keys, truncated date ranges).
${GROUNDING_CORE}`,
  },
  {
    id: 'hr',
    active: true,
    nameEn: 'Human Resources Specialist',
    nameAr: 'أخصائي الموارد البشرية',
    departmentEn: 'People Operations & Talent',
    departmentAr: 'إدارة الأفراد والمواهب',
    descriptionEn:
      'Workforce planning, attrition diagnostics, compensation benchmarking, and organizational policy intelligence.',
    descriptionAr:
      'تخطيط القوى العاملة وتحليل الدوران الوظيفي ومقارنة الرواتب وسياسات الموارد البشرية.',
    color: '#8B5CF6',
    iconName: 'Users',
    capabilitiesEn: [
      'Headcount, hiring funnel & attrition rate diagnostics',
      'Compensation band & payroll structure benchmarking',
      'Departmental span-of-control & org capacity planning',
      'HR policy, leave & handbook compliance Q&A',
      'Employee engagement & survey driver synthesis',
    ],
    capabilitiesAr: [
      'تحليل أعداد الموظفين ومعدلات الاستقطاب والدوران الوظيفي',
      'مقارنة هياكل الأجور والمزايا والتكاليف البشرية',
      'تخطيط السعة الوظيفية والهيكل التنظيمي للإدارات',
      'الإجابة عن سياسات الموارد البشرية واللوائح الداخلية',
      'تحليل نتائج استبيانات رضا ومشاركة الموظفين',
    ],
    examplePromptsEn: [
      'Analyze quarterly attrition and hiring trends by department from the uploaded HR workbook.',
      'Review our compensation distribution across job grades and flag outliers or missing salary bands.',
      'Summarize leave, overtime, and onboarding obligations from the attached employee handbook.',
    ],
    examplePromptsAr: [
      'حلل اتجاهات الدوران الوظيفي والتوظيف ربع السنوي حسب الإدارة من ملف الموارد البشرية المرفق.',
      'راجع توزيع الرواتب عبر الدرجات الوظيفية وحدد الفجوات أو القيم الشاذة.',
      'لخّص سياسات الإجازات والعمل الإضافي والتعيين من دليل الموظفين المرفق.',
    ],
    systemInstruction: `You are the EGAI Enterprise Human Resources Specialist (People Operations & Talent).
Your responsibilities:
- Analyze workforce metrics (headcount, attrition, retention, tenure, hiring funnel, absenteeism, compensation bands) and HR policy documents.
- Explain HR metric formulas (e.g., annualized attrition rate, cost-per-hire, compa-ratio) clearly using verified document figures.
- Highlight missing demographic segments, incomplete date ranges, or unverified policy clauses.
- Maintain respectful, objective, compliant HR advisory standards without inventing employee data.
${GROUNDING_CORE}`,
  },
  {
    id: 'marketing',
    active: true,
    nameEn: 'Marketing Specialist',
    nameAr: 'أخصائي التسويق',
    departmentEn: 'Growth & Brand Performance',
    departmentAr: 'النمو وأداء العلامة التجارية',
    descriptionEn:
      'Campaign ROI attribution, funnel conversion diagnostics, channel efficiency, and audience segmentation.',
    descriptionAr:
      'قياس عائد الحملات التسويقية وتحليل قمع التحويل وكفاءة القنوات وتقسيم الجمهور.',
    color: '#EC4899',
    iconName: 'Megaphone',
    capabilitiesEn: [
      'Campaign ROI, ROAS & CAC/LTV diagnostics',
      'Multi-channel attribution & spend efficiency comparisons',
      'Lead funnel conversion & drop-off analysis',
      'Audience cohort & messaging positioning audits',
      'Budget reallocation recommendations grounded in channel metrics',
    ],
    capabilitiesAr: [
      'قياس العائد على الإنفاق التسويقي وتكلفة الاستحواذ CAC',
      'مقارنة كفاءة القنوات التسويقية وتوزيع الميزانية',
      'تحليل قمع التحويل ونقاط التسرب للعملاء المحتملين',
      'تقييم شرائح الجمهور والرسائل التسويقية',
      'توصيات إعادة توزيع الميزانية بناءً على الأداء الفعلي',
    ],
    examplePromptsEn: [
      'Compare CAC, conversion rate, and ROAS across paid channels in the attached campaign sheet.',
      'Identify where leads drop off most severely in our acquisition funnel and quantify the impact.',
      'Evaluate campaign spend efficiency and flag channels lacking attribution or revenue data.',
    ],
    examplePromptsAr: [
      'قارن تكلفة الاستحواذ ومعدل التحويل والعائد على الإنفاق عبر القنوات في ملف الحملات المرفق.',
      'حدد أكبر نقاط التسرب في قمع الاستحواذ وحجم الأثر الفعلي.',
      'قيّم كفاءة الإنفاق التسويقي وحدد القنوات التي تفتقر لبيانات الإسناد أو الإيراد.',
    ],
    systemInstruction: `You are the EGAI Enterprise Marketing Specialist (Growth & Brand Performance).
Your responsibilities:
- Evaluate marketing spend, CAC, ROAS, CTR, conversion rates, pipeline contribution, and campaign briefs.
- Separate tracked attribution metrics from modeled estimates and identify missing tracking parameters.
- Present channel comparisons in clean Markdown tables with exact unit economics.
${GROUNDING_CORE}`,
  },
  {
    id: 'sales',
    active: true,
    nameEn: 'Sales Specialist',
    nameAr: 'أخصائي المبيعات',
    departmentEn: 'Revenue Operations',
    departmentAr: 'عمليات الإيرادات والمبيعات',
    descriptionEn:
      'Pipeline velocity, win-rate diagnostics, quota attainment forecasting, and account expansion analysis.',
    descriptionAr:
      'تحليل سرعة خط المبيعات ومعدلات الإغلاق وتوقعات تحقيق الأهداف وتوسع الحسابات.',
    color: '#10B981',
    iconName: 'TrendingUp',
    capabilitiesEn: [
      'Pipeline stage conversion & cycle-time analysis',
      'Rep & territory quota attainment tracking',
      'Win/loss driver & deal-slip diagnostics',
      'Weighted pipeline & revenue coverage ratios',
      'Account expansion & cross-sell prioritization',
    ],
    capabilitiesAr: [
      'تحليل التحويل بين مراحل البيع ومدة إغلاق الصفقات',
      'متابعة تحقيق حصص المبيعات حسب الفريق والمنطقة',
      'تشخيص أسباب الفوز والخسارة وتأخر الصفقات',
      'حساب تغطية خط المبيعات المرجّح مقابل الأهداف',
      'تحديد فرص التوسع والبيع الإضافي للحسابات',
    ],
    examplePromptsEn: [
      'Calculate stage-by-stage conversion rates and pipeline coverage from our CRM export.',
      'Identify stalled deals, rep attainment variance, and missing close-date records in Q3.',
      'Summarize top win/loss reasons across enterprise vs. mid-market segments.',
    ],
    examplePromptsAr: [
      'احسب نسب التحويل بين مراحل البيع ونسبة تغطية خط المبيعات من ملف CRM المرفق.',
      'حدد الصفقات المتعثرة وتباين تحقيق الأهداف والبيانات الناقصة في الربع الثالث.',
      'لخّص أبرز أسباب الفوز والخسارة بين قطاع الشركات الكبرى والمتوسطة.',
    ],
    systemInstruction: `You are the EGAI Enterprise Sales Specialist (Revenue Operations).
Your responsibilities:
- Analyze CRM pipeline exports, win rates, average deal size, sales cycle length, quota attainment, and forecast coverage.
- Clearly distinguish committed closed-won actuals from weighted or unweighted pipeline projections.
- Surface missing stage timestamps, unallocated reps, or skewed deal outliers before forecasting.
${GROUNDING_CORE}`,
  },
  {
    id: 'operations',
    active: true,
    nameEn: 'Operations Specialist',
    nameAr: 'أخصائي العمليات',
    departmentEn: 'Supply & Process Excellence',
    departmentAr: 'الكفاءة التشغيلية وسلاسل الإمداد',
    descriptionEn:
      'Throughput efficiency, SLA compliance monitoring, capacity planning, and operational bottleneck discovery.',
    descriptionAr:
      'كفاءة الإنتاج ومراقبة اتفاقيات مستوى الخدمة وتخطيط السعة واكتشاف الاختناقات التشغيلية.',
    color: '#F59E0B',
    iconName: 'Settings2',
    capabilitiesEn: [
      'Process throughput, cycle-time & SLA compliance analysis',
      'Capacity, utilization & shift workload modeling',
      'Inventory turnover & fulfillment delay diagnostics',
      'SOP adherence & incident root-cause reviews',
      'Operational bottleneck & cost-per-unit optimization',
    ],
    capabilitiesAr: [
      'تحليل الكفاءة التشغيلية وزمن الدورة ومستويات الخدمة SLA',
      'نمذجة السعة التشغيلية ونسب استغلال الموارد',
      'تشخيص دوران المخزون وتأخيرات التوريد والتنفيذ',
      'مراجعة إجراءات التشغيل القياسية وتحليل أسباب الأعطال',
      'اكتشاف الاختناقات التشغيلية وتحسين تكلفة الوحدة',
    ],
    examplePromptsEn: [
      'Summarize SLA compliance rates and identify the top operational bottlenecks in the attached log.',
      'Evaluate facility utilization and unit throughput variance across shifts or warehouses.',
      'Review our standard operating procedure document and highlight missing escalation thresholds.',
    ],
    examplePromptsAr: [
      'لخّص نسب الالتزام باتفاقيات مستوى الخدمة وحدد أبرز الاختناقات التشغيلية في السجل المرفق.',
      'قيّم نسب استغلال الطاقة الإنتاجية وتباين الإنتاجية عبر المستودعات أو الورديات.',
      'راجع مستند إجراءات التشغيل القياسية وحدد أي فجوات في حدود التصعيد.',
    ],
    systemInstruction: `You are the EGAI Enterprise Operations Specialist (Supply & Process Excellence).
Your responsibilities:
- Diagnose operational throughput, SLA compliance, lead times, capacity utilization, defect rates, and logistics bottlenecks.
- Ground calculations in verified dataset counts, timestamps, and averages, highlighting incomplete operational logs.
- Propose practical process improvements tied directly to observed variance.
${GROUNDING_CORE}`,
  },
  {
    id: 'procurement',
    active: true,
    nameEn: 'Procurement Specialist',
    nameAr: 'أخصائي المشتريات',
    departmentEn: 'Vendor & Spend Intelligence',
    departmentAr: 'إدارة الموردين والإنفاق',
    descriptionEn:
      'Vendor spend consolidation, contract term comparison, unit cost variance, and supplier risk tracking.',
    descriptionAr:
      'توحيد إنفاق الموردين ومقارنة بنود العقود وتحليل تغيرات تكلفة الوحدة ومخاطر التوريد.',
    color: '#06B6D4',
    iconName: 'PackageCheck',
    capabilitiesEn: [
      'Vendor spend concentration & tail-spend consolidation',
      'Contract clause, payment terms & SLA comparison',
      'Unit price variance & inflation tracking across suppliers',
      'Purchase order compliance & maverick spend detection',
      'Supplier concentration & lead-time risk evaluation',
    ],
    capabilitiesAr: [
      'تحليل تركز الإنفاق على الموردين وتوحيد المشتريات',
      'مقارنة بنود العقود وشروط السداد ومستويات الخدمة',
      'تتبع تغيرات سعر الوحدة وفروقات التكلفة بين الموردين',
      'رصد أوامر الشراء غير المطابقة والإنفاق خارج العقود',
      'تقييم مخاطر الاعتماد على مورد واحد ومهل التوريد',
    ],
    examplePromptsEn: [
      'Compare unit pricing, payment terms, and spend concentration across the vendors in the attached sheet.',
      'Review these two supplier proposals and build a side-by-side commercial & SLA comparison matrix.',
      'Identify cost-saving consolidation opportunities and missing contract renewal dates.',
    ],
    examplePromptsAr: [
      'قارن أسعار الوحدة وشروط السداد وتركز الإنفاق عبر الموردين في الملف المرفق.',
      'راجع عرضي الموردين المرفقين وأعد مصفوفة مقارنة تجارية وفنية دقيقة.',
      'حدد فرص التوفير وتوحيد الموردين وأي تواريخ تجديد عقود مفقودة.',
    ],
    systemInstruction: `You are the EGAI Enterprise Procurement Specialist (Vendor & Spend Intelligence).
Your responsibilities:
- Analyze vendor spend ledgers, PO histories, unit pricing, contract terms, rebates, and supplier performance.
- Flag single-source dependency risks, off-contract purchases, and missing commercial terms (incoterms, payment days, SLAs).
- Compare competing vendor bids objectively in Markdown tables without fabricating quote items.
${GROUNDING_CORE}`,
  },
  {
    id: 'customer_success',
    active: true,
    nameEn: 'Customer Success Specialist',
    nameAr: 'أخصائي نجاح العملاء',
    departmentEn: 'Retention & Account Health',
    departmentAr: 'الاحتفاظ بالعملاء وصحة الحسابات',
    descriptionEn:
      'Renewal risk analysis, NPS/CSAT driver synthesis, support ticket clustering, and net retention modeling.',
    descriptionAr:
      'تحليل مخاطر التجديد واستخلاص مؤشرات رضا العملاء وتصنيف التذاكر ونمذجة صافي الاحتفاظ.',
    color: '#14B8A6',
    iconName: 'HeartHandshake',
    capabilitiesEn: [
      'Gross & Net Revenue Retention (GRR/NRR) diagnostics',
      'Renewal risk scoring & churn driver identification',
      'Support ticket volume & root-cause clustering',
      'NPS / CSAT qualitative & quantitative synthesis',
      'Account health segmentation & adoption playbooks',
    ],
    capabilitiesAr: [
      'تحليل صافي وإجمالي الاحتفاظ بالإيرادات GRR و NRR',
      'رصد مخاطر التجديد وتحديد أسباب تسرب العملاء',
      'تصنيف تذاكر الدعم الفني وتحليل الأسباب المتكررة',
      'استخلاص رؤى مؤشرات رضا العملاء NPS و CSAT',
      'تقسيم صحة الحسابات وخطط رفع التبني والاحتفاظ',
    ],
    examplePromptsEn: [
      'Calculate churn, expansion, and Net Revenue Retention from the attached account cohort sheet.',
      'Cluster recurring themes in customer support tickets and rank them by affected ARR.',
      'Flag upcoming renewals showing low product adoption or missing health-score inputs.',
    ],
    examplePromptsAr: [
      'احسب معدل التسرب والتوسع وصافي الاحتفاظ بالإيرادات NRR من ملف الحسابات المرفق.',
      'صنّف الشكاوى المتكررة في تذاكر الدعم ورتّبها حسب قيمة العقود المتأثرة.',
      'حدد الحسابات القريبة من التجديد ذات التبني المنخفض أو البيانات الصحية الناقصة.',
    ],
    systemInstruction: `You are the EGAI Enterprise Customer Success Specialist (Retention & Account Health).
Your responsibilities:
- Evaluate GRR, NRR, logo churn, renewal pipelines, support ticket logs, onboarding milestones, and NPS/CSAT feedback.
- Link churn or ticket trends to verified segments and cite exact document evidence.
- Highlight missing customer health signals before recommending intervention playbooks.
${GROUNDING_CORE}`,
  },
  {
    id: 'risk_compliance',
    active: true,
    nameEn: 'Risk & Compliance Specialist',
    nameAr: 'أخصائي المخاطر والامتثال',
    departmentEn: 'Governance & Audit Controls',
    departmentAr: 'الحوكمة والرقابة والامتثال',
    descriptionEn:
      'Policy gap assessments, audit readiness checklists, regulatory document review, and control mapping.',
    descriptionAr:
      'تقييم فجوات السياسات وقوائم الجاهزية للتدقيق ومراجعة الوثائق التنظيمية وربط الضوابط.',
    color: '#EF4444',
    iconName: 'ShieldAlert',
    capabilitiesEn: [
      'Policy & regulatory gap assessments',
      'Audit evidence verification & readiness checklists',
      'Enterprise risk register scoring (likelihood × impact)',
      'Contractual liability & compliance clause review',
      'Control mapping & remediation action tracking',
    ],
    capabilitiesAr: [
      'تقييم فجوات السياسات والامتثال للوائح التنظيمية',
      'التحقق من أدلة التدقيق وإعداد قوائم الجاهزية',
      'تقييم سجل المخاطر المؤسسية حسب الاحتمالية والأثر',
      'مراجعة بنود المسؤولية والامتثال في العقود',
      'ربط الضوابط الرقابية ومتابعة خطط المعالجة',
    ],
    examplePromptsEn: [
      'Perform a gap assessment on the attached policy document and list missing control ownership or review cycles.',
      'Review our enterprise risk register and rank top critical risks by likelihood and impact.',
      'Generate an audit readiness checklist with evidence requirements based on the uploaded compliance report.',
    ],
    examplePromptsAr: [
      'أجرِ تقييماً لفجوات السياسة المرفقة وحدد الضوابط المفقودة أو غير المحددة المسؤولية.',
      'راجع سجل المخاطر المؤسسية ورتّب أعلى المخاطر الحرجة حسب الاحتمالية والأثر.',
      'أنشئ قائمة جاهزية للتدقيق مع متطلبات الأدلة استناداً إلى تقرير الامتثال المرفق.',
    ],
    systemInstruction: `You are the EGAI Enterprise Risk & Compliance Specialist (Governance & Audit Controls).
Your responsibilities:
- Analyze internal policies, audit findings, risk registers, incident logs, and vendor compliance attestations.
- Identify missing controls, ambiguous owners, unverified evidence, and high-severity compliance exposures.
- Distinguish clearly between documented control evidence and general governance best practices, and note that formal legal sign-off remains with qualified counsel.
${GROUNDING_CORE}`,
  },
  {
    id: 'strategy',
    active: true,
    nameEn: 'Strategy Specialist',
    nameAr: 'أخصائي الاستراتيجية',
    departmentEn: 'Corporate Strategy & Board Advisory',
    departmentAr: 'الاستراتيجية المؤسسية واستشارات الإدارة',
    descriptionEn:
      'Market expansion scenarios, strategic initiative prioritization, capital allocation trade-offs, and board memos.',
    descriptionAr:
      'سيناريوهات التوسع في الأسواق وترتيب المبادرات الاستراتيجية وتوزيع رأس المال ومذكرات مجلس الإدارة.',
    color: '#6366F1',
    iconName: 'Compass',
    capabilitiesEn: [
      'Strategic option & capital allocation trade-off matrices',
      'Market entry, pricing & expansion scenario framing',
      'Cross-functional KPI synthesis for leadership reviews',
      'Initiative prioritization (impact vs. feasibility & risk)',
      'Executive & quarterly board memo drafting',
    ],
    capabilitiesAr: [
      'مصفوفات المفاضلة بين الخيارات الاستراتيجية وتوزيع رأس المال',
      'تحليل سيناريوهات دخول الأسواق والتوسع والتسعير',
      'دمج مؤشرات الأداء عبر الإدارات لمراجعات القيادة',
      'ترتيب أولويات المبادرات حسب الأثر والمخاطر والتنفيذ',
      'صياغة مذكرات مجلس الإدارة والملخصات التنفيذية',
    ],
    examplePromptsEn: [
      'Synthesize the attached financial and operational documents into a structured Q4 board strategy memo.',
      'Build an objective trade-off matrix comparing the strategic initiatives outlined in the uploaded brief.',
      'Identify key strategic assumptions and missing market or financial data needed before capital allocation.',
    ],
    examplePromptsAr: [
      'ادمج المستندات المالية والتشغيلية المرفقة في مذكرة استراتيجية منظمة لمجلس الإدارة للربع الرابع.',
      'أعد مصفوفة مفاضلة موضوعية بين المبادرات الاستراتيجية الواردة في الوثيقة المرفقة.',
      'حدد الافتراضات الاستراتيجية الأساسية والبيانات المفقودة قبل اتخاذ قرار تخصيص رأس المال.',
    ],
    systemInstruction: `You are the EGAI Enterprise Strategy Specialist (Corporate Strategy & Board Advisory).
Your responsibilities:
- Synthesize financial, operational, market, and organizational documents into structured executive decision frameworks and board memos.
- Present clear trade-offs, measurable success criteria, dependencies, and risk mitigations.
- Explicitly separate factual baselines found in company documents from strategic assumptions requiring executive validation.
${GROUNDING_CORE}`,
  },
];

export function getSpecialist(id: string): SpecialistDefinition | undefined {
  return SPECIALISTS.find((s) => s.id === id);
}

export function isSpecialistActive(id: string): id is ActiveSpecialistId {
  const found = getSpecialist(id);
  return Boolean(found && found.active);
}

export function getActiveSpecialists(): SpecialistDefinition[] {
  return SPECIALISTS.filter((s) => s.active);
}

export function parseSpecialistId(raw: unknown): ActiveSpecialistId | null {
  if (typeof raw !== 'string') return null;
  const cleaned = raw.trim().toLowerCase();
  return isSpecialistActive(cleaned) ? cleaned : null;
}

export function resolveSpecialistFallback(query: string, focusData = ''): ActiveSpecialistId {
  const text = `${query} ${focusData}`
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه');

  if (/(risk|compliance|audit|policy|regulation|control|مخاطر|امتثال|تدقيق|رقاب|سياسه)/.test(text)) {
    return 'risk_compliance';
  }
  if (/(payroll|salary|employee|hr|attrition|hiring|headcount|موظف|راتب|رواتب|موارد بشريه|دوران وظيفي)/.test(text)) {
    return 'hr';
  }
  if (/(procurement|vendor|supplier|purchase|contract|po|مورد|مشتري|عقد|عقود)/.test(text)) {
    return 'procurement';
  }
  if (/(marketing|campaign|ad|roas|cac|ctr|funnel|تسويق|حمل|اعلان)/.test(text)) {
    return 'marketing';
  }
  if (/(sales|pipeline|crm|deal|win rate|quota|مبيع|صفق|عملاء محتمل|ايرادات البيع)/.test(text)) {
    return 'sales';
  }
  if (/(churn|retention|nrr|nps|csat|ticket|support|نجاح العملاء|تجديد|تذاكر|رضا العملاء)/.test(text)) {
    return 'customer_success';
  }
  if (/(operation|sla|throughput|warehouse|inventory|supply|defect|تشغيل|انتاج|مخزون|عمليات)/.test(text)) {
    return 'operations';
  }
  if (/(strategy|board|okr|expansion|roadmap|capital allocation|استراتيج|مجلس الاداره|توسع|اهداف)/.test(text)) {
    return 'strategy';
  }
  if (/(revenue|profit|expense|margin|cash flow|p&l|income|balance|invoice|cost|ربح|ارباح|مصروف|ايراد|ميزانيه|سيوله|هامش|فاتور)/.test(text)) {
    return 'finance';
  }
  return 'bi';
}

