import type { UserRole } from './types.ts';

export interface RolePermissions {
  canViewWorkspace: boolean;
  canWriteWorkspace: boolean;
  canUploadDocuments: boolean;
  canDeleteDocuments: boolean;
  canInvokeAI: boolean;
  canVerifyRecords: boolean;
  canRunForensics: boolean;
  canApproveGrowthPlans: boolean;
  canViewAuditLogs: boolean;
  canManageTeam: boolean;
  canManageCompany: boolean;
  canManageBillingLimits: boolean;
  canDeleteCompanyData: boolean;
}

const ROLE_MATRIX: Record<UserRole, RolePermissions> = {
  owner: {
    canViewWorkspace: true,
    canWriteWorkspace: true,
    canUploadDocuments: true,
    canDeleteDocuments: true,
    canInvokeAI: true,
    canVerifyRecords: true,
    canRunForensics: true,
    canApproveGrowthPlans: true,
    canViewAuditLogs: true,
    canManageTeam: true,
    canManageCompany: true,
    canManageBillingLimits: true,
    canDeleteCompanyData: true,
  },
  administrator: {
    canViewWorkspace: true,
    canWriteWorkspace: true,
    canUploadDocuments: true,
    canDeleteDocuments: true,
    canInvokeAI: true,
    canVerifyRecords: true,
    canRunForensics: true,
    canApproveGrowthPlans: true,
    canViewAuditLogs: true,
    canManageTeam: true,
    canManageCompany: true,
    canManageBillingLimits: true,
    canDeleteCompanyData: false,
  },
  analyst: {
    canViewWorkspace: true,
    canWriteWorkspace: true,
    canUploadDocuments: true,
    canDeleteDocuments: true,
    canInvokeAI: true,
    canVerifyRecords: true,
    canRunForensics: true,
    canApproveGrowthPlans: false,
    canViewAuditLogs: true,
    canManageTeam: false,
    canManageCompany: false,
    canManageBillingLimits: false,
    canDeleteCompanyData: false,
  },
  viewer: {
    canViewWorkspace: true,
    canWriteWorkspace: false,
    canUploadDocuments: false,
    canDeleteDocuments: false,
    canInvokeAI: false,
    canVerifyRecords: false,
    canRunForensics: false,
    canApproveGrowthPlans: false,
    canViewAuditLogs: false,
    canManageTeam: false,
    canManageCompany: false,
    canManageBillingLimits: false,
    canDeleteCompanyData: false,
  },
};

export function getPermissionsForRole(role: UserRole | undefined | null): RolePermissions {
  if (!role || !(role in ROLE_MATRIX)) {
    return ROLE_MATRIX.viewer;
  }
  return ROLE_MATRIX[role];
}

export function canAssignRole(actorRole: UserRole, targetRole: UserRole): boolean {
  if (targetRole === 'owner') return false;
  return actorRole === 'owner' || actorRole === 'administrator';
}

export function canRemoveMember(actorRole: UserRole, targetRole: UserRole, isSelf: boolean): boolean {
  if (targetRole === 'owner') return false;
  if (isSelf) return true;
  return actorRole === 'owner' || actorRole === 'administrator';
}
