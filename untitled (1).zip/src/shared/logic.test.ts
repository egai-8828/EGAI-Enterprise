import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SPECIALISTS,
  isSpecialistActive,
  getActiveSpecialists,
  parseSpecialistId,
  resolveSpecialistFallback,
} from './specialists';
import { PLANS, evaluateQuotaStatus } from './plans';
import { getPermissionsForRole, canAssignRole, canRemoveMember } from './rbac';
import { summarizeTabularRows, getCurrentMonthKey, formatBytes, sanitizeEnvSetting } from './financeUtils';
import {
  WORKSPACE_DATA_DOMAINS,
  GROWTH_ADVISOR_DOMAINS,
  chunkDocumentText,
  extractStructuredRecordsFromSheets,
  searchKnowledgeChunks,
  computePeriodAnalytics,
  runFinancialForensics,
  extractFocusSpotlight,
  sanitizeStructuredRecordDraft,
  sanitizeKnowledgeChunkDraft,
  sanitizeForensicFindingDraft,
  sanitizeGrowthProposalDraft,
  dedupeForensicFindings,
} from './intelligenceEngine';
import type { KnowledgeChunk, StructuredBusinessRecord } from './types';

test('specialist directory has all 10 departments active with full instructions', () => {
  assert.equal(SPECIALISTS.length, 10);
  const active = getActiveSpecialists();
  assert.equal(active.length, 10);
  assert.deepEqual(
    active.map((s) => s.id),
    [
      'finance',
      'bi',
      'hr',
      'marketing',
      'sales',
      'operations',
      'procurement',
      'customer_success',
      'risk_compliance',
      'strategy',
    ]
  );
  for (const spec of SPECIALISTS) {
    assert.equal(isSpecialistActive(spec.id), true);
    assert.ok(spec.systemInstruction.trim().length > 50, `${spec.id} missing systemInstruction`);
    assert.ok(spec.capabilitiesEn.length >= 3, `${spec.id} missing English capabilities`);
    assert.ok(spec.capabilitiesAr.length >= 3, `${spec.id} missing Arabic capabilities`);
    assert.ok(spec.examplePromptsEn.length >= 2, `${spec.id} missing English example prompts`);
    assert.ok(spec.examplePromptsAr.length >= 2, `${spec.id} missing Arabic example prompts`);
  }
  assert.equal(isSpecialistActive('unknown_dept'), false);
});

test('quota evaluation detects token and request boundaries accurately', () => {
  const ok = evaluateQuotaStatus(50000, 20, PLANS.starter.monthlyTokenLimit, PLANS.starter.monthlyRequestLimit);
  assert.equal(ok.exceeded, false);
  assert.equal(ok.reason, 'ok');
  assert.equal(ok.tokensRemaining, 200000);
  assert.equal(ok.tokenUsagePct, 20);

  const tokenExceeded = evaluateQuotaStatus(250000, 10, 250000, 250);
  assert.equal(tokenExceeded.exceeded, true);
  assert.equal(tokenExceeded.reason, 'token_limit_exceeded');

  const reqExceeded = evaluateQuotaStatus(1000, 250, 250000, 250);
  assert.equal(reqExceeded.exceeded, true);
  assert.equal(reqExceeded.reason, 'request_limit_exceeded');
});

test('RBAC matrix restricts viewer writes, protects owner role, and enforces management approvals', () => {
  const viewer = getPermissionsForRole('viewer');
  assert.equal(viewer.canViewWorkspace, true);
  assert.equal(viewer.canWriteWorkspace, false);
  assert.equal(viewer.canInvokeAI, false);
  assert.equal(viewer.canManageTeam, false);
  assert.equal(viewer.canApproveGrowthPlans, false);
  assert.equal(viewer.canDeleteCompanyData, false);

  const analyst = getPermissionsForRole('analyst');
  assert.equal(analyst.canUploadDocuments, true);
  assert.equal(analyst.canInvokeAI, true);
  assert.equal(analyst.canVerifyRecords, true);
  assert.equal(analyst.canRunForensics, true);
  assert.equal(analyst.canApproveGrowthPlans, false);
  assert.equal(analyst.canManageTeam, false);

  const admin = getPermissionsForRole('administrator');
  assert.equal(admin.canApproveGrowthPlans, true);
  assert.equal(admin.canDeleteCompanyData, false);

  const owner = getPermissionsForRole('owner');
  assert.equal(owner.canApproveGrowthPlans, true);
  assert.equal(owner.canDeleteCompanyData, true);

  assert.equal(canAssignRole('administrator', 'analyst'), true);
  assert.equal(canAssignRole('administrator', 'owner'), false);
  assert.equal(canAssignRole('analyst', 'viewer'), false);

  assert.equal(canRemoveMember('administrator', 'owner', false), false);
  assert.equal(canRemoveMember('administrator', 'analyst', false), true);
  assert.equal(canRemoveMember('analyst', 'analyst', true), true);
  assert.equal(canRemoveMember('analyst', 'viewer', false), false);
});

test('tabular summarization calculates exact sums, means, and anomalies', () => {
  const rows = [
    { Month: 'Jan', Revenue: '$1,000', Margin: 20 },
    { Month: 'Feb', Revenue: '$1,100', Margin: 22 },
    { Month: 'Mar', Revenue: '$1,050', Margin: 21 },
    { Month: 'Apr', Revenue: '$1,080', Margin: 20 },
    { Month: 'May', Revenue: '$1,020', Margin: 21 },
    { Month: 'Jun', Revenue: '$9,900', Margin: 45 },
  ];
  const summary = summarizeTabularRows('Q1-Q2', rows);
  assert.equal(summary.rowCount, 6);
  assert.deepEqual(summary.headers, ['Month', 'Revenue', 'Margin']);

  const rev = summary.numericSummaries.find((s) => s.column === 'Revenue');
  assert.ok(rev);
  assert.equal(rev.count, 6);
  assert.equal(rev.sum, 15150);
  assert.equal(rev.min, 1000);
  assert.equal(rev.max, 9900);
  assert.deepEqual(rev.anomalies, [9900]);
});

test('month key and byte formatter return clean deterministic strings', () => {
  assert.equal(getCurrentMonthKey(new Date('2026-11-14T12:00:00Z')), '2026-11');
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(2048), '2.0 KB');
});

test('Company Intelligence Memory chunks, extracts records, searches RAG, and computes period analytics', () => {
  assert.equal(WORKSPACE_DATA_DOMAINS.length, 7);
  assert.equal(GROWTH_ADVISOR_DOMAINS.length, 8);

  const chunks = chunkDocumentText({
    fileName: 'Q1_Q2_PL.pdf',
    fullText:
      '[Page 1]\nQ1 Revenue reached 100000 while Operating Expenses were 60000.\n\n[Page 2]\nQ2 Revenue grew to 108000 (+8%) while Expenses surged to 71400 (+19%) due to supplier cost inflation and ad spend.',
  });
  assert.equal(chunks.length, 2);
  assert.equal(chunks[1].locationLabel, 'Page 2');

  const chunkModels: KnowledgeChunk[] = chunks.map((c, idx) => ({
    id: `chk_${idx}`,
    companyId: 'comp_1',
    documentId: 'doc_1',
    documentName: 'Q1_Q2_PL.pdf',
    domain: 'finance',
    periodKey: '2026-Q2',
    chunkIndex: c.chunkIndex,
    locationLabel: c.locationLabel,
    content: c.content,
    keywords: c.keywords,
    createdAt: null,
  }));

  const hits = searchKnowledgeChunks('Why did expenses surge supplier cost', chunkModels, 2);
  assert.ok(hits.length >= 1);
  assert.equal(hits[0].chunk.locationLabel, 'Page 2');

  const sheetSummary = summarizeTabularRows('Ledger', [
    { Month: '2026-01', Category: 'Core', Revenue: 100000, Expenses: 60000 },
    { Month: '2026-06', Category: 'Core', Revenue: 108000, Expenses: 71400 },
  ]);
  const drafts = extractStructuredRecordsFromSheets({
    sheets: [sheetSummary],
    domain: 'finance',
    defaultPeriodKey: '2026-06',
  });
  assert.equal(drafts.length, 4);

  const records: StructuredBusinessRecord[] = drafts.map((d, idx) => ({
    ...d,
    id: `rec_${idx}`,
    companyId: 'comp_1',
    sourceDocumentId: 'doc_1',
    sourceDocumentName: 'Ledger.xlsx',
    verificationStatus: idx === 0 ? 'verified' : 'pending_review',
    createdBy: 'u1',
    createdAt: null,
    updatedAt: null,
  }));

  const analytics = computePeriodAnalytics(records);
  assert.equal(analytics.totalRevenue, 208000);
  assert.equal(analytics.totalExpenses, 131400);
  assert.equal(analytics.revenueGrowthPct, 8);
  assert.equal(analytics.expenseGrowthPct, 19);
  assert.equal(analytics.verifiedCount, 1);
  assert.equal(analytics.pendingCount, 3);
});

test('Financial Forensics detects margin compression, duplicates, and round numbers', () => {
  const records: StructuredBusinessRecord[] = [
    {
      id: 'r1',
      companyId: 'c1',
      domain: 'finance',
      periodKey: '2026-01',
      metricKey: 'revenue',
      metricLabel: 'Revenue',
      category: 'Sales',
      numericValue: 100000,
      unit: 'currency',
      sourceDocumentId: 'd1',
      sourceDocumentName: 'PL.xlsx',
      sourceLocation: 'Row 2',
      verificationStatus: 'verified',
      createdBy: 'u1',
      createdAt: null,
      updatedAt: null,
    },
    {
      id: 'r2',
      companyId: 'c1',
      domain: 'finance',
      periodKey: '2026-01',
      metricKey: 'expenses',
      metricLabel: 'Vendor Fee',
      category: 'Logistics',
      numericValue: 5000,
      unit: 'currency',
      sourceDocumentId: 'd1',
      sourceDocumentName: 'PL.xlsx',
      sourceLocation: 'Row 3',
      verificationStatus: 'pending_review',
      createdBy: 'u1',
      createdAt: null,
      updatedAt: null,
    },
    {
      id: 'r3',
      companyId: 'c1',
      domain: 'finance',
      periodKey: '2026-01',
      metricKey: 'expenses',
      metricLabel: 'Vendor Fee',
      category: 'Logistics',
      numericValue: 5000,
      unit: 'currency',
      sourceDocumentId: 'd2',
      sourceDocumentName: 'Inv.pdf',
      sourceLocation: 'Page 1',
      verificationStatus: 'pending_review',
      createdBy: 'u1',
      createdAt: null,
      updatedAt: null,
    },
    {
      id: 'r4',
      companyId: 'c1',
      domain: 'finance',
      periodKey: '2026-02',
      metricKey: 'revenue',
      metricLabel: 'Revenue',
      category: 'Sales',
      numericValue: 105000,
      unit: 'currency',
      sourceDocumentId: 'd1',
      sourceDocumentName: 'PL.xlsx',
      sourceLocation: 'Row 4',
      verificationStatus: 'verified',
      createdBy: 'u1',
      createdAt: null,
      updatedAt: null,
    },
    {
      id: 'r5',
      companyId: 'c1',
      domain: 'finance',
      periodKey: '2026-02',
      metricKey: 'expenses',
      metricLabel: 'Consultancy',
      category: 'Ops',
      numericValue: 20000,
      unit: 'currency',
      sourceDocumentId: 'd1',
      sourceDocumentName: 'PL.xlsx',
      sourceLocation: 'Row 5',
      verificationStatus: 'pending_review',
      createdBy: 'u1',
      createdAt: null,
      updatedAt: null,
    },
  ];

  const findings = runFinancialForensics({ records });
  const categories = findings.map((f) => f.category);
  assert.ok(categories.includes('margin_compression'));
  assert.ok(categories.includes('expense_spike'));
  assert.ok(categories.includes('duplicate_entry'));
  assert.ok(categories.includes('round_number_pattern'));
});

test('specialist auto-routing fallback selects relevant active department and validates IDs', () => {
  assert.equal(parseSpecialistId('Finance'), 'finance');
  assert.equal(parseSpecialistId('  strategy '), 'strategy');
  assert.equal(parseSpecialistId('auto'), null);
  assert.equal(parseSpecialistId('invalid_id'), null);

  assert.equal(resolveSpecialistFallback('حلل مصروفات الرواتب والموظفين'), 'hr');
  assert.equal(resolveSpecialistFallback('Compare supplier contract prices and PO terms'), 'procurement');
  assert.equal(resolveSpecialistFallback('Why did revenue drop and expenses rise in P&L?'), 'finance');
  assert.equal(resolveSpecialistFallback('General KPI overview'), 'bi');
});

test('sanitizeEnvSetting strips accidental KEY= prefixes and quotes', () => {
  assert.equal(sanitizeEnvSetting('AWS_REGION=us-east-1', 'AWS_REGION'), 'us-east-1');
  assert.equal(sanitizeEnvSetting('  "us-east-1"  ', 'AWS_REGION'), 'us-east-1');
  assert.equal(sanitizeEnvSetting('eu-west-1', 'AWS_REGION'), 'eu-west-1');
  assert.equal(sanitizeEnvSetting(undefined, 'AWS_REGION'), '');
});

test('extractFocusSpotlight and draft sanitizers enforce non-empty Firestore-safe bounds', () => {
  const focus = extractFocusSpotlight('Priority overtime cost: 18,500\nMargin target: 22');
  assert.equal(focus.lines.length, 2);
  assert.deepEqual(focus.numbers, [18500, 22]);

  const rec = sanitizeStructuredRecordDraft(
    { domain: 'invalid' as never, periodKey: '', metricLabel: 'A'.repeat(200), numericValue: Number.NaN },
    'operations',
    '2026-05',
    'Page 3'
  );
  assert.equal(rec.domain, 'operations');
  assert.equal(rec.periodKey, '2026-05');
  assert.equal(rec.metricLabel.length, 120);
  assert.equal(rec.numericValue, 0);
  assert.equal(rec.sourceLocation, 'Page 3');

  const chk = sanitizeKnowledgeChunkDraft({ chunkIndex: -4, locationLabel: '', content: '' }, 'Page 1');
  assert.equal(chk.chunkIndex, 0);
  assert.equal(chk.locationLabel, 'Page 1');
  assert.ok(chk.content.length >= 1);

  const f1 = sanitizeForensicFindingDraft({ titleEn: 'Duplicate Vendor Fee', sourceDocumentName: 'inv.pdf', sourceLocation: 'Page 1' });
  const f2 = sanitizeForensicFindingDraft({ titleEn: 'duplicate vendor fee', sourceDocumentName: 'inv.pdf', sourceLocation: 'page 1' });
  assert.equal(f1.status, 'open');
  assert.ok(f1.titleAr.length >= 1);
  assert.equal(dedupeForensicFindings([f1, f2]).length, 1);

  const prop = sanitizeGrowthProposalDraft({
    domain: 'marketing',
    title: '',
    executionPlan: [],
    requiresManagementApproval: false as never,
    status: 'approved' as never,
  });
  assert.equal(prop.requiresManagementApproval, true);
  assert.equal(prop.status, 'pending_approval');
  assert.ok(prop.title.length >= 1);
  assert.ok(prop.executionPlan.length >= 1);
});


