# EGAI Enterprise Security Specification

## 1. Data Invariants
1. **Strict Tenant Isolation**: Every document, conversation, message, report, member, invite, and usage log belongs to exactly one `companyId`. Users who are not active members of `companies/{companyId}/members/{uid}` have zero read or write access to any company resource.
2. **Verified Identity Enforcement**: All company-level operations require `request.auth != null && request.auth.token.email_verified == true`.
3. **RBAC Role Hierarchy**:
   - `owner`: Full control over company profile, billing/limits, team members, invites, and all workspace data.
   - `administrator`: Can manage company profile, invites, non-owner members, usage limits, and all workspace data. Cannot demote or remove the `owner`.
   - `analyst`: Can upload/delete documents, create/edit conversations, run AI workflows, and generate/delete reports. Cannot manage team roles or company settings.
   - `viewer`: Read-only access to company overview, documents, conversations, reports, and usage summaries. Cannot create, update, or delete business records or invoke AI.
4. **No Self-Assigned Privileges**: Users cannot add themselves to another company or escalate their `role`. Only company creation (with `ownerId == request.auth.uid` and atomic `getAfter`) or accepting a valid pending `companyInvites` document for their verified email creates a membership.
5. **Immutable Audit Fields & Server Timestamps**: `createdAt`, `companyId`, `ownerId`, `createdBy`, `uploadedBy`, `senderId`, and `userId` are immutable after creation. All `createdAt` and `updatedAt` fields must equal `request.time`.
6. **PII Isolation**: `/users/{userId}` is strictly readable and writable only by `request.auth.uid == userId`. No blanket `isSignedIn()` reads exist anywhere.

## 2. The "Dirty Dozen" Adversarial Test Payloads
1. **Cross-Tenant Read**: User B (member of Company B) attempts `GET /companies/companyA/documents/doc1` -> `PERMISSION_DENIED`.
2. **Privilege Escalation on Join**: User B creates `/companies/companyA/members/userB` with `{ role: "owner" }` -> `PERMISSION_DENIED`.
3. **Role Self-Promotion**: An `analyst` updates their own `/companies/companyA/members/{uid}` with `{ role: "administrator" }` -> `PERMISSION_DENIED`.
4. **Shadow Field Injection**: A member creates a document with an extra undeclared field `{ isVerifiedSystem: true }` -> `PERMISSION_DENIED`.
5. **Email Spoofing (Unverified)**: User creates a company with `email_verified: false` -> `PERMISSION_DENIED`.
6. **PII Scraping**: Signed-in User B attempts `GET /users/userA` -> `PERMISSION_DENIED`.
7. **Viewer Write Attempt**: A `viewer` attempts to create a conversation or upload document metadata -> `PERMISSION_DENIED`.
8. **Timestamp Forgery**: User creates a company with `createdAt` set to a past timestamp instead of `request.time` -> `PERMISSION_DENIED`.
9. **ID Poisoning**: User attempts to write to `/companies/invalid id with spaces and 2kb payload...` -> `PERMISSION_DENIED`.
10. **Terminal State Mutation**: User attempts to update a `companyInvites` document after `status` is `'accepted'` or `'revoked'` -> `PERMISSION_DENIED`.
11. **Usage Log Tampering**: User attempts to `UPDATE` or `DELETE` an immutable `usageLogs` record -> `PERMISSION_DENIED`.
12. **Blanket List Query**: Non-member attempts `LIST /companyInvites` without filtering by their verified email -> `PERMISSION_DENIED`.
