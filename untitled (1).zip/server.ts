import path from 'node:path';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { serverEnv } from './server/config.ts';
import apiRouter from './server/routes/api.ts';

async function startServer() {
  const app = express();

  app.set('trust proxy', 1);
  app.use(express.json({ limit: '2mb' }));

  // General API rate limiting
  app.use(
    '/api',
    rateLimit({
      windowMs: 60 * 1000,
      max: 120,
      standardHeaders: true,
      legacyHeaders: false,
    })
  );

  app.use('/api', apiRouter);

  if (serverEnv.nodeEnv !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(serverEnv.port, '0.0.0.0', () => {
    console.log(`EGAI Enterprise server listening on http://0.0.0.0:${serverEnv.port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start EGAI Enterprise server:', err);
  process.exit(1);
});
