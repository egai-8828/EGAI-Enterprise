import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
import { sanitizeEnvSetting } from '../src/shared/financeUtils.ts';
import type { AIProviderName, IntegrationStatus } from '../src/shared/types.ts';

dotenv.config({ override: true });

interface FirebaseAppletConfig {
  projectId: string;
  appId: string;
  apiKey: string;
  authDomain: string;
  firestoreDatabaseId: string;
  storageBucket: string;
}

function loadFirebaseConfig(): FirebaseAppletConfig {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (!fs.existsSync(configPath)) {
    throw new Error('Missing firebase-applet-config.json. Provision Firebase before starting the server.');
  }
  const raw = fs.readFileSync(configPath, 'utf-8');
  return JSON.parse(raw) as FirebaseAppletConfig;
}

export const firebaseConfig = loadFirebaseConfig();

export const serverEnv = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  geminiApiKey:
    process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'
      ? process.env.GEMINI_API_KEY.trim()
      : '',
  geminiModel: 'gemini-4-hydrogen',
  awsRegion: sanitizeEnvSetting(process.env.AWS_REGION, 'AWS_REGION'),
  awsAccessKeyId: sanitizeEnvSetting(process.env.AWS_ACCESS_KEY_ID, 'AWS_ACCESS_KEY_ID'),
  awsSecretAccessKey: sanitizeEnvSetting(process.env.AWS_SECRET_ACCESS_KEY, 'AWS_SECRET_ACCESS_KEY'),
  bedrockModelId:
    sanitizeEnvSetting(process.env.BEDROCK_MODEL_ID, 'BEDROCK_MODEL_ID') ||
    'anthropic.claude-3-5-sonnet-20241022-v2:0',
  awsS3Bucket: sanitizeEnvSetting(process.env.AWS_S3_BUCKET, 'AWS_S3_BUCKET'),
  paymobApiKey: sanitizeEnvSetting(process.env.PAYMOB_API_KEY, 'PAYMOB_API_KEY'),
  paymobIntegrationId: sanitizeEnvSetting(process.env.PAYMOB_INTEGRATION_ID, 'PAYMOB_INTEGRATION_ID'),
  paymobHmacSecret: sanitizeEnvSetting(process.env.PAYMOB_HMAC_SECRET, 'PAYMOB_HMAC_SECRET'),
};

export function isBedrockConfigured(): boolean {
  return Boolean(
    serverEnv.awsRegion &&
      serverEnv.awsAccessKeyId &&
      serverEnv.awsSecretAccessKey &&
      serverEnv.bedrockModelId
  );
}

export function isGeminiConfigured(): boolean {
  return Boolean(serverEnv.geminiApiKey);
}

export function isAnyAiProviderConfigured(): boolean {
  return isGeminiConfigured() || isBedrockConfigured();
}

export function isS3Configured(): boolean {
  return Boolean(
    serverEnv.awsS3Bucket &&
      serverEnv.awsRegion &&
      serverEnv.awsAccessKeyId &&
      serverEnv.awsSecretAccessKey
  );
}

export function getActiveAiProvider(): AIProviderName {
  const requestedDefault = (process.env.DEFAULT_AI_PROVIDER || '').trim().toLowerCase();
  if (requestedDefault === 'bedrock' && isBedrockConfigured()) return 'bedrock';
  if (isGeminiConfigured()) return 'gemini';
  if (isBedrockConfigured()) return 'bedrock';
  return 'gemini';
}

export function getIntegrationStatus(): IntegrationStatus {
  return {
    firebaseAuth: {
      configured: Boolean(firebaseConfig.projectId && firebaseConfig.apiKey),
      projectId: firebaseConfig.projectId,
    },
    firestore: {
      configured: Boolean(firebaseConfig.projectId && firebaseConfig.firestoreDatabaseId),
      databaseId: firebaseConfig.firestoreDatabaseId,
    },
    bedrock: {
      configured: isBedrockConfigured(),
      region: serverEnv.awsRegion || 'us-east-1',
      modelId: serverEnv.bedrockModelId,
      requiredEnv: ['AWS_REGION', 'AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'BEDROCK_MODEL_ID'],
    },
    gemini: {
      configured: isGeminiConfigured(),
      model: serverEnv.geminiModel,
    },
    s3Storage: {
      configured: isS3Configured(),
      bucket: serverEnv.awsS3Bucket || 'local-enterprise-store',
      mode: isS3Configured() ? 'aws_s3' : 'local_disk',
    },
    billingProvider: {
      configured: Boolean(
        serverEnv.paymobApiKey &&
          serverEnv.paymobIntegrationId &&
          serverEnv.paymobHmacSecret
      ),
      provider: 'paymob',
      requiredEnv: ['PAYMOB_API_KEY', 'PAYMOB_INTEGRATION_ID', 'PAYMOB_HMAC_SECRET'],
    },
    activeAiProvider: getActiveAiProvider(),
  };
}
