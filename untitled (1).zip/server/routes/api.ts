import { Router, type Response } from 'express';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import { getIntegrationStatus } from '../config.ts';
import { verifyFirebaseToken, type AuthenticatedRequest } from '../middleware/auth.ts';
import {
  assertAuthorizedRole,
  createUsageLogRest,
  getCompanyMemberRest,
  getCompanyProfileRest,
  getMonthUsageRest,
  isValidCompanyIdFormat,
  updateCompanyLimitsRest,
} from '../services/firestoreRest.ts';
import { detectDocumentFormat, parseDocumentBuffer } from '../services/documentParser.ts';
import {
  deleteDocumentObjects,
  listCompanyDocumentExtracts,
  loadDocumentExtract,
  purgeCompanyStorage,
  storeDocumentAndExtract,
  type StoredDocumentExtract,
} from '../services/storageService.ts';
import {
  buildGroundingSystemPrompt,
  classifyAndExtractDocumentWithAI,
  generateEnterpriseAI,
  generateForensicFindingsWithAI,
  generateGrowthProposalsWithAI,
  IntegrationNotConfiguredError,
  resolveActiveProvider,
  selectSpecialistWithAI,
  streamEnterpriseAI,
} from '../services/aiProvider.ts';
import {
  getSpecialist,
  isSpecialistActive,
  parseSpecialistId,
  SPECIALISTS,
} from '../../src/shared/specialists.ts';
import { evaluateQuotaStatus, PLANS } from '../../src/shared/plans.ts';
import { getCurrentMonthKey } from '../../src/shared/financeUtils.ts';
import {
  chunkDocumentText,
  computePeriodAnalytics,
  dedupeForensicFindings,
  extractStructuredRecordsFromSheets,
  GROWTH_ADVISOR_DOMAINS,
  inferDomainFromText,
  normalizeTextToken,
  runFinancialForensics,
  sanitizeKnowledgeChunkDraft,
  sanitizeStructuredRecordDraft,
  searchKnowledgeChunks,
  WORKSPACE_DATA_DOMAINS,
  type ExtractedRecordDraft,
} from '../../src/shared/intelligenceEngine.ts';
import type {
  ActiveSpecialistId,
  CompanyProfile,
  GrowthAdvisorDomain,
  KnowledgeChunk,
  PlanId,
  ReportType,
  SpecialistSelection,
  StructuredBusinessRecord,
  UsageLog,
  WorkspaceDataDomain,
} from '../../src/shared/types.ts';

const router = Router();

const MAX_FILE_BYTES = 20 * 1024 * 1024; // 20 MB

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_FILE_BYTES,
  },
});

const aiRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 35,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Rate limit exceeded for AI requests. Please wait a minute before retrying.',
    code: 'RATE_LIMITED',
  },
});

function handleRouteError(res: Response, err: unknown) {
  if (err instanceof IntegrationNotConfiguredError) {
    res.status(503).json({
      error: err.message,
      code: 'INTEGRATION_NOT_CONFIGURED',
      provider: err.provider,
      requiredEnv: err.requiredEnv,
    });
    return;
  }
  const msg = err instanceof Error ? err.message : 'Internal server error';
  if (msg.startsWith('FORBIDDEN:')) {
    res.status(403).json({ error: msg, code: 'FORBIDDEN' });
    return;
  }
  console.error('[EGAI API Error]', err);
  res.status(500).json({ error: msg, code: 'INTERNAL_ERROR' });
}

async function enforceMonthlyQuota(
  company: CompanyProfile,
  companyId: string,
  idToken: string,
  res: Response
): Promise<{ monthKey: string } | null> {
  const monthKey = getCurrentMonthKey();
  const monthUsage = await getMonthUsageRest(companyId, monthKey, idToken);
  const quota = evaluateQuotaStatus(
    monthUsage.tokensUsed,
    monthUsage.requestsUsed,
    company.monthlyTokenLimit,
    company.monthlyRequestLimit
  );

  if (quota.exceeded) {
    res.status(429).json({
      error:
        quota.reason === 'token_limit_exceeded'
          ? 'Monthly company AI token limit has been reached. Upgrade plan or adjust limits in Company Settings.'
          : 'Monthly company AI request limit has been reached. Upgrade plan or adjust limits in Company Settings.',
      code: 'QUOTA_EXCEEDED',
      quota,
    });
    return null;
  }

  return { monthKey };
}

async function recordUsage(params: {
  companyId: string;
  idToken: string;
  userId: string;
  userEmail: string;
  specialistId: ActiveSpecialistId;
  provider: UsageLog['provider'];
  model: string;
  inputTokens: number;
  outputTokens: number;
  monthKey: string;
  action: UsageLog['action'];
}) {
  const logId = `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  await createUsageLogRest(params.companyId, logId, params.idToken, {
    userId: params.userId,
    userEmail: params.userEmail || 'unknown@user',
    specialistId: params.specialistId,
    provider: params.provider,
    model: params.model,
    inputTokens: params.inputTokens,
    outputTokens: params.outputTokens,
    monthKey: params.monthKey,
    action: params.action,
  }).catch((err) => console.error('[UsageLog Error]', err));
}

function mergeExtractedRecords(
  sheetRecords: ExtractedRecordDraft[],
  aiRecords: ExtractedRecordDraft[]
): ExtractedRecordDraft[] {
  const out: ExtractedRecordDraft[] = [];
  const seen = new Set<string>();

  for (const item of [...sheetRecords, ...aiRecords]) {
    const key = [
      item.periodKey,
      normalizeTextToken(item.metricLabel),
      Number(item.numericValue).toFixed(2),
    ].join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
    if (out.length >= 40) break;
  }

  return out;
}

function buildChunksFromExtracts(
  companyId: string,
  docs: StoredDocumentExtract[]
): KnowledgeChunk[] {
  const result: KnowledgeChunk[] = [];
  for (const d of docs) {
    const drafts = chunkDocumentText({
      fullText: d.fullText,
      fileName: d.fileName,
      maxChunks: 16,
    });
    for (const draft of drafts) {
      result.push({
        id: `${d.docId}_chunk_${draft.chunkIndex}`,
        companyId,
        documentId: d.docId,
        documentName: d.fileName,
        domain: d.domain || 'finance',
        periodKey: d.periodKey || getCurrentMonthKey(),
        chunkIndex: draft.chunkIndex,
        locationLabel: draft.locationLabel,
        content: draft.content,
        keywords: draft.keywords,
        createdAt: null,
      });
    }
  }
  return result;
}

function buildRecordsFromExtracts(
  companyId: string,
  docs: StoredDocumentExtract[],
  userId: string
): StructuredBusinessRecord[] {
  const records: StructuredBusinessRecord[] = [];
  for (const d of docs) {
    const domain = d.domain || inferDomainFromText(d.fileName, d.fullText);
    const periodKey = d.periodKey || getCurrentMonthKey();
    const drafts =
      d.sheets && d.sheets.length > 0
        ? extractStructuredRecordsFromSheets({
            sheets: d.sheets,
            domain,
            defaultPeriodKey: periodKey,
            maxRecords: 30,
          })
        : [];
    drafts.forEach((draft, idx) => {
      records.push({
        id: `${d.docId}_rec_${idx}`,
        companyId,
        domain: draft.domain,
        periodKey: draft.periodKey,
        metricKey: draft.metricKey,
        metricLabel: draft.metricLabel,
        category: draft.category,
        numericValue: draft.numericValue,
        unit: draft.unit,
        sourceDocumentId: d.docId,
        sourceDocumentName: d.fileName,
        sourceLocation: draft.sourceLocation,
        verificationStatus: 'pending_review',
        createdBy: userId,
        createdAt: null,
        updatedAt: null,
      });
    });
  }
  return records;
}

// Public readiness & catalog endpoints
router.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'egai-enterprise-api',
    timestamp: new Date().toISOString(),
  });
});

router.get('/system/integrations', (_req, res) => {
  res.json(getIntegrationStatus());
});

router.get('/specialists', (_req, res) => {
  res.json({ specialists: SPECIALISTS });
});

// Upload, parse, AI-classify & extract enterprise document (PDF, XLSX, CSV, DOCX, TXT)
router.post(
  '/documents/upload',
  verifyFirebaseToken,
  aiRateLimiter,
  upload.single('file'),
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const companyId = String(req.body.companyId || '').trim();
      const docId = String(req.body.docId || '').trim();
      const requestedDomainRaw = String(req.body.domain || '').trim();
      const requestedPeriod = String(req.body.periodKey || '').trim().slice(0, 32);
      const file = req.file;

      if (!isValidCompanyIdFormat(companyId) || !isValidCompanyIdFormat(docId)) {
        res.status(400).json({ error: 'Invalid companyId or docId format.' });
        return;
      }
      if (!file) {
        res.status(400).json({ error: 'No document file uploaded.' });
        return;
      }

      const format = detectDocumentFormat(file.originalname);
      if (!format) {
        res.status(400).json({
          error: 'Unsupported file format. Allowed: PDF, XLSX, CSV, DOCX, TXT.',
        });
        return;
      }

      resolveActiveProvider();

      const [company, member] = await Promise.all([
        getCompanyProfileRest(companyId, user.idToken),
        getCompanyMemberRest(companyId, user.uid, user.idToken),
      ]);
      if (!company) {
        res.status(404).json({ error: 'Company workspace not found.' });
        return;
      }
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      const plan = PLANS[company.planId] || PLANS.starter;
      const maxPlanBytes = plan.maxFileSizeMb * 1024 * 1024;
      if (file.size > maxPlanBytes) {
        res.status(413).json({
          error: `File size exceeds your ${plan.nameEn} limit of ${plan.maxFileSizeMb} MB.`,
        });
        return;
      }

      const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
      if (!quotaCheck) return;

      const parsed = await parseDocumentBuffer(file.buffer, file.originalname);
      const validDomainIds = new Set<string>(WORKSPACE_DATA_DOMAINS.map((d) => d.id));
      const explicitDomain = validDomainIds.has(requestedDomainRaw)
        ? (requestedDomainRaw as WorkspaceDataDomain)
        : undefined;

      const aiClassification = await classifyAndExtractDocumentWithAI({
        fileName: file.originalname,
        fileType: parsed.fileType,
        fullText: parsed.fullText,
        sheets: parsed.sheets,
        requestedDomain: explicitDomain,
        requestedPeriod: requestedPeriod || undefined,
        companyName: company.name,
        industry: company.industry,
      });

      const finalDomain = aiClassification.domain;
      const finalPeriodKey = aiClassification.periodKey || getCurrentMonthKey();

      const storageLocation = await storeDocumentAndExtract({
        companyId,
        docId,
        fileName: file.originalname,
        mimeType: file.mimetype,
        buffer: file.buffer,
        parsed,
        domain: finalDomain,
        periodKey: finalPeriodKey,
      });

      const rawChunks = chunkDocumentText({
        fullText: parsed.fullText,
        fileName: file.originalname,
      });
      const chunks = rawChunks.map((c) => sanitizeKnowledgeChunkDraft(c, file.originalname));

      const sheetRecords =
        parsed.sheets && parsed.sheets.length > 0
          ? extractStructuredRecordsFromSheets({
              sheets: parsed.sheets,
              domain: finalDomain,
              defaultPeriodKey: finalPeriodKey,
            }).map((r) =>
              sanitizeStructuredRecordDraft(r, finalDomain, finalPeriodKey, file.originalname)
            )
          : [];

      const extractedRecords = mergeExtractedRecords(
        sheetRecords,
        aiClassification.extractedRecords
      );

      await recordUsage({
        companyId,
        idToken: user.idToken,
        userId: user.uid,
        userEmail: user.email || 'unknown@user',
        specialistId: 'bi',
        provider: aiClassification.provider,
        model: aiClassification.model,
        inputTokens: aiClassification.inputTokens,
        outputTokens: aiClassification.outputTokens,
        monthKey: quotaCheck.monthKey,
        action: 'document_classification',
      });

      res.json({
        docId,
        fileName: file.originalname,
        fileType: parsed.fileType,
        fileSize: file.size,
        storageLocation,
        status: 'ready',
        domain: finalDomain,
        periodKey: finalPeriodKey,
        aiSummary: aiClassification.summary,
        autoClassified: !explicitDomain,
        provider: aiClassification.provider,
        model: aiClassification.model,
        pageCount: parsed.pageCount ?? null,
        sheetNames: parsed.sheetNames ?? [],
        sheets: parsed.sheets ?? [],
        textPreview: parsed.textPreview,
        chunks,
        extractedRecords,
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

router.get(
  '/documents/:companyId/:docId/extract',
  verifyFirebaseToken,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const companyId = String(req.params.companyId || '');
      const docId = String(req.params.docId || '');
      if (!isValidCompanyIdFormat(companyId) || !isValidCompanyIdFormat(docId)) {
        res.status(400).json({ error: 'Invalid identifier.' });
        return;
      }

      const member = await getCompanyMemberRest(companyId, user.uid, user.idToken);
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst', 'viewer']);

      const extract = await loadDocumentExtract(companyId, docId);
      if (!extract) {
        res.status(404).json({
          error: 'Extracted document payload is unavailable on this server node.',
        });
        return;
      }
      res.json(extract);
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

router.delete(
  '/documents/:companyId/:docId',
  verifyFirebaseToken,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const companyId = String(req.params.companyId || '');
      const docId = String(req.params.docId || '');
      const storageLocation =
        typeof req.query.storageLocation === 'string' ? req.query.storageLocation : undefined;

      if (!isValidCompanyIdFormat(companyId) || !isValidCompanyIdFormat(docId)) {
        res.status(400).json({ error: 'Invalid identifier.' });
        return;
      }

      const member = await getCompanyMemberRest(companyId, user.uid, user.idToken);
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      await deleteDocumentObjects(companyId, docId, storageLocation);
      res.json({ deleted: true });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Streaming AI Workspace chat endpoint (automatically uses Company Memory & Auto Specialist Routing)
router.post('/chat', verifyFirebaseToken, aiRateLimiter, async (req: AuthenticatedRequest, res) => {
  try {
    const user = req.authUser!;
    const {
      companyId,
      specialistId = 'auto',
      message,
      history = [],
      documentIds = [],
      language = 'en',
      focusData: requestedFocusData,
      records: clientRecords = [],
      chunks: clientChunks = [],
    } = req.body as {
      companyId?: string;
      specialistId?: SpecialistSelection;
      message?: string;
      history?: Array<{ role: 'user' | 'assistant'; content: string }>;
      documentIds?: string[];
      language?: 'en' | 'ar';
      focusData?: string;
      records?: StructuredBusinessRecord[];
      chunks?: KnowledgeChunk[];
    };

    if (!companyId || !isValidCompanyIdFormat(companyId)) {
      res.status(400).json({ error: 'Valid companyId is required.' });
      return;
    }
    if (specialistId !== 'auto' && !isSpecialistActive(specialistId)) {
      res.status(400).json({ error: 'Selected AI specialist is invalid.' });
      return;
    }
    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Message content cannot be empty.' });
      return;
    }

    // Validate AI provider before opening SSE stream
    resolveActiveProvider();

    const [company, member] = await Promise.all([
      getCompanyProfileRest(companyId, user.idToken),
      getCompanyMemberRest(companyId, user.uid, user.idToken),
    ]);

    if (!company) {
      res.status(404).json({ error: 'Company workspace not found.' });
      return;
    }
    assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

    const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
    if (!quotaCheck) return;

    const docs: StoredDocumentExtract[] = [];
    if (Array.isArray(documentIds) && documentIds.length > 0) {
      for (const id of documentIds.slice(0, 8)) {
        if (isValidCompanyIdFormat(id)) {
          const loaded = await loadDocumentExtract(companyId, id);
          if (loaded) docs.push(loaded);
        }
      }
    } else {
      const memoryExtracts = await listCompanyDocumentExtracts(companyId, 12);
      docs.push(...memoryExtracts);
    }

    const effectiveChunks =
      Array.isArray(clientChunks) && clientChunks.length > 0
        ? clientChunks
        : buildChunksFromExtracts(companyId, docs);

    const effectiveRecords =
      Array.isArray(clientRecords) && clientRecords.length > 0
        ? clientRecords
        : buildRecordsFromExtracts(companyId, docs, user.uid);

    const effectiveFocusData =
      typeof requestedFocusData === 'string' && requestedFocusData.trim()
        ? requestedFocusData.trim().slice(0, 8000)
        : (company.modelFocusData || '').trim().slice(0, 8000);

    const lang = language === 'ar' ? 'ar' : 'en';
    const explicitSpecialist = parseSpecialistId(specialistId);
    let chosenSpecialist: ActiveSpecialistId;
    let routingInputTokens = 0;
    let routingOutputTokens = 0;

    if (explicitSpecialist) {
      chosenSpecialist = explicitSpecialist;
    } else {
      const routing = await selectSpecialistWithAI({
        query: message.trim(),
        focusData: effectiveFocusData,
        documentSummaries: docs.map((d) => `${d.fileName} (${d.domain || 'general'})`),
        language: lang,
      });
      chosenSpecialist = routing.specialistId;
      routingInputTokens = routing.inputTokens;
      routingOutputTokens = routing.outputTokens;
    }

    const ragHits = searchKnowledgeChunks(
      effectiveFocusData ? `${message.trim()} ${effectiveFocusData}` : message.trim(),
      effectiveChunks,
      6
    );
    const analytics = computePeriodAnalytics(effectiveRecords);

    const specialist = getSpecialist(chosenSpecialist)!;
    const systemInstruction = buildGroundingSystemPrompt({
      baseInstruction: specialist.systemInstruction,
      companyName: company.name,
      industry: company.industry,
      country: company.country,
      language: lang,
      companySummary: company.companySummary,
      strategicGoals: company.strategicGoals,
      focusData: effectiveFocusData,
      structuredAnalyticsSummary:
        analytics.totalRecords > 0
          ? `Records=${analytics.totalRecords}, Revenue=${analytics.totalRevenue}, Expenses=${analytics.totalExpenses}, NetProfit=${analytics.netProfit}, Periods=${analytics.periods.length}`
          : undefined,
      retrievedChunks: ragHits,
      documents: docs,
    });

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');

    res.write(`data: ${JSON.stringify({ type: 'meta', specialistId: chosenSpecialist })}\n\n`);

    const result = await streamEnterpriseAI({
      systemInstruction,
      history,
      userMessage: message.trim(),
      onDelta: (chunk) => {
        res.write(`data: ${JSON.stringify({ type: 'delta', text: chunk })}\n\n`);
      },
    });

    const totalInputTokens = result.inputTokens + routingInputTokens;
    const totalOutputTokens = result.outputTokens + routingOutputTokens;

    await recordUsage({
      companyId,
      idToken: user.idToken,
      userId: user.uid,
      userEmail: user.email || 'unknown@user',
      specialistId: chosenSpecialist,
      provider: result.provider,
      model: result.model,
      inputTokens: totalInputTokens,
      outputTokens: totalOutputTokens,
      monthKey: quotaCheck.monthKey,
      action: 'chat',
    });

    res.write(
      `data: ${JSON.stringify({
        type: 'done',
        specialistId: chosenSpecialist,
        provider: result.provider,
        model: result.model,
        inputTokens: totalInputTokens,
        outputTokens: totalOutputTokens,
      })}\n\n`
    );
    res.end();
  } catch (err) {
    if (!res.headersSent) {
      handleRouteError(res, err);
    } else {
      const msg = err instanceof Error ? err.message : 'Streaming failed';
      res.write(`data: ${JSON.stringify({ type: 'error', error: msg })}\n\n`);
      res.end();
    }
  }
});

// Company Intelligence Memory RAG Query endpoint
router.post(
  '/intelligence/query',
  verifyFirebaseToken,
  aiRateLimiter,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const {
        companyId,
        question,
        domain = 'all',
        language = 'en',
        focusData: requestedFocusData,
        records: clientRecords = [],
        chunks: clientChunks = [],
      } = req.body as {
        companyId?: string;
        question?: string;
        domain?: WorkspaceDataDomain | 'all';
        language?: 'en' | 'ar';
        focusData?: string;
        records?: StructuredBusinessRecord[];
        chunks?: KnowledgeChunk[];
      };

      if (!companyId || !isValidCompanyIdFormat(companyId)) {
        res.status(400).json({ error: 'Valid companyId is required.' });
        return;
      }
      if (!question || !question.trim()) {
        res.status(400).json({ error: 'Search query cannot be empty.' });
        return;
      }

      resolveActiveProvider();

      const [company, member] = await Promise.all([
        getCompanyProfileRest(companyId, user.idToken),
        getCompanyMemberRest(companyId, user.uid, user.idToken),
      ]);
      if (!company) {
        res.status(404).json({ error: 'Company workspace not found.' });
        return;
      }
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
      if (!quotaCheck) return;

      const docs = await listCompanyDocumentExtracts(companyId, 16);
      const effectiveChunks =
        Array.isArray(clientChunks) && clientChunks.length > 0
          ? clientChunks
          : buildChunksFromExtracts(companyId, docs);
      const effectiveRecords =
        Array.isArray(clientRecords) && clientRecords.length > 0
          ? clientRecords
          : buildRecordsFromExtracts(companyId, docs, user.uid);

      const effectiveFocusData =
        typeof requestedFocusData === 'string' && requestedFocusData.trim()
          ? requestedFocusData.trim().slice(0, 8000)
          : (company.modelFocusData || '').trim().slice(0, 8000);

      const hits = searchKnowledgeChunks(
        effectiveFocusData ? `${question.trim()} ${effectiveFocusData}` : question.trim(),
        effectiveChunks,
        6,
        domain
      );
      const analytics = computePeriodAnalytics(effectiveRecords);
      const lang = language === 'ar' ? 'ar' : 'en';

      const specialist = getSpecialist('bi')!;
      const systemInstruction = buildGroundingSystemPrompt({
        baseInstruction: specialist.systemInstruction,
        companyName: company.name,
        industry: company.industry,
        country: company.country,
        language: lang,
        companySummary: company.companySummary,
        strategicGoals: company.strategicGoals,
        focusData: effectiveFocusData,
        structuredAnalyticsSummary:
          analytics.totalRecords > 0
            ? `Records=${analytics.totalRecords}, Revenue=${analytics.totalRevenue}, Expenses=${analytics.totalExpenses}, NetProfit=${analytics.netProfit}, MarginPct=${analytics.profitMarginPct ?? 'N/A'}, Periods=${analytics.periods.length}`
            : undefined,
        retrievedChunks: hits,
        documents: docs.slice(0, 8),
      });

      const aiResult = await generateEnterpriseAI({
        systemInstruction,
        userPrompt: question.trim(),
      });

      await recordUsage({
        companyId,
        idToken: user.idToken,
        userId: user.uid,
        userEmail: user.email || 'unknown@user',
        specialistId: 'bi',
        provider: aiResult.provider,
        model: aiResult.model,
        inputTokens: aiResult.inputTokens,
        outputTokens: aiResult.outputTokens,
        monthKey: quotaCheck.monthKey,
        action: 'intelligence_query',
      });

      res.json({
        answer: aiResult.text,
        hits,
        analytics,
        provider: aiResult.provider,
        model: aiResult.model,
        inputTokens: aiResult.inputTokens,
        outputTokens: aiResult.outputTokens,
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Financial Forensics & Anomaly Detection Scan endpoint (Deterministic Math + Gemini Audit)
router.post(
  '/forensics/scan',
  verifyFirebaseToken,
  aiRateLimiter,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const {
        companyId,
        records = [],
        focusData: requestedFocusData,
      } = req.body as {
        companyId?: string;
        records?: StructuredBusinessRecord[];
        focusData?: string;
      };

      if (!companyId || !isValidCompanyIdFormat(companyId)) {
        res.status(400).json({ error: 'Valid companyId is required.' });
        return;
      }

      resolveActiveProvider();

      const [company, member] = await Promise.all([
        getCompanyProfileRest(companyId, user.idToken),
        getCompanyMemberRest(companyId, user.uid, user.idToken),
      ]);
      if (!company) {
        res.status(404).json({ error: 'Company workspace not found.' });
        return;
      }
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
      if (!quotaCheck) return;

      const docs = await listCompanyDocumentExtracts(companyId, 20);
      const sheetPayload = docs
        .filter((d) => d.sheets && d.sheets.length > 0)
        .map((d) => ({
          docId: d.docId,
          fileName: d.fileName,
          sheets: d.sheets || [],
        }));

      const effectiveRecords =
        Array.isArray(records) && records.length > 0
          ? records
          : buildRecordsFromExtracts(companyId, docs, user.uid);

      const effectiveFocusData =
        typeof requestedFocusData === 'string' && requestedFocusData.trim()
          ? requestedFocusData.trim().slice(0, 8000)
          : (company.modelFocusData || '').trim().slice(0, 8000);

      const mathFindings = runFinancialForensics({
        records: effectiveRecords,
        sheets: sheetPayload,
      });

      const aiForensics = await generateForensicFindingsWithAI({
        companyName: company.name,
        industry: company.industry,
        docs,
        records: effectiveRecords,
        mathFindings,
        focusData: effectiveFocusData,
      });

      const findings = dedupeForensicFindings([...mathFindings, ...aiForensics.findings]);

      await recordUsage({
        companyId,
        idToken: user.idToken,
        userId: user.uid,
        userEmail: user.email || 'unknown@user',
        specialistId: 'finance',
        provider: aiForensics.provider,
        model: aiForensics.model,
        inputTokens: aiForensics.inputTokens,
        outputTokens: aiForensics.outputTokens,
        monthKey: quotaCheck.monthKey,
        action: 'forensics_scan',
      });

      res.json({
        findings,
        scannedDocuments: docs.length,
        scannedRecords: effectiveRecords.length,
        provider: aiForensics.provider,
        model: aiForensics.model,
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Business Growth Advisor endpoint (8 domains, 7 structured fields, Management Approval mandatory)
router.post(
  '/advisor/generate',
  verifyFirebaseToken,
  aiRateLimiter,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const {
        companyId,
        domains = [],
        records = [],
        chunks = [],
        language = 'en',
        focusData: requestedFocusData,
      } = req.body as {
        companyId?: string;
        domains?: GrowthAdvisorDomain[];
        records?: StructuredBusinessRecord[];
        chunks?: KnowledgeChunk[];
        language?: 'en' | 'ar';
        focusData?: string;
      };

      if (!companyId || !isValidCompanyIdFormat(companyId)) {
        res.status(400).json({ error: 'Valid companyId is required.' });
        return;
      }

      resolveActiveProvider();

      const [company, member] = await Promise.all([
        getCompanyProfileRest(companyId, user.idToken),
        getCompanyMemberRest(companyId, user.uid, user.idToken),
      ]);
      if (!company) {
        res.status(404).json({ error: 'Company workspace not found.' });
        return;
      }
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
      if (!quotaCheck) return;

      const validDomains = new Set(GROWTH_ADVISOR_DOMAINS.map((d) => d.id));
      const requestedDomains: GrowthAdvisorDomain[] =
        Array.isArray(domains) && domains.length > 0
          ? domains.filter((d) => validDomains.has(d))
          : ['finance', 'sales', 'marketing', 'operations'];

      if (requestedDomains.length === 0) {
        res.status(400).json({ error: 'Select at least one growth domain.' });
        return;
      }

      const docs = await listCompanyDocumentExtracts(companyId, 16);
      const effectiveChunks =
        Array.isArray(chunks) && chunks.length > 0
          ? chunks
          : buildChunksFromExtracts(companyId, docs);
      const effectiveRecords =
        Array.isArray(records) && records.length > 0
          ? records
          : buildRecordsFromExtracts(companyId, docs, user.uid);

      const effectiveFocusData =
        typeof requestedFocusData === 'string' && requestedFocusData.trim()
          ? requestedFocusData.trim().slice(0, 8000)
          : (company.modelFocusData || '').trim().slice(0, 8000);

      const analytics = computePeriodAnalytics(effectiveRecords);
      const lang = language === 'ar' ? 'ar' : 'en';

      const aiProposals = await generateGrowthProposalsWithAI({
        companyName: company.name,
        industry: company.industry,
        country: company.country,
        language: lang,
        domains: requestedDomains,
        docs,
        records: effectiveRecords,
        chunks: effectiveChunks,
        analytics,
        focusData: effectiveFocusData,
      });

      await recordUsage({
        companyId,
        idToken: user.idToken,
        userId: user.uid,
        userEmail: user.email || 'unknown@user',
        specialistId: 'strategy',
        provider: aiProposals.provider,
        model: aiProposals.model,
        inputTokens: aiProposals.inputTokens,
        outputTokens: aiProposals.outputTokens,
        monthKey: quotaCheck.monthKey,
        action: 'growth_advisor',
      });

      res.json({
        proposals: aiProposals.proposals,
        provider: aiProposals.provider,
        model: aiProposals.model,
        requiresManagementApproval: true,
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Dedicated Document Analysis workflow endpoint
router.post(
  '/documents/analyze',
  verifyFirebaseToken,
  aiRateLimiter,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const {
        companyId,
        documentIds = [],
        workflow = 'summarize',
        question = '',
        specialistId = 'auto',
        language = 'en',
        focusData: requestedFocusData,
      } = req.body as {
        companyId?: string;
        documentIds?: string[];
        workflow?:
          | 'summarize'
          | 'financial_extraction'
          | 'trend_identification'
          | 'comparison'
          | 'qa'
          | 'report';
        question?: string;
        specialistId?: SpecialistSelection;
        language?: 'en' | 'ar';
        focusData?: string;
      };

      if (!companyId || !isValidCompanyIdFormat(companyId)) {
        res.status(400).json({ error: 'Valid companyId is required.' });
        return;
      }
      if (!Array.isArray(documentIds) || documentIds.length === 0) {
        res.status(400).json({ error: 'Select at least one processed document to analyze.' });
        return;
      }

      resolveActiveProvider();

      const [company, member] = await Promise.all([
        getCompanyProfileRest(companyId, user.idToken),
        getCompanyMemberRest(companyId, user.uid, user.idToken),
      ]);
      if (!company) {
        res.status(404).json({ error: 'Company workspace not found.' });
        return;
      }
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
      if (!quotaCheck) return;

      const docs: StoredDocumentExtract[] = [];
      for (const id of documentIds.slice(0, 6)) {
        if (isValidCompanyIdFormat(id)) {
          const loaded = await loadDocumentExtract(companyId, id);
          if (loaded) docs.push(loaded);
        }
      }
      if (docs.length === 0) {
        res.status(404).json({
          error: 'Selected documents could not be found in document storage or have not finished processing.',
        });
        return;
      }

      const lang = language === 'ar' ? 'ar' : 'en';
      const effectiveFocusData =
        typeof requestedFocusData === 'string' && requestedFocusData.trim()
          ? requestedFocusData.trim().slice(0, 8000)
          : (company.modelFocusData || '').trim().slice(0, 8000);

      const workflowPrompts: Record<string, string> = {
        summarize:
          lang === 'ar'
            ? 'قدّم ملخصاً تنفيذياً شاملاً للمستندات المرفقة، مع إبراز الحقائق والأرقام الرئيسية والمصادر (اسم الملف ورقم الصفحة أو الورقة)، وتوضيح أي بيانات مفقودة.'
            : 'Provide a structured executive summary of the attached documents. Cite exact filenames and page/sheet locations for key facts, and explicitly list any missing data.',
        financial_extraction:
          lang === 'ar'
            ? 'استخرج جميع البيانات المالية الموثقة (الإيرادات، المصروفات، الهوامش، التدفقات النقدية، الأصول والالتزامات) في جداول Markdown واضحة مع الإشارة للمصدر، وحدد البنود المفقودة.'
            : 'Extract all documented financial metrics (revenues, expenses, margins, cash flows, assets/liabilities) into structured Markdown tables with exact source citations, and highlight missing line items.',
        trend_identification:
          lang === 'ar'
            ? 'حلل الاتجاهات الزمنية والتغيرات الدورية والقيم الشاذة في البيانات المرفقة مع شرح المؤشرات المحسوبة.'
            : 'Identify period-over-period trends, directional movements, and statistical anomalies across the attached datasets with exact figures and formulas.',
        comparison:
          lang === 'ar'
            ? 'أجرِ مقارنة تفصيلية بين المستندات أو الفترات المرفقة في جدول منظم يوضح الفروقات المطلقة والنسبية.'
            : 'Perform a structured comparison across the attached documents or periods using a Markdown comparison matrix showing absolute and percentage variances.',
        qa:
          question.trim() ||
          (lang === 'ar'
            ? 'أجب عن الأسئلة المحورية في هذه المستندات.'
            : 'Answer key business questions from these documents.'),
        report:
          lang === 'ar'
            ? 'أعد تقريراً مؤسسياً كاملاً يعتمد على المستندات المرفقة ويشمل الملخص التنفيذي والنتائج التفصيلية والمخاطر والتوصيات.'
            : 'Generate a comprehensive enterprise intelligence report grounded in the attached documents with Executive Summary, Detailed Findings, Risks, and Actionable Recommendations.',
      };

      const explicitSpecialist = parseSpecialistId(specialistId);
      let chosenSpecialist: ActiveSpecialistId;
      let routingInputTokens = 0;
      let routingOutputTokens = 0;

      if (explicitSpecialist) {
        chosenSpecialist = explicitSpecialist;
      } else {
        const routing = await selectSpecialistWithAI({
          query: `${workflow} ${question.trim()}`.trim(),
          focusData: effectiveFocusData,
          documentSummaries: docs.map((d) => `${d.fileName} (${d.domain || 'general'})`),
          language: lang,
        });
        chosenSpecialist = routing.specialistId;
        routingInputTokens = routing.inputTokens;
        routingOutputTokens = routing.outputTokens;
      }

      const specialist = getSpecialist(chosenSpecialist)!;
      const systemInstruction = buildGroundingSystemPrompt({
        baseInstruction: specialist.systemInstruction,
        companyName: company.name,
        industry: company.industry,
        country: company.country,
        language: lang,
        companySummary: company.companySummary,
        strategicGoals: company.strategicGoals,
        focusData: effectiveFocusData,
        documents: docs,
      });

      const userPrompt =
        workflow === 'qa' && question.trim()
          ? `${workflowPrompts.qa}\n\nRespond strictly in ${lang === 'ar' ? 'Arabic' : 'English'}.`
          : `${workflowPrompts[workflow] || workflowPrompts.summarize}\n\n${
              question.trim() ? `Additional focus: ${question.trim()}\n` : ''
            }Respond strictly in ${lang === 'ar' ? 'Arabic' : 'English'}.`;

      const result = await generateEnterpriseAI({
        systemInstruction,
        userPrompt,
      });

      const totalInputTokens = result.inputTokens + routingInputTokens;
      const totalOutputTokens = result.outputTokens + routingOutputTokens;

      await recordUsage({
        companyId,
        idToken: user.idToken,
        userId: user.uid,
        userEmail: user.email || 'unknown@user',
        specialistId: chosenSpecialist,
        provider: result.provider,
        model: result.model,
        inputTokens: totalInputTokens,
        outputTokens: totalOutputTokens,
        monthKey: quotaCheck.monthKey,
        action: 'document_analysis',
      });

      res.json({
        content: result.text,
        specialistId: chosenSpecialist,
        provider: result.provider,
        model: result.model,
        inputTokens: totalInputTokens,
        outputTokens: totalOutputTokens,
        analyzedDocuments: docs.map((d) => ({
          docId: d.docId,
          fileName: d.fileName,
          pageCount: d.pageCount,
          sheetNames: d.sheetNames,
        })),
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Generate structured report from template + documents/conversation context
router.post(
  '/reports/generate',
  verifyFirebaseToken,
  aiRateLimiter,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const {
        companyId,
        title,
        reportType = 'executive_summary',
        specialistId = 'auto',
        documentIds = [],
        conversationSummary = '',
        instructions = '',
        language = 'en',
        focusData: requestedFocusData,
      } = req.body as {
        companyId?: string;
        title?: string;
        reportType?: ReportType;
        specialistId?: SpecialistSelection;
        documentIds?: string[];
        conversationSummary?: string;
        instructions?: string;
        language?: 'en' | 'ar';
        focusData?: string;
      };

      if (!companyId || !isValidCompanyIdFormat(companyId)) {
        res.status(400).json({ error: 'Valid companyId is required.' });
        return;
      }
      if (!title || !title.trim()) {
        res.status(400).json({ error: 'Report title is required.' });
        return;
      }

      resolveActiveProvider();

      const [company, member] = await Promise.all([
        getCompanyProfileRest(companyId, user.idToken),
        getCompanyMemberRest(companyId, user.uid, user.idToken),
      ]);
      if (!company) {
        res.status(404).json({ error: 'Company workspace not found.' });
        return;
      }
      assertAuthorizedRole(member, ['owner', 'administrator', 'analyst']);

      const quotaCheck = await enforceMonthlyQuota(company, companyId, user.idToken, res);
      if (!quotaCheck) return;

      const docs: StoredDocumentExtract[] = [];
      if (Array.isArray(documentIds) && documentIds.length > 0) {
        for (const id of documentIds.slice(0, 6)) {
          if (isValidCompanyIdFormat(id)) {
            const loaded = await loadDocumentExtract(companyId, id);
            if (loaded) docs.push(loaded);
          }
        }
      } else {
        docs.push(...(await listCompanyDocumentExtracts(companyId, 10)));
      }

      const lang = language === 'ar' ? 'ar' : 'en';
      const effectiveFocusData =
        typeof requestedFocusData === 'string' && requestedFocusData.trim()
          ? requestedFocusData.trim().slice(0, 8000)
          : (company.modelFocusData || '').trim().slice(0, 8000);

      const explicitSpecialist = parseSpecialistId(specialistId);
      let chosenSpecialist: ActiveSpecialistId;
      let routingInputTokens = 0;
      let routingOutputTokens = 0;

      if (explicitSpecialist) {
        chosenSpecialist = explicitSpecialist;
      } else {
        const routing = await selectSpecialistWithAI({
          query: `${title.trim()} ${reportType} ${instructions}`.trim(),
          focusData: effectiveFocusData,
          documentSummaries: docs.map((d) => `${d.fileName} (${d.domain || 'general'})`),
          language: lang,
        });
        chosenSpecialist = routing.specialistId;
        routingInputTokens = routing.inputTokens;
        routingOutputTokens = routing.outputTokens;
      }

      const specialist = getSpecialist(chosenSpecialist)!;
      const systemInstruction = buildGroundingSystemPrompt({
        baseInstruction: specialist.systemInstruction,
        companyName: company.name,
        industry: company.industry,
        country: company.country,
        language: lang,
        companySummary: company.companySummary,
        strategicGoals: company.strategicGoals,
        focusData: effectiveFocusData,
        documents: docs,
      });

      const prompt = `Generate a formal enterprise report titled "${title.trim()}" using template "${reportType}".
Language: ${lang === 'ar' ? 'Arabic (العربية)' : 'English'}
${conversationSummary ? `\nAssociated Conversation Context:\n${conversationSummary.slice(0, 8000)}\n` : ''}
${instructions ? `\nCustom Instructions:\n${instructions}\n` : ''}
Include clear headings, verified metrics/tables from documents (with source citations), a clear distinction between Document Evidence and General Domain Knowledge, identified data gaps, and concrete next steps.`;

      const result = await generateEnterpriseAI({
        systemInstruction,
        userPrompt: prompt,
      });

      const totalInputTokens = result.inputTokens + routingInputTokens;
      const totalOutputTokens = result.outputTokens + routingOutputTokens;

      await recordUsage({
        companyId,
        idToken: user.idToken,
        userId: user.uid,
        userEmail: user.email || 'unknown@user',
        specialistId: chosenSpecialist,
        provider: result.provider,
        model: result.model,
        inputTokens: totalInputTokens,
        outputTokens: totalOutputTokens,
        monthKey: quotaCheck.monthKey,
        action: 'report_generation',
      });

      res.json({
        content: result.text,
        specialistId: chosenSpecialist,
        provider: result.provider,
        model: result.model,
        inputTokens: totalInputTokens,
        outputTokens: totalOutputTokens,
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Owner-only purge of company document storage (S3 + local disk extracts)
router.delete(
  '/company/:companyId/purge',
  verifyFirebaseToken,
  async (req: AuthenticatedRequest, res) => {
    try {
      const user = req.authUser!;
      const companyId = String(req.params.companyId || '');
      if (!isValidCompanyIdFormat(companyId)) {
        res.status(400).json({ error: 'Invalid companyId format.' });
        return;
      }
      const member = await getCompanyMemberRest(companyId, user.uid, user.idToken);
      assertAuthorizedRole(member, ['owner']);

      await purgeCompanyStorage(companyId);
      res.json({ purged: true });
    } catch (err) {
      handleRouteError(res, err);
    }
  }
);

// Configurable usage limits & plan management (Backend RBAC enforced)
router.post('/company/limits', verifyFirebaseToken, async (req: AuthenticatedRequest, res) => {
  try {
    const user = req.authUser!;
    const { companyId, planId, monthlyTokenLimit, monthlyRequestLimit } = req.body as {
      companyId?: string;
      planId?: PlanId;
      monthlyTokenLimit?: number;
      monthlyRequestLimit?: number;
    };

    if (!companyId || !isValidCompanyIdFormat(companyId)) {
      res.status(400).json({ error: 'Valid companyId is required.' });
      return;
    }
    if (!planId || !(planId in PLANS)) {
      res.status(400).json({ error: 'Invalid planId.' });
      return;
    }
    if (
      typeof monthlyTokenLimit !== 'number' ||
      monthlyTokenLimit < 1000 ||
      typeof monthlyRequestLimit !== 'number' ||
      monthlyRequestLimit < 10
    ) {
      res.status(400).json({ error: 'Invalid token or request limit thresholds.' });
      return;
    }

    const member = await getCompanyMemberRest(companyId, user.uid, user.idToken);
    assertAuthorizedRole(member, ['owner', 'administrator']);

    await updateCompanyLimitsRest(companyId, user.idToken, {
      planId,
      monthlyTokenLimit,
      monthlyRequestLimit,
    });

    res.json({
      updated: true,
      planId,
      monthlyTokenLimit,
      monthlyRequestLimit,
    });
  } catch (err) {
    handleRouteError(res, err);
  }
});

router.get('/billing/status', verifyFirebaseToken, async (_req: AuthenticatedRequest, res) => {
  const integrations = getIntegrationStatus();
  res.json({
    plans: PLANS,
    billingProvider: integrations.billingProvider,
    note: integrations.billingProvider.configured
      ? 'Paymob payment gateway is connected.'
      : 'Paymob payment gateway integration is deferred and not yet connected. Plan upgrades are disabled until Paymob credentials are configured; no simulated charges are processed.',
  });
});

export default router;
