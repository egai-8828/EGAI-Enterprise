import type { NextFunction, Request, Response } from 'express';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { firebaseConfig } from '../config.ts';

const FIREBASE_JWKS = createRemoteJWKSet(
  new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com')
);

export interface AuthenticatedUser {
  uid: string;
  email: string;
  emailVerified: boolean;
  name: string;
  idToken: string;
}

export interface AuthenticatedRequest extends Request {
  authUser?: AuthenticatedUser;
}

export async function verifyFirebaseToken(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({
      error: 'Authentication required. Missing Bearer ID token.',
      code: 'AUTH_REQUIRED',
    });
    return;
  }

  const idToken = header.slice('Bearer '.length).trim();
  if (!idToken) {
    res.status(401).json({
      error: 'Authentication token is empty.',
      code: 'AUTH_INVALID',
    });
    return;
  }

  try {
    const projectId = firebaseConfig.projectId;
    const { payload } = await jwtVerify(idToken, FIREBASE_JWKS, {
      issuer: `https://securetoken.google.com/${projectId}`,
      audience: projectId,
    });

    const uid = typeof payload.sub === 'string' ? payload.sub : '';
    const email = typeof payload.email === 'string' ? payload.email : '';
    const emailVerified = Boolean(payload.email_verified);
    const name = typeof payload.name === 'string' && payload.name ? payload.name : email;

    if (!uid) {
      res.status(401).json({ error: 'Invalid Firebase user subject.', code: 'AUTH_INVALID' });
      return;
    }

    if (!emailVerified) {
      res.status(403).json({
        error: 'Email verification is required before accessing enterprise APIs.',
        code: 'EMAIL_NOT_VERIFIED',
      });
      return;
    }

    req.authUser = {
      uid,
      email,
      emailVerified,
      name,
      idToken,
    };
    next();
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Token verification failed';
    res.status(401).json({
      error: `Invalid or expired authentication token: ${message}`,
      code: 'AUTH_EXPIRED',
    });
  }
}
