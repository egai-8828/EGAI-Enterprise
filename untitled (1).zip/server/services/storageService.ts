import fs from 'node:fs/promises';
import path from 'node:path';
import {
  DeleteObjectCommand,
  DeleteObjectsCommand,
  ListObjectsV2Command,
  PutObjectCommand,
  S3Client,
} from '@aws-sdk/client-s3';
import { isS3Configured, serverEnv } from '../config.ts';
import type { ParsedDocumentResult } from './documentParser.ts';
import type { WorkspaceDataDomain } from '../../src/shared/types.ts';

const STORAGE_ROOT = path.resolve(process.cwd(), 'storage', 'companies');

export interface StoredDocumentExtract {
  docId: string;
  companyId: string;
  fileName: string;
  fileType: string;
  domain?: WorkspaceDataDomain;
  periodKey?: string;
  pageCount?: number;
  sheetNames?: string[];
  sheets?: ParsedDocumentResult['sheets'];
  fullText: string;
}

function getS3Client(): S3Client | null {
  if (!isS3Configured()) return null;
  return new S3Client({
    region: serverEnv.awsRegion,
    credentials: {
      accessKeyId: serverEnv.awsAccessKeyId,
      secretAccessKey: serverEnv.awsSecretAccessKey,
    },
  });
}

function sanitizeSegment(segment: string): string {
  return segment.replace(/[^a-zA-Z0-9_.-]/g, '_');
}

function getCompanyDir(companyId: string): string {
  const safeCompany = sanitizeSegment(companyId);
  return path.join(STORAGE_ROOT, safeCompany);
}

export async function storeDocumentAndExtract(params: {
  companyId: string;
  docId: string;
  fileName: string;
  mimeType: string;
  buffer: Buffer;
  parsed: ParsedDocumentResult;
  domain?: WorkspaceDataDomain;
  periodKey?: string;
}): Promise<string> {
  const safeCompany = sanitizeSegment(params.companyId);
  const safeDoc = sanitizeSegment(params.docId);
  const safeFile = sanitizeSegment(params.fileName);
  const companyDir = getCompanyDir(safeCompany);

  await fs.mkdir(companyDir, { recursive: true });

  const extractPayload: StoredDocumentExtract = {
    docId: params.docId,
    companyId: params.companyId,
    fileName: params.fileName,
    fileType: params.parsed.fileType,
    domain: params.domain,
    periodKey: params.periodKey,
    pageCount: params.parsed.pageCount,
    sheetNames: params.parsed.sheetNames,
    sheets: params.parsed.sheets,
    fullText: params.parsed.fullText,
  };

  const extractPath = path.join(companyDir, `${safeDoc}.extracted.json`);
  await fs.writeFile(extractPath, JSON.stringify(extractPayload), 'utf-8');

  const s3 = getS3Client();
  if (s3 && serverEnv.awsS3Bucket) {
    const key = `companies/${safeCompany}/${safeDoc}-${safeFile}`;
    await s3.send(
      new PutObjectCommand({
        Bucket: serverEnv.awsS3Bucket,
        Key: key,
        Body: params.buffer,
        ContentType: params.mimeType || 'application/octet-stream',
      })
    );
    return `s3://${serverEnv.awsS3Bucket}/${key}`;
  }

  const rawPath = path.join(companyDir, `${safeDoc}-${safeFile}`);
  await fs.writeFile(rawPath, params.buffer);
  return `local://companies/${safeCompany}/${safeDoc}-${safeFile}`;
}

export async function loadDocumentExtract(
  companyId: string,
  docId: string
): Promise<StoredDocumentExtract | null> {
  const safeCompany = sanitizeSegment(companyId);
  const safeDoc = sanitizeSegment(docId);
  const extractPath = path.join(getCompanyDir(safeCompany), `${safeDoc}.extracted.json`);
  try {
    const raw = await fs.readFile(extractPath, 'utf-8');
    return JSON.parse(raw) as StoredDocumentExtract;
  } catch {
    return null;
  }
}

export async function listCompanyDocumentExtracts(
  companyId: string,
  limit = 16
): Promise<StoredDocumentExtract[]> {
  const safeCompany = sanitizeSegment(companyId);
  const companyDir = getCompanyDir(safeCompany);
  try {
    const entries = await fs.readdir(companyDir);
    const extractFiles = entries.filter((e) => e.endsWith('.extracted.json')).slice(-limit);
    const out: StoredDocumentExtract[] = [];
    for (const file of extractFiles) {
      try {
        const raw = await fs.readFile(path.join(companyDir, file), 'utf-8');
        out.push(JSON.parse(raw) as StoredDocumentExtract);
      } catch {
        // Ignore corrupted extract
      }
    }
    return out;
  } catch {
    return [];
  }
}

export async function deleteDocumentObjects(
  companyId: string,
  docId: string,
  storageLocation?: string
): Promise<void> {
  const safeCompany = sanitizeSegment(companyId);
  const safeDoc = sanitizeSegment(docId);
  const companyDir = getCompanyDir(safeCompany);

  try {
    const entries = await fs.readdir(companyDir);
    for (const entry of entries) {
      if (entry.startsWith(`${safeDoc}-`) || entry === `${safeDoc}.extracted.json`) {
        await fs.unlink(path.join(companyDir, entry)).catch(() => undefined);
      }
    }
  } catch {
    // Directory may not exist
  }

  if (storageLocation && storageLocation.startsWith('s3://')) {
    const s3 = getS3Client();
    if (s3 && serverEnv.awsS3Bucket) {
      const prefix = `s3://${serverEnv.awsS3Bucket}/`;
      if (storageLocation.startsWith(prefix)) {
        const key = storageLocation.slice(prefix.length);
        await s3
          .send(
            new DeleteObjectCommand({
              Bucket: serverEnv.awsS3Bucket,
              Key: key,
            })
          )
          .catch(() => undefined);
      }
    }
  }
}

export async function purgeCompanyStorage(companyId: string): Promise<void> {
  const safeCompany = sanitizeSegment(companyId);
  const companyDir = getCompanyDir(safeCompany);
  await fs.rm(companyDir, { recursive: true, force: true }).catch(() => undefined);

  const s3 = getS3Client();
  if (s3 && serverEnv.awsS3Bucket) {
    try {
      const listed = await s3.send(
        new ListObjectsV2Command({
          Bucket: serverEnv.awsS3Bucket,
          Prefix: `companies/${safeCompany}/`,
        })
      );
      const objects = (listed.Contents || [])
        .map((obj) => (obj.Key ? { Key: obj.Key } : null))
        .filter((x): x is { Key: string } => x !== null);
      if (objects.length > 0) {
        await s3.send(
          new DeleteObjectsCommand({
            Bucket: serverEnv.awsS3Bucket,
            Delete: { Objects: objects },
          })
        );
      }
    } catch {
      // Ignore S3 cleanup error if objects don't exist
    }
  }
}
