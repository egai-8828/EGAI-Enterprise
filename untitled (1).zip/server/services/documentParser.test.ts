import test from 'node:test';
import assert from 'node:assert/strict';
import * as XLSX from 'xlsx';
import { detectDocumentFormat, parseDocumentBuffer } from './documentParser.ts';

test('detectDocumentFormat identifies all supported formats and rejects unsupported ones', () => {
  assert.equal(detectDocumentFormat('q3_financials.pdf'), 'pdf');
  assert.equal(detectDocumentFormat('ledger.xlsx'), 'xlsx');
  assert.equal(detectDocumentFormat('metrics.csv'), 'csv');
  assert.equal(detectDocumentFormat('memo.docx'), 'docx');
  assert.equal(detectDocumentFormat('notes.txt'), 'txt');
  assert.equal(detectDocumentFormat('malware.exe'), null);
});

test('parseDocumentBuffer extracts CSV rows and verified numeric summaries', async () => {
  const csv = 'Quarter,Revenue,Cost\nQ1,120000,80000\nQ2,145000,85000\nQ3,160000,90000\n';
  const result = await parseDocumentBuffer(Buffer.from(csv, 'utf-8'), 'revenue.csv');
  assert.equal(result.fileType, 'csv');
  assert.ok(result.sheetNames && result.sheetNames.length === 1);
  assert.ok(result.sheets && result.sheets[0].rowCount === 3);
  const rev = result.sheets[0].numericSummaries.find((s) => s.column === 'Revenue');
  assert.ok(rev);
  assert.equal(rev.sum, 425000);
  assert.equal(rev.min, 120000);
  assert.equal(rev.max, 160000);
});

test('parseDocumentBuffer extracts XLSX multi-sheet workbooks', async () => {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet([
    { Department: 'Engineering', Spend: 50000 },
    { Department: 'Operations', Spend: 30000 },
  ]);
  XLSX.utils.book_append_sheet(wb, ws, 'Expenses');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;

  const result = await parseDocumentBuffer(buf, 'budget.xlsx');
  assert.equal(result.fileType, 'xlsx');
  assert.deepEqual(result.sheetNames, ['Expenses']);
  assert.ok(result.fullText.includes('Expenses'));
  assert.ok(result.fullText.includes('80000'));
});

test('parseDocumentBuffer extracts TXT and rejects empty buffers', async () => {
  const txt = await parseDocumentBuffer(Buffer.from('Enterprise Q4 budget policy.', 'utf-8'), 'policy.txt');
  assert.equal(txt.fileType, 'txt');
  assert.ok(txt.fullText.includes('Enterprise Q4 budget policy.'));

  await assert.rejects(
    () => parseDocumentBuffer(Buffer.alloc(0), 'empty.txt'),
    /empty/i
  );
});
