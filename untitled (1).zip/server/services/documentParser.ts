import path from 'node:path';
import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import { PDFParse } from 'pdf-parse';
import type { DocumentFormat, SheetSummary } from '../../src/shared/types.ts';
import { summarizeTabularRows } from '../../src/shared/financeUtils.ts';

export interface ParsedDocumentResult {
  fileType: DocumentFormat;
  pageCount?: number;
  sheetNames?: string[];
  sheets?: SheetSummary[];
  fullText: string;
  textPreview: string;
}

const EXTENSION_MAP: Record<string, DocumentFormat> = {
  '.pdf': 'pdf',
  '.xlsx': 'xlsx',
  '.xls': 'xlsx',
  '.csv': 'csv',
  '.docx': 'docx',
  '.txt': 'txt',
};

export function detectDocumentFormat(fileName: string): DocumentFormat | null {
  const ext = path.extname(fileName).toLowerCase();
  return EXTENSION_MAP[ext] ?? null;
}

export async function parseDocumentBuffer(
  buffer: Buffer,
  fileName: string
): Promise<ParsedDocumentResult> {
  const fileType = detectDocumentFormat(fileName);
  if (!fileType) {
    throw new Error(
      `Unsupported file format for "${fileName}". Supported formats: PDF, XLSX, CSV, DOCX, TXT.`
    );
  }

  if (buffer.length === 0) {
    throw new Error(`File "${fileName}" is empty (0 bytes).`);
  }

  if (fileType === 'pdf') {
    const parser = new PDFParse({ data: buffer });
    try {
      const result = await parser.getText();
      const pages = result.pages || [];
      const formattedPages =
        pages.length > 0
          ? pages
              .map((p) => `[Page ${p.num}]\n${(p.text || '').trim()}`)
              .filter((s) => s.length > 0)
              .join('\n\n')
          : (result.text || '').trim();

      if (!formattedPages) {
        throw new Error(
          'No extractable text found in PDF. Scanned image-only PDFs require OCR before analysis.'
        );
      }

      return {
        fileType: 'pdf',
        pageCount: result.total || pages.length || 1,
        fullText: formattedPages,
        textPreview: formattedPages.slice(0, 12000),
      };
    } finally {
      await parser.destroy();
    }
  }

  if (fileType === 'xlsx' || fileType === 'csv') {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheetNames = workbook.SheetNames || [];
    if (sheetNames.length === 0) {
      throw new Error('Spreadsheet contains no readable sheets.');
    }

    const sheets: SheetSummary[] = [];
    const sections: string[] = [];

    for (const sheetName of sheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      if (!worksheet) continue;
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, {
        defval: '',
      });
      const summary = summarizeTabularRows(sheetName, rows);
      sheets.push(summary);

      const csvSnippet = XLSX.utils.sheet_to_csv(worksheet).split('\n').slice(0, 120).join('\n');
      const statsBlock =
        summary.numericSummaries.length > 0
          ? `Verified Column Statistics (${sheetName}):\n` +
            summary.numericSummaries
              .map(
                (s) =>
                  `- ${s.column}: count=${s.count}, sum=${s.sum}, mean=${s.mean}, min=${s.min}, max=${s.max}${
                    s.anomalies.length > 0 ? `, outliers=[${s.anomalies.join(', ')}]` : ''
                  }`
              )
              .join('\n')
          : 'No numeric columns detected in this sheet.';

      sections.push(
        `[Sheet "${sheetName}" | ${summary.rowCount} rows | Columns: ${summary.headers.join(', ')}]\n${statsBlock}\n\nRows Preview (CSV):\n${csvSnippet}`
      );
    }

    const fullText = sections.join('\n\n---\n\n');
    return {
      fileType,
      sheetNames,
      sheets,
      fullText,
      textPreview: fullText.slice(0, 12000),
    };
  }

  if (fileType === 'docx') {
    const extracted = await mammoth.extractRawText({ buffer });
    const text = (extracted.value || '').trim();
    if (!text) {
      throw new Error('No extractable text found in DOCX file.');
    }
    return {
      fileType: 'docx',
      fullText: text,
      textPreview: text.slice(0, 12000),
    };
  }

  // TXT
  const text = buffer.toString('utf-8').trim();
  if (!text) {
    throw new Error('Text file contains no readable content.');
  }
  return {
    fileType: 'txt',
    fullText: text,
    textPreview: text.slice(0, 12000),
  };
}
