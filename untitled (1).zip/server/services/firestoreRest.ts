import { firebaseConfig } from '../config.ts';
import type { CompanyMember, CompanyProfile, UserRole } from '../../src/shared/types.ts';

const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents`;

type FirestoreValue =
  | { stringValue: string }
  | { integerValue: string }
  | { doubleValue: number }
  | { booleanValue: boolean }
  | { timestampValue: string }
  | { nullValue: null }
  | { arrayValue: { values?: FirestoreValue[] } }
  | { mapValue: { fields?: Record<string, FirestoreValue> } };

function decodeValue(val: FirestoreValue | undefined): unknown {
  if (!val) return undefined;
  if ('stringValue' in val) return val.stringValue;
  if ('integerValue' in val) return Number(val.integerValue);
  if ('doubleValue' in val) return val.doubleValue;
  if ('booleanValue' in val) return val.booleanValue;
  if ('timestampValue' in val) return val.timestampValue;
  if ('nullValue' in val) return null;
  if ('arrayValue' in val) return (val.arrayValue.values || []).map(decodeValue);
  if ('mapValue' in val) {
    const out: Record<string, unknown> = {};
    const fields = val.mapValue.fields || {};
    for (const [k, v] of Object.entries(fields)) {
      out[k] = decodeValue(v);
    }
    return out;
  }
  return undefined;
}

function decodeDocument(doc: { fields?: Record<string, FirestoreValue> }): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(doc.fields || {})) {
    out[k] = decodeValue(v);
  }
  return out;
}

async function firestoreGet(docPath: string, idToken: string): Promise<Record<string, unknown> | null> {
  const res = await fetch(`${FIRESTORE_BASE}/${docPath}`, {
    headers: {
      Authorization: `Bearer ${idToken}`,
    },
  });
  if (res.status === 404) return null;
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore read failed (${res.status}): ${body}`);
  }
  const data = (await res.json()) as { fields?: Record<string, FirestoreValue> };
  return decodeDocument(data);
}

export async function getCompanyProfileRest(
  companyId: string,
  idToken: string
): Promise<CompanyProfile | null> {
  const doc = await firestoreGet(`companies/${encodeURIComponent(companyId)}`, idToken);
  return doc as CompanyProfile | null;
}

export async function getCompanyMemberRest(
  companyId: string,
  uid: string,
  idToken: string
): Promise<CompanyMember | null> {
  const doc = await firestoreGet(
    `companies/${encodeURIComponent(companyId)}/members/${encodeURIComponent(uid)}`,
    idToken
  );
  return doc as CompanyMember | null;
}

export async function getMonthUsageRest(
  companyId: string,
  monthKey: string,
  idToken: string
): Promise<{ tokensUsed: number; requestsUsed: number }> {
  const res = await fetch(`${FIRESTORE_BASE}/companies/${encodeURIComponent(companyId)}:runQuery`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: 'usageLogs' }],
        where: {
          fieldFilter: {
            field: { fieldPath: 'monthKey' },
            op: 'EQUAL',
            value: { stringValue: monthKey },
          },
        },
      },
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore usage query failed (${res.status}): ${text}`);
  }

  const rows = (await res.json()) as Array<{ document?: { fields?: Record<string, FirestoreValue> } }>;
  let tokensUsed = 0;
  let requestsUsed = 0;

  for (const row of rows) {
    if (!row.document) continue;
    const decoded = decodeDocument(row.document);
    const inp = typeof decoded.inputTokens === 'number' ? decoded.inputTokens : 0;
    const out = typeof decoded.outputTokens === 'number' ? decoded.outputTokens : 0;
    tokensUsed += inp + out;
    requestsUsed += 1;
  }

  return { tokensUsed, requestsUsed };
}

export async function updateCompanyLimitsRest(
  companyId: string,
  idToken: string,
  updates: { planId: string; monthlyTokenLimit: number; monthlyRequestLimit: number }
): Promise<void> {
  const commitRes = await fetch(
    `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents:commit`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${idToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        writes: [
          {
            update: {
              name: `projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/companies/${companyId}`,
              fields: {
                planId: { stringValue: updates.planId },
                monthlyTokenLimit: { integerValue: String(Math.round(updates.monthlyTokenLimit)) },
                monthlyRequestLimit: { integerValue: String(Math.round(updates.monthlyRequestLimit)) },
              },
            },
            updateMask: {
              fieldPaths: ['planId', 'monthlyTokenLimit', 'monthlyRequestLimit'],
            },
            updateTransforms: [
              {
                fieldPath: 'updatedAt',
                setToServerValue: 'REQUEST_TIME',
              },
            ],
          },
        ],
      }),
    }
  );

  if (!commitRes.ok) {
    const errText = await commitRes.text();
    throw new Error(`Failed to update company limits (${commitRes.status}): ${errText}`);
  }
}

export async function createUsageLogRest(
  companyId: string,
  logId: string,
  idToken: string,
  payload: {
    userId: string;
    userEmail: string;
    specialistId: string;
    provider: string;
    model: string;
    inputTokens: number;
    outputTokens: number;
    monthKey: string;
    action: string;
  }
): Promise<void> {
  const safeEmail =
    typeof payload.userEmail === 'string' && payload.userEmail.trim().length >= 3
      ? payload.userEmail.trim().slice(0, 254)
      : 'unknown@user.egai';
  const safeModel =
    typeof payload.model === 'string' && payload.model.trim().length >= 1
      ? payload.model.trim().slice(0, 120)
      : 'gemini-4-hydrogen';
  const safeProvider = payload.provider === 'bedrock' ? 'bedrock' : 'gemini';
  const safeMonthKey = /^[0-9]{4}-[0-9]{2}$/.test(payload.monthKey)
    ? payload.monthKey
    : new Date().toISOString().slice(0, 7);

  const docName = `projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/companies/${companyId}/usageLogs/${logId}`;
  const res = await fetch(
    `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents:commit`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${idToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        writes: [
          {
            update: {
              name: docName,
              fields: {
                id: { stringValue: logId.slice(0, 128) },
                companyId: { stringValue: companyId.slice(0, 128) },
                userId: { stringValue: payload.userId.slice(0, 128) },
                userEmail: { stringValue: safeEmail },
                specialistId: { stringValue: payload.specialistId },
                provider: { stringValue: safeProvider },
                model: { stringValue: safeModel },
                inputTokens: {
                  integerValue: String(
                    Math.max(0, Math.min(10000000, Math.round(payload.inputTokens || 0)))
                  ),
                },
                outputTokens: {
                  integerValue: String(
                    Math.max(0, Math.min(10000000, Math.round(payload.outputTokens || 0)))
                  ),
                },
                monthKey: { stringValue: safeMonthKey },
                action: { stringValue: payload.action },
              },
            },
            updateTransforms: [
              {
                fieldPath: 'createdAt',
                setToServerValue: 'REQUEST_TIME',
              },
            ],
            currentDocument: { exists: false },
          },
        ],
      }),
    }
  );

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to persist usage log (${res.status}): ${errText}`);
  }
}

export function isValidCompanyIdFormat(id: string): boolean {
  return typeof id === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(id);
}

export function assertAuthorizedRole(member: CompanyMember | null, allowed: UserRole[]): CompanyMember {
  if (!member) {
    throw new Error('FORBIDDEN: User is not a member of this company.');
  }
  if (!allowed.includes(member.role)) {
    throw new Error(`FORBIDDEN: Role "${member.role}" is not permitted for this action.`);
  }
  return member;
}
