import {
  BedrockRuntimeClient,
  ConverseCommand,
  ConverseStreamCommand,
  type Message as BedrockMessage,
} from '@aws-sdk/client-bedrock-runtime';
import { GoogleGenAI, Type, type Content, type Schema } from '@google/genai';
import {
  getActiveAiProvider,
  isBedrockConfigured,
  isGeminiConfigured,
  serverEnv,
} from '../config.ts';
import {
  inferDomainFromText,
  sanitizeForensicFindingDraft,
  sanitizeGrowthProposalDraft,
  sanitizeStructuredRecordDraft,
  WORKSPACE_DATA_DOMAINS,
  type CompanyAnalyticsSnapshot,
  type ExtractedRecordDraft,
  type ForensicFindingDraft,
  type GrowthProposalDraft,
} from '../../src/shared/intelligenceEngine.ts';
import {
  parseSpecialistId,
  resolveSpecialistFallback,
  SPECIALISTS,
} from '../../src/shared/specialists.ts';
import { getCurrentMonthKey } from '../../src/shared/financeUtils.ts';
import type {
  ActiveSpecialistId,
  AIProviderName,
  DocumentFormat,
  GrowthAdvisorDomain,
  KnowledgeChunk,
  SheetSummary,
  StructuredBusinessRecord,
  WorkspaceDataDomain,
} from '../../src/shared/types.ts';
import type { StoredDocumentExtract } from './storageService.ts';

export class IntegrationNotConfiguredError extends Error {
  statusCode = 503;
  provider: string;
  requiredEnv: string[];

  constructor(provider: string, requiredEnv: string[], message: string) {
    super(message);
    this.name = 'IntegrationNotConfiguredError';
    this.provider = provider;
    this.requiredEnv = requiredEnv;
  }
}

export interface ChatTurnInput {
  role: 'user' | 'assistant';
  content: string;
}

export interface AIInferenceResult {
  text: string;
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
}

function getBedrockClient(): BedrockRuntimeClient {
  return new BedrockRuntimeClient({
    region: serverEnv.awsRegion,
    credentials: {
      accessKeyId: serverEnv.awsAccessKeyId,
      secretAccessKey: serverEnv.awsSecretAccessKey,
    },
  });
}

function getGeminiClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: serverEnv.geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function resolveActiveProvider(): AIProviderName {
  const provider = getActiveAiProvider();
  if (provider === 'bedrock') {
    if (!isBedrockConfigured()) {
      throw new IntegrationNotConfiguredError(
        'Amazon Bedrock',
        ['AWS_REGION', 'AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'BEDROCK_MODEL_ID'],
        'AI inference provider (Amazon Bedrock) is not configured on this server.'
      );
    }
    return 'bedrock';
  }
  if (!isGeminiConfigured()) {
    throw new IntegrationNotConfiguredError(
      'Google Gemini',
      ['GEMINI_API_KEY'],
      'Server-side AI inference requires GEMINI_API_KEY in the server environment.'
    );
  }
  return 'gemini';
}

function isTransientAiError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    msg.includes('429') ||
    msg.includes('500') ||
    msg.includes('503') ||
    msg.includes('resource_exhausted') ||
    msg.includes('unavailable') ||
    msg.includes('timeout') ||
    msg.includes('fetch failed')
  );
}

async function withRetry<T>(fn: () => Promise<T>, maxAttempts = 3): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      if (attempt === maxAttempts || !isTransientAiError(err)) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 400 * Math.pow(2, attempt - 1)));
    }
  }
  throw lastErr;
}

function buildGeminiChatContents(history: ChatTurnInput[], userMessage: string): Content[] {
  const contents: Content[] = [];
  for (const turn of history.slice(-12)) {
    const text = (turn.content || '').trim();
    if (!text) continue;
    const role: 'user' | 'model' = turn.role === 'assistant' ? 'model' : 'user';
    if (contents.length === 0 && role === 'model') continue;
    const prev = contents[contents.length - 1];
    if (prev && prev.role === role) {
      prev.parts = [...(prev.parts || []), { text }];
    } else {
      contents.push({ role, parts: [{ text }] });
    }
  }
  const cleanMsg = userMessage.trim();
  const last = contents[contents.length - 1];
  if (last && last.role === 'user') {
    last.parts = [...(last.parts || []), { text: cleanMsg }];
  } else {
    contents.push({ role: 'user', parts: [{ text: cleanMsg }] });
  }
  return contents;
}

function extractJsonText(raw: string): string {
  const trimmed = raw.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenced && fenced[1]) return fenced[1].trim();
  const firstObj = trimmed.indexOf('{');
  const firstArr = trimmed.indexOf('[');
  const start =
    firstObj === -1 ? firstArr : firstArr === -1 ? firstObj : Math.min(firstObj, firstArr);
  if (start > 0) {
    return trimmed.slice(start);
  }
  return trimmed;
}

export function buildGroundingSystemPrompt(params: {
  baseInstruction: string;
  companyName: string;
  industry: string;
  country: string;
  language: 'en' | 'ar';
  companySummary?: string;
  strategicGoals?: string[];
  focusData?: string;
  structuredAnalyticsSummary?: string;
  retrievedChunks?: Array<{ chunk: KnowledgeChunk; score: number }>;
  documents: StoredDocumentExtract[];
}): string {
  const docContext =
    params.documents.length > 0
      ? params.documents
          .map((d) => {
            const excerpt = d.fullText.slice(0, 18000);
            const meta = [
              `Type: ${d.fileType.toUpperCase()}`,
              d.domain ? `Domain: ${d.domain}` : null,
              d.periodKey ? `Period: ${d.periodKey}` : null,
              d.pageCount ? `Pages: ${d.pageCount}` : null,
              d.sheetNames?.length ? `Sheets: ${d.sheetNames.join(', ')}` : null,
            ]
              .filter(Boolean)
              .join(' | ');
            return `=== COMPANY DOCUMENT: "${d.fileName}" (${meta}) ===\n${excerpt}`;
          })
          .join('\n\n')
      : 'No company documents are stored in the workspace yet. Do not fabricate metrics; analyze user-specified focus data if provided, or explain what data domain should be uploaded.';

  const ragContext =
    params.retrievedChunks && params.retrievedChunks.length > 0
      ? `\n\nTOP RETRIEVED MEMORY CHUNKS (RAG):\n${params.retrievedChunks
          .map(
            (r, i) =>
              `[${i + 1}] ${r.chunk.documentName} (${r.chunk.locationLabel} · domain=${r.chunk.domain} · score=${r.score}):\n${r.chunk.content}`
          )
          .join('\n\n')}`
      : '';

  const goalsText =
    params.strategicGoals && params.strategicGoals.length > 0
      ? `\n- Strategic Goals: ${params.strategicGoals.join(' | ')}`
      : '';

  const cleanFocus = (params.focusData || '').trim().slice(0, 8000);
  const focusSection = cleanFocus
    ? `\n\nUSER-SPECIFIED MODEL FOCUS DATA (HIGH PRIORITY — center your analysis and recommendations on these metrics, items, and priorities):\n${cleanFocus}`
    : '';

  return `${params.baseInstruction}

COMPANY INTELLIGENCE CONTEXT:
- Organization: ${params.companyName}
- Industry: ${params.industry}
- Country: ${params.country}
- UI Language: ${params.language === 'ar' ? 'Arabic (العربية)' : 'English'}${
    params.companySummary ? `\n- Company Summary: ${params.companySummary}` : ''
  }${goalsText}${
    params.structuredAnalyticsSummary
      ? `\n- Structured Ledger Snapshot:\n${params.structuredAnalyticsSummary}`
      : ''
  }${focusSection}

GOVERNANCE RULE:
- Never fabricate financial figures. Always cite document name and page/sheet location.
- AI recommendations are advisory only and always require Management Approval before execution.
${ragContext}

${docContext}`;
}

export async function streamEnterpriseAI(params: {
  systemInstruction: string;
  history: ChatTurnInput[];
  userMessage: string;
  onDelta: (chunk: string) => void;
}): Promise<AIInferenceResult> {
  const provider = resolveActiveProvider();

  if (provider === 'bedrock') {
    const client = getBedrockClient();
    const cleanedHistory = buildGeminiChatContents(params.history, params.userMessage);
    const messages: BedrockMessage[] = cleanedHistory.map((c) => ({
      role: c.role === 'model' ? 'assistant' : 'user',
      content: (c.parts || []).map((p) => ({ text: p.text || '' })),
    }));

    const response = await withRetry(() =>
      client.send(
        new ConverseStreamCommand({
          modelId: serverEnv.bedrockModelId,
          system: [{ text: params.systemInstruction }],
          messages,
          inferenceConfig: {
            maxTokens: 4096,
            temperature: 0.2,
          },
        })
      )
    );

    let fullText = '';
    let inputTokens = 0;
    let outputTokens = 0;

    if (response.stream) {
      for await (const event of response.stream) {
        const deltaText = event.contentBlockDelta?.delta?.text;
        if (deltaText) {
          fullText += deltaText;
          params.onDelta(deltaText);
        }
        if (event.metadata?.usage) {
          inputTokens = event.metadata.usage.inputTokens ?? inputTokens;
          outputTokens = event.metadata.usage.outputTokens ?? outputTokens;
        }
      }
    }

    return {
      text: fullText,
      provider: 'bedrock',
      model: serverEnv.bedrockModelId,
      inputTokens,
      outputTokens,
    };
  }

  const ai = getGeminiClient();
  const contents = buildGeminiChatContents(params.history, params.userMessage);

  const stream = await withRetry(() =>
    ai.models.generateContentStream({
      model: serverEnv.geminiModel,
      contents,
      config: {
        systemInstruction: params.systemInstruction,
      },
    })
  );

  let fullText = '';
  let inputTokens = 0;
  let outputTokens = 0;

  for await (const chunk of stream) {
    const textPart = chunk.text ?? '';
    if (textPart) {
      fullText += textPart;
      params.onDelta(textPart);
    }
    if (chunk.usageMetadata) {
      inputTokens = chunk.usageMetadata.promptTokenCount ?? inputTokens;
      outputTokens = chunk.usageMetadata.candidatesTokenCount ?? outputTokens;
    }
  }

  return {
    text: fullText,
    provider: 'gemini',
    model: serverEnv.geminiModel,
    inputTokens,
    outputTokens,
  };
}

export async function generateEnterpriseAI(params: {
  systemInstruction: string;
  userPrompt: string;
}): Promise<AIInferenceResult> {
  const provider = resolveActiveProvider();

  if (provider === 'bedrock') {
    const client = getBedrockClient();
    const res = await withRetry(() =>
      client.send(
        new ConverseCommand({
          modelId: serverEnv.bedrockModelId,
          system: [{ text: params.systemInstruction }],
          messages: [
            {
              role: 'user',
              content: [{ text: params.userPrompt }],
            },
          ],
          inferenceConfig: {
            maxTokens: 4096,
            temperature: 0.2,
          },
        })
      )
    );

    const text =
      res.output?.message?.content
        ?.map((b) => b.text || '')
        .join('')
        .trim() || '';

    return {
      text,
      provider: 'bedrock',
      model: serverEnv.bedrockModelId,
      inputTokens: res.usage?.inputTokens ?? 0,
      outputTokens: res.usage?.outputTokens ?? 0,
    };
  }

  const ai = getGeminiClient();
  const res = await withRetry(() =>
    ai.models.generateContent({
      model: serverEnv.geminiModel,
      contents: params.userPrompt,
      config: {
        systemInstruction: params.systemInstruction,
      },
    })
  );

  return {
    text: (res.text ?? '').trim(),
    provider: 'gemini',
    model: serverEnv.geminiModel,
    inputTokens: res.usageMetadata?.promptTokenCount ?? 0,
    outputTokens: res.usageMetadata?.candidatesTokenCount ?? 0,
  };
}

export async function generateStructuredJson<T>(params: {
  systemInstruction: string;
  userPrompt: string;
  schema: Schema;
}): Promise<{
  data: T;
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
}> {
  const provider = resolveActiveProvider();

  if (provider === 'bedrock') {
    const res = await generateEnterpriseAI({
      systemInstruction: `${params.systemInstruction}\nRespond strictly with valid JSON only. No markdown prose.`,
      userPrompt: params.userPrompt,
    });
    const parsed = JSON.parse(extractJsonText(res.text)) as T;
    return {
      data: parsed,
      provider: res.provider,
      model: res.model,
      inputTokens: res.inputTokens,
      outputTokens: res.outputTokens,
    };
  }

  const ai = getGeminiClient();
  const res = await withRetry(() =>
    ai.models.generateContent({
      model: serverEnv.geminiModel,
      contents: params.userPrompt,
      config: {
        systemInstruction: params.systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: params.schema,
      },
    })
  );

  const jsonStr = extractJsonText(res.text ?? '{}');
  const parsed = JSON.parse(jsonStr) as T;

  return {
    data: parsed,
    provider: 'gemini',
    model: serverEnv.geminiModel,
    inputTokens: res.usageMetadata?.promptTokenCount ?? 0,
    outputTokens: res.usageMetadata?.candidatesTokenCount ?? 0,
  };
}

export async function selectSpecialistWithAI(params: {
  query: string;
  focusData?: string;
  documentSummaries?: string[];
  language: 'en' | 'ar';
}): Promise<{
  specialistId: ActiveSpecialistId;
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
}> {
  const catalog = SPECIALISTS.map(
    (s) => `- "${s.id}": ${s.nameEn} (${s.descriptionEn})`
  ).join('\n');

  try {
    const res = await generateStructuredJson<{ specialistId: string }>({
      systemInstruction: `You are an enterprise request router for EGAI Enterprise. Choose the single best active specialist department ID for the user's request.\nAvailable specialists:\n${catalog}`,
      userPrompt: `Query: ${params.query.slice(0, 2000)}${
        params.focusData ? `\nModel Focus Data: ${params.focusData.slice(0, 1000)}` : ''
      }${
        params.documentSummaries?.length
          ? `\nAttached/Indexed Documents: ${params.documentSummaries.slice(0, 8).join('; ')}`
          : ''
      }`,
      schema: {
        type: Type.OBJECT,
        properties: {
          specialistId: {
            type: Type.STRING,
            enum: SPECIALISTS.map((s) => s.id),
            description: 'The single best matching specialist department ID.',
          },
        },
        required: ['specialistId'],
      },
    });

    const parsedId = parseSpecialistId(res.data?.specialistId);
    return {
      specialistId: parsedId ?? resolveSpecialistFallback(params.query, params.focusData),
      provider: res.provider,
      model: res.model,
      inputTokens: res.inputTokens,
      outputTokens: res.outputTokens,
    };
  } catch (err) {
    if (err instanceof IntegrationNotConfiguredError) {
      throw err;
    }
    return {
      specialistId: resolveSpecialistFallback(params.query, params.focusData),
      provider: resolveActiveProvider(),
      model: serverEnv.geminiModel,
      inputTokens: 0,
      outputTokens: 0,
    };
  }
}

export async function classifyAndExtractDocumentWithAI(params: {
  fileName: string;
  fileType: DocumentFormat;
  fullText: string;
  sheets?: SheetSummary[];
  requestedDomain?: WorkspaceDataDomain;
  requestedPeriod?: string;
  companyName: string;
  industry: string;
}): Promise<{
  domain: WorkspaceDataDomain;
  periodKey: string;
  summary: string;
  extractedRecords: ExtractedRecordDraft[];
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
}> {
  const validDomainIds = new Set(WORKSPACE_DATA_DOMAINS.map((d) => d.id));
  const sheetOverview =
    params.sheets && params.sheets.length > 0
      ? params.sheets
          .map(
            (s) =>
              `Sheet "${s.sheetName}" (${s.rowCount} rows) headers: [${s.headers.join(', ')}]`
          )
          .join('\n')
      : 'No spreadsheet tabs.';

  const excerpt = (params.fullText || '').slice(0, 16000);
  const domainsDesc = WORKSPACE_DATA_DOMAINS.map(
    (d) => `- "${d.id}": ${d.nameEn} (${d.examplesEn})`
  ).join('\n');

  const res = await generateStructuredJson<{
    domain: WorkspaceDataDomain;
    periodKey: string;
    summary: string;
    extractedRecords: Array<{
      periodKey: string;
      metricKey: string;
      metricLabel: string;
      category: string;
      numericValue: number;
      unit: string;
      sourceLocation: string;
    }>;
  }>({
    systemInstruction: `You are EGAI Document Ingestion Intelligence for "${params.companyName}" (${params.industry}).
Analyze the uploaded business document excerpt and:
1. Classify it into the single best department domain:
${domainsDesc}
2. Determine its primary reporting periodKey (format YYYY-MM if monthly e.g. 2026-03, YYYY-Q# if quarterly, or YYYY if annual).
3. Write a concise factual 2-sentence executive summary citing document contents only.
4. Extract key verified numeric business metrics found verbatim in the document (revenue, expenses, net_profit, payroll, headcount, marketing_spend, procurement_spend, conversion_rate, kpi_metric). Never guess or invent numbers not explicitly printed in the document.`,
    userPrompt: `Filename: ${params.fileName} (${params.fileType.toUpperCase()})
${params.requestedDomain ? `Requested Domain Hint: ${params.requestedDomain}` : 'Domain Hint: Auto-detect'}
${params.requestedPeriod ? `Default Period Hint: ${params.requestedPeriod}` : ''}
${sheetOverview}

Document Content Excerpt:
${excerpt || '(Empty text payload)'}`,
    schema: {
      type: Type.OBJECT,
      properties: {
        domain: {
          type: Type.STRING,
          enum: WORKSPACE_DATA_DOMAINS.map((d) => d.id),
        },
        periodKey: { type: Type.STRING },
        summary: { type: Type.STRING },
        extractedRecords: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              periodKey: { type: Type.STRING },
              metricKey: { type: Type.STRING },
              metricLabel: { type: Type.STRING },
              category: { type: Type.STRING },
              numericValue: { type: Type.NUMBER },
              unit: { type: Type.STRING },
              sourceLocation: { type: Type.STRING },
            },
            required: [
              'periodKey',
              'metricKey',
              'metricLabel',
              'category',
              'numericValue',
              'unit',
              'sourceLocation',
            ],
          },
        },
      },
      required: ['domain', 'periodKey', 'summary', 'extractedRecords'],
    },
  });

  const finalDomain: WorkspaceDataDomain =
    params.requestedDomain && validDomainIds.has(params.requestedDomain)
      ? params.requestedDomain
      : validDomainIds.has(res.data?.domain)
      ? res.data.domain
      : inferDomainFromText(params.fileName, params.fullText);

  const cleanPeriod =
    params.requestedPeriod?.trim().slice(0, 32) ||
    (res.data?.periodKey || '').trim().slice(0, 32) ||
    getCurrentMonthKey();

  const sanitizedRecords = Array.isArray(res.data?.extractedRecords)
    ? res.data.extractedRecords
        .slice(0, 25)
        .map((r) =>
          sanitizeStructuredRecordDraft(
            { ...r, domain: finalDomain },
            finalDomain,
            cleanPeriod,
            params.fileName
          )
        )
    : [];

  return {
    domain: finalDomain,
    periodKey: cleanPeriod,
    summary: (res.data?.summary || '').trim().slice(0, 600),
    extractedRecords: sanitizedRecords,
    provider: res.provider,
    model: res.model,
    inputTokens: res.inputTokens,
    outputTokens: res.outputTokens,
  };
}

export async function generateGrowthProposalsWithAI(params: {
  companyName: string;
  industry: string;
  country: string;
  language: 'en' | 'ar';
  domains: GrowthAdvisorDomain[];
  docs: StoredDocumentExtract[];
  records: StructuredBusinessRecord[];
  chunks: KnowledgeChunk[];
  analytics: CompanyAnalyticsSnapshot;
  focusData?: string;
}): Promise<{
  proposals: GrowthProposalDraft[];
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
}> {
  const isAr = params.language === 'ar';
  const docIds = Array.from(
    new Set([
      ...params.docs.map((d) => d.docId),
      ...params.records.map((r) => r.sourceDocumentId),
    ])
  ).slice(0, 20);

  const recordsSample = params.records
    .slice(0, 45)
    .map(
      (r) =>
        `${r.domain} | ${r.periodKey} | ${r.metricLabel}: ${r.numericValue} ${r.unit} (${r.sourceDocumentName} · ${r.sourceLocation})`
    )
    .join('\n');

  const chunksSample = params.chunks
    .slice(0, 12)
    .map((c) => `[${c.documentName} · ${c.locationLabel}]: ${c.content.slice(0, 400)}`)
    .join('\n');

  const systemInstruction = `You are the EGAI Enterprise Business Growth Advisor for "${params.companyName}" (${params.industry}, ${params.country}).
Write all proposal text strictly in ${isAr ? 'Arabic (العربية)' : 'English'}.
Produce EXACTLY one thorough, practical, executive-ready growth proposal for EACH requested domain in: [${params.domains.join(', ')}].
STRICT RULES:
- Prioritize any User-Specified Model Focus Data directly inside evidenceAndNumbers, detectedProblem, and proposedSolution.
- Ground every metric in the actual ledger analytics, structured records, and uploaded document excerpts provided. If a specific domain has no uploaded data yet, state that data gap clearly in evidenceAndNumbers instead of fabricating numbers.
- Provide realistic expectedCost, quantified expectedReturn ranges, concrete step-by-step executionPlan items (at least 3 steps), and measurable KPI successMetrics.
- All proposals are advisory and require Management Approval before execution.`;

  const userPrompt = `Requested Domains (${params.domains.length}): ${params.domains.join(', ')}
${params.focusData ? `\nMODEL FOCUS DATA (HIGH PRIORITY):\n${params.focusData}\n` : ''}
LEDGER ANALYTICS:
Total Records: ${params.analytics.totalRecords} | Revenue: ${params.analytics.totalRevenue} | Expenses: ${params.analytics.totalExpenses} | Net Profit: ${params.analytics.netProfit} | Profit Margin %: ${params.analytics.profitMarginPct ?? 'N/A'} | Revenue Growth %: ${params.analytics.revenueGrowthPct ?? 'N/A'} | Expense Growth %: ${params.analytics.expenseGrowthPct ?? 'N/A'}

STRUCTURED RECORDS:
${recordsSample || 'No structured records uploaded yet.'}

DOCUMENT EXCERPTS:
${chunksSample || 'No document text chunks indexed yet.'}`;

  const res = await generateStructuredJson<{
    proposals: Array<{
      domain: GrowthAdvisorDomain;
      title: string;
      detectedProblem: string;
      evidenceAndNumbers: string;
      proposedSolution: string;
      expectedCost: string;
      expectedReturn: string;
      executionPlan: string[];
      successMetrics: string;
    }>;
  }>({
    systemInstruction,
    userPrompt,
    schema: {
      type: Type.OBJECT,
      properties: {
        proposals: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              domain: {
                type: Type.STRING,
                enum: params.domains,
              },
              title: { type: Type.STRING },
              detectedProblem: { type: Type.STRING },
              evidenceAndNumbers: { type: Type.STRING },
              proposedSolution: { type: Type.STRING },
              expectedCost: { type: Type.STRING },
              expectedReturn: { type: Type.STRING },
              executionPlan: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              successMetrics: { type: Type.STRING },
            },
            required: [
              'domain',
              'title',
              'detectedProblem',
              'evidenceAndNumbers',
              'proposedSolution',
              'expectedCost',
              'expectedReturn',
              'executionPlan',
              'successMetrics',
            ],
          },
        },
      },
      required: ['proposals'],
    },
  });

  const proposals = (Array.isArray(res.data?.proposals) ? res.data.proposals : [])
    .slice(0, 12)
    .map((p) => sanitizeGrowthProposalDraft(p, docIds));

  return {
    proposals,
    provider: res.provider,
    model: res.model,
    inputTokens: res.inputTokens,
    outputTokens: res.outputTokens,
  };
}

export async function generateForensicFindingsWithAI(params: {
  companyName: string;
  industry: string;
  docs: StoredDocumentExtract[];
  records: StructuredBusinessRecord[];
  mathFindings: ForensicFindingDraft[];
  focusData?: string;
}): Promise<{
  findings: ForensicFindingDraft[];
  provider: AIProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
}> {
  const cleanFocus = (params.focusData || '').trim();
  if (params.docs.length === 0 && params.records.length === 0 && !cleanFocus) {
    const provider = resolveActiveProvider();
    return {
      findings: [],
      provider,
      model: provider === 'bedrock' ? serverEnv.bedrockModelId : serverEnv.geminiModel,
      inputTokens: 0,
      outputTokens: 0,
    };
  }

  const docByName = new Map<string, string>();
  for (const d of params.docs) {
    docByName.set(d.fileName.toLowerCase(), d.docId);
  }
  const fallbackDocId = params.docs[0]?.docId || params.records[0]?.sourceDocumentId || 'workspace_audit';
  const fallbackDocName = params.docs[0]?.fileName || params.records[0]?.sourceDocumentName || 'Company Workspace';

  const docSnippets = params.docs
    .slice(0, 8)
    .map((d) => `=== "${d.fileName}" (${d.fileType.toUpperCase()}) ===\n${d.fullText.slice(0, 3500)}`)
    .join('\n\n');

  const recordsSnippet = params.records
    .slice(0, 40)
    .map(
      (r) =>
        `${r.periodKey} | ${r.category} | ${r.metricLabel}: ${r.numericValue} (${r.sourceDocumentName} · ${r.sourceLocation})`
    )
    .join('\n');

  const existingMathSummary = params.mathFindings
    .map((f) => `- [${f.category}] ${f.titleEn} (${f.sourceDocumentName})`)
    .join('\n');

  const res = await generateStructuredJson<{
    findings: Array<{
      category: ForensicFindingDraft['category'];
      severity: ForensicFindingDraft['severity'];
      titleEn: string;
      titleAr: string;
      descriptionEn: string;
      descriptionAr: string;
      evidence: string;
      sourceDocumentName: string;
      sourceLocation: string;
    }>;
  }>({
    systemInstruction: `You are the EGAI Enterprise Financial Forensics AI Auditor for "${params.companyName}" (${params.industry}).
Inspect uploaded financial/procurement documents, structured records, and Model Focus Data to identify subtle semantic anomalies, vendor pricing variances, unverified discretionary charges, margin leakage, or cross-document mismatches NOT already covered by deterministic rules.
Return bilingual fields (titleEn/titleAr, descriptionEn/descriptionAr). Only report anomalies grounded in the provided data; return an empty list if none exist.`,
    userPrompt: `${cleanFocus ? `MODEL FOCUS DATA (Priority Risks/Audit Targets):\n${cleanFocus}\n\n` : ''}ALREADY DETECTED MATH FINDINGS (do not duplicate these):
${existingMathSummary || 'None'}

STRUCTURED RECORDS:
${recordsSnippet || 'None'}

DOCUMENT EXCERPTS:
${docSnippets || 'None'}`,
    schema: {
      type: Type.OBJECT,
      properties: {
        findings: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              category: {
                type: Type.STRING,
                enum: [
                  'duplicate_entry',
                  'expense_spike',
                  'statistical_outlier',
                  'round_number_pattern',
                  'margin_compression',
                  'vendor_variance',
                ],
              },
              severity: { type: Type.STRING, enum: ['high', 'medium', 'low'] },
              titleEn: { type: Type.STRING },
              titleAr: { type: Type.STRING },
              descriptionEn: { type: Type.STRING },
              descriptionAr: { type: Type.STRING },
              evidence: { type: Type.STRING },
              sourceDocumentName: { type: Type.STRING },
              sourceLocation: { type: Type.STRING },
            },
            required: [
              'category',
              'severity',
              'titleEn',
              'titleAr',
              'descriptionEn',
              'descriptionAr',
              'evidence',
              'sourceDocumentName',
              'sourceLocation',
            ],
          },
        },
      },
      required: ['findings'],
    },
  });

  const findings = (Array.isArray(res.data?.findings) ? res.data.findings : [])
    .slice(0, 10)
    .map((f) => {
      const matchedId =
        docByName.get((f.sourceDocumentName || '').trim().toLowerCase()) || fallbackDocId;
      return sanitizeForensicFindingDraft(f, matchedId, fallbackDocName);
    });

  return {
    findings,
    provider: res.provider,
    model: res.model,
    inputTokens: res.inputTokens,
    outputTokens: res.outputTokens,
  };
}
